/**
 * Member Directory — Directory Search & Filters
 * AJAX-powered search, taxonomy filtering, sort, and layout toggle.
 * Loaded on archive pages only.
 */

(function ($) {
    'use strict';

    var searchTimer = null;
    var $grid = $('#memdir-member-grid');
    var $resultsCount = $('.memdir-results-count');
    var $clearBtn = $('.memdir-clear-filters');

    // --- Layout Toggle ---
    var savedLayout = localStorage.getItem('memdir_layout') || 'grid';

    function applyLayout(layout) {
        $grid.removeClass('memdir-member-grid--grid memdir-member-grid--list')
            .addClass('memdir-member-grid--' + layout);
        $('.memdir-layout-btn').removeClass('active');
        $('.memdir-layout-btn[data-layout="' + layout + '"]').addClass('active');
        localStorage.setItem('memdir_layout', layout);
    }

    // Apply saved layout on load
    applyLayout(savedLayout);

    $(document).on('click', '.memdir-layout-btn', function () {
        applyLayout($(this).data('layout'));
    });

    // --- Collect current filter state ---
    function getFilterState() {
        var state = {
            s: $('#memdir-search-input').val().trim(),
            sort: $('#memdir-sort-select').val(),
            page: 1,
            taxonomies: {}
        };

        $('.memdir-filter-section[data-taxonomy]').each(function () {
            var taxonomy = $(this).data('taxonomy');
            var checked = [];
            $(this).find('input[type="checkbox"]:checked').each(function () {
                checked.push(parseInt($(this).val(), 10));
            });
            if (checked.length > 0) {
                state.taxonomies[taxonomy] = checked;
            }
        });

        return state;
    }

    // --- Update Clear button visibility ---
    function updateClearButton() {
        var state = getFilterState();
        var hasFilters = state.s.length > 0 || Object.keys(state.taxonomies).length > 0;
        $clearBtn.toggle(hasFilters);
    }

    // --- Generate skeleton cards for loading state ---
    function getSkeletonHTML(count) {
        var html = '';
        for (var i = 0; i < count; i++) {
            html += '<div class="memdir-skeleton-card">' +
                '<div class="memdir-skeleton-avatar"></div>' +
                '<div class="memdir-skeleton-line memdir-skeleton-line--title"></div>' +
                '<div class="memdir-skeleton-line memdir-skeleton-line--short"></div>' +
                '<div style="margin-top:12px">' +
                '<span class="memdir-skeleton-line--tag"></span>' +
                '<span class="memdir-skeleton-line--tag"></span>' +
                '<span class="memdir-skeleton-line--tag"></span>' +
                '</div></div>';
        }
        return html;
    }

    // --- AJAX Search ---
    var currentXHR = null; // Track in-flight request for deduplication

    function doSearch(page) {
        var state = getFilterState();
        if (page) state.page = page;

        // Abort any in-flight request to prevent stale overwrites
        if (currentXHR && currentXHR.readyState !== 4) {
            currentXHR.abort();
        }

        // Show skeleton cards instead of opacity fade
        $grid.addClass('memdir-loading').html(getSkeletonHTML(6));

        currentXHR = $.ajax({
            url: memdirArchiveData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'memdir_search_members',
                nonce: memdirArchiveData.nonce,
                search: state.s,
                sort: state.sort,
                page: state.page,
                taxonomies: JSON.stringify(state.taxonomies)
            },
            success: function (response) {
                if (response.success) {
                    $grid.html(response.data.html);
                    $resultsCount.text(response.data.total + ' result' + (response.data.total !== 1 ? 's' : ''));

                    // Update pagination
                    $('.memdir-pagination').html(response.data.pagination);

                    // Reapply layout class
                    var layout = localStorage.getItem('memdir_layout') || 'grid';
                    $grid.removeClass('memdir-member-grid--grid memdir-member-grid--list')
                        .addClass('memdir-member-grid--' + layout);

                    // Update URL without reload
                    updateUrl(state);
                }
            },
            complete: function () {
                $grid.removeClass('memdir-loading');
                currentXHR = null;
            }
        });
    }

    // --- Update URL with current state ---
    function updateUrl(state) {
        var params = new URLSearchParams();
        if (state.s) params.set('s', state.s);
        if (state.sort && state.sort !== 'az') params.set('sort', state.sort);

        for (var tax in state.taxonomies) {
            state.taxonomies[tax].forEach(function (termId) {
                params.append(tax + '[]', termId);
            });
        }

        var newUrl = window.location.pathname;
        var qs = params.toString();
        if (qs) newUrl += '?' + qs;

        window.history.replaceState(null, '', newUrl);
    }

    // --- Event Bindings ---

    // Text search (debounced)
    $('#memdir-search-input').on('input', function () {
        clearTimeout(searchTimer);
        searchTimer = setTimeout(function () {
            doSearch(1);
            updateClearButton();
        }, 300);
    });

    // Sort change
    $('#memdir-sort-select').on('change', function () {
        doSearch(1);
    });

    // Taxonomy checkbox change
    $(document).on('change', '.memdir-filter-checkbox input', function () {
        doSearch(1);
        updateClearButton();
    });

    // Clear all filters
    $clearBtn.on('click', function () {
        $('#memdir-search-input').val('');
        $('.memdir-filter-checkbox input').prop('checked', false);
        doSearch(1);
        updateClearButton();
    });

    // Pagination clicks (delegated for AJAX-replaced content)
    $(document).on('click', '.memdir-pagination a', function (e) {
        e.preventDefault();
        var href = $(this).attr('href');
        var match = href.match(/\/page\/(\d+)/) || href.match(/[?&]paged=(\d+)/);
        var page = match ? parseInt(match[1], 10) : 1;
        doSearch(page);

        // Scroll to top of grid
        $('html, body').animate({ scrollTop: $grid.offset().top - 80 }, 300);
    });

    // --- Initialize filters from URL parameters ---
    // (handles deep-links from profile tag clicks like ?memdir_instruments[]=5)
    var urlParams = new URLSearchParams(window.location.search);
    var hasUrlFilters = false;

    $('.memdir-filter-section[data-taxonomy]').each(function () {
        var taxonomy = $(this).data('taxonomy');
        var paramValues = urlParams.getAll(taxonomy + '[]');
        if (paramValues.length > 0) {
            var $section = $(this);
            paramValues.forEach(function (val) {
                $section.find('input[type="checkbox"][value="' + val + '"]').prop('checked', true);
            });
            hasUrlFilters = true;
        }
    });

    // If URL had filters, also set search input from URL
    var urlSearch = urlParams.get('s');
    if (urlSearch) {
        $('#memdir-search-input').val(urlSearch);
        hasUrlFilters = true;
    }

    // If any URL filters were applied, trigger search to show filtered results
    if (hasUrlFilters) {
        doSearch(1);
    }

    // Initialize clear button state
    updateClearButton();

})(jQuery);
