/**
 * Member Directory - Profile Core
 * Navigation, headers, social links, forms, and shared utilities.
 * Loaded for all viewer modes (edit, member, public).
 */

(function ($) {
    'use strict';

    // Store viewer mode globally (DOCs requirement)
    window.memdirViewMode = (typeof memdirData !== 'undefined') ? memdirData.viewerMode : 'public';

    // Wait for DOM ready
    $(document).ready(function () {
        MEMDIR_Profile.init();
    });

    // Expose globally so pmp-controls.js can access shared methods
    window.MEMDIR_Profile = {

        /**
         * Initialize core interactions
         */
        init: function () {
            this.setupToastContainer();
            this.setupNavPills();
            this.setupSocialFormSync();
            this.setupSaveSocialLinks();

            this.setupShareButton();
            this.setupPortfolioLightbox();
            this.hideEmptySections();
            this.setupRefreshButton();

            // Initialize PMP controls if available (loaded separately in edit mode)
            if (window.MEMDIR_PMP && typeof window.MEMDIR_PMP.init === 'function') {
                window.MEMDIR_PMP.init();
            }
        },

        /**
         * Setup navigation pills switching
         * "All Sections" pill = scroll mode (all visible)
         * Specific section pill = focus mode (only that section)
         */
        setupNavPills: function () {

            $('.memdir-pill').on('click', function (e) {
                e.preventDefault();

                const $pill = $(this);
                const sectionKey = $pill.data('section');

                // Update active pill
                $('.memdir-pill').removeClass('active');
                $pill.addClass('active');

                // Switch headers based on section
                MEMDIR_Profile.switchHeader(sectionKey);

                if (sectionKey === 'all') {
                    // All Sections mode: Show all sections, enable scrolling
                    $('.memdir-section').removeClass('memdir-section-hidden').addClass('memdir-section-visible');

                    // Scroll to top of sections container
                    const $firstSection = $('.memdir-section:first');
                    if ($firstSection.length) {
                        $('html, body').animate({
                            scrollTop: $firstSection.offset().top - 100
                        }, 400);
                    }
                } else {
                    // Focus mode: Hide all sections, show only clicked section
                    const $section = $('.memdir-section[data-section="' + sectionKey + '"]');

                    if ($section.length) {
                        // Hide all sections
                        $('.memdir-section').removeClass('memdir-section-visible').addClass('memdir-section-hidden');

                        // Show only clicked section
                        $section.removeClass('memdir-section-hidden').addClass('memdir-section-visible');
                    }
                }
            });
        },

        /**
         * Hide sections that have no meaningful content (display mode only).
         * Also hides the corresponding navigation pill.
         */
        hideEmptySections: function () {
            // Only run in non-edit modes
            if (window.memdirViewMode === 'edit') return;

            $('.memdir-section').each(function () {
                var $section = $(this);
                var sectionKey = $section.data('section');
                var $content = $section.find('.memdir-section-content');

                // If there's no section-content wrapper, skip (edit mode templates)
                if (!$content.length) return;

                // Check if content is effectively empty:
                // - Only contains .memdir-empty-section message
                // - Or has no visible children at all
                var $children = $content.children().not('.memdir-empty-section');
                var hasContent = false;

                $children.each(function () {
                    // Check if this child has any visible text or images
                    if ($(this).find('img, video, iframe').length > 0 ||
                        $.trim($(this).text()).length > 0) {
                        hasContent = true;
                        return false; // break
                    }
                });

                if (!hasContent) {
                    $section.hide();
                    // Hide the corresponding pill
                    $('.memdir-pill[data-section="' + sectionKey + '"]').hide();
                }
            });
        },

        /**
         * Show a brief save indicator (shared utility)
         */
        showSaveIndicator: function () {
            // Create indicator if it doesn't exist
            if ($('.memdir-save-indicator').length === 0) {
                $('body').append('<div class="memdir-save-indicator">✓ Saved</div>');
            }

            const $indicator = $('.memdir-save-indicator');

            // Show and fade out (styles defined in profile-styles.css)
            $indicator.fadeIn(200).delay(1500).fadeOut(300);
        },

        /**
         * Setup social links sync on ACF form submission
         * Only fires when social link inputs are present (profile section)
         */
        setupSocialFormSync: function () {
            // Only attach if social link inputs exist on this page
            if ($('input[name="author_website"]').length === 0) {
                return;
            }

            // Hook into ACF form submission to include social links
            $('.acf-form').on('submit', function (e) {
                // Get social link values
                const socialLinks = {
                    website: $('input[name="author_website"]').val(),
                    instagram: $('input[name="author_instagram"]').val(),
                    facebook: $('input[name="author_facebook"]').val(),
                    youtube: $('input[name="author_youtube"]').val(),
                    linktree: $('input[name="author_linktree"]').val()
                };

                // Save social links via AJAX (don't prevent form submission)
                $.ajax({
                    url: memdirData.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'memdir_save_social_links',
                        nonce: memdirData.nonce,
                        post_id: memdirData.postId,
                        links: socialLinks
                    }
                });
            });
        },

        /**
         * Setup save social links button
         */
        setupSaveSocialLinks: function () {
            const self = this;

            $('.memdir-save-social-links').on('click', function (e) {
                e.preventDefault();

                const $btn = $(this);
                const originalText = $btn.text();

                // Gather social link values
                const socialLinks = {
                    website: $('input[name="author_website"]').val(),
                    instagram: $('input[name="author_instagram"]').val(),
                    facebook: $('input[name="author_facebook"]').val(),
                    youtube: $('input[name="author_youtube"]').val(),
                    linktree: $('input[name="author_linktree"]').val()
                };

                // Update button state
                $btn.prop('disabled', true).text('Saving...');

                // Save via AJAX
                $.ajax({
                    url: memdirData.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'memdir_save_social_links',
                        nonce: memdirData.nonce,
                        post_id: memdirData.postId,
                        links: socialLinks
                    },
                    success: function (response) {
                        if (response.success) {
                            $btn.text('✓ Saved!');
                            setTimeout(function () {
                                $btn.prop('disabled', false).text(originalText);
                            }, 2000);
                        } else {
                            alert('Error saving social links: ' + (response.data || 'Unknown error'));
                            $btn.prop('disabled', false).text(originalText);
                        }
                    },
                    error: function () {
                        alert('Error saving social links. Please try again.');
                        $btn.prop('disabled', false).text(originalText);
                    }
                });
            });
        },

        /**
         * Switch between Profile and Business headers
         * Shows business header when Business section is focused,
         * profile header for everything else
         * 
         * @param {string} sectionKey - The active section key
         */
        switchHeader: function (sectionKey) {
            // Skip header switching in edit mode (owner always sees profile header)
            const viewerMode = $('.memdir-wrap').data('viewer-mode');
            if (viewerMode === 'edit') {
                return;
            }

            const $profileWrap = $('.memdir-profile-header-wrap');
            const $profileCover = $profileWrap.prev('.memdir-cover-banner');
            const $businessHeader = $('.memdir-business-header');
            const $businessCover = $('.memdir-biz-cover-banner');

            // Only switch if both headers exist
            if (!$businessHeader.length) {
                return;
            }

            // Determine which header to show:
            // - Business pill → always business header
            // - Any other pill → respect the user's saved default
            var showBusiness;
            if (sectionKey === 'business') {
                showBusiness = true;
            } else {
                var defaultHeader = $('.memdir-wrap').data('default-header') || 'personal';
                showBusiness = (defaultHeader === 'business');
            }

            if (showBusiness) {
                $profileWrap.hide();
                $profileCover.hide();
                $businessHeader.show();
                $businessCover.show();
            } else {
                $businessHeader.hide();
                $businessCover.hide();
                $profileWrap.show();
                $profileCover.show();
            }
        },



        // ===================================================
        // TOAST NOTIFICATION SYSTEM
        // ===================================================

        /**
         * Create the toast container once
         */
        setupToastContainer: function () {
            if ($('#memdir-toast-container').length === 0) {
                $('body').append('<div id="memdir-toast-container" class="memdir-toast-container"></div>');
            }
        },

        /**
         * Show a toast notification
         * @param {string} message - Text to display
         * @param {string} type - 'success', 'error', or 'info'
         * @param {number} duration - Auto-dismiss in ms (default 3000)
         */
        toast: function (message, type, duration) {
            type = type || 'info';
            duration = duration || 3000;

            var icons = { success: '✓', error: '✕', info: 'ℹ' };
            // Build toast safely — message uses .text() to prevent XSS
            var $toast = $('<div>', { 'class': 'memdir-toast memdir-toast--' + type });
            $toast.append($('<span>').text(icons[type] || ''));
            $toast.append(' ');
            $toast.append($('<span>').text(message));

            $('#memdir-toast-container').append($toast);

            // Auto-dismiss
            setTimeout(function () {
                $toast.addClass('memdir-toast--exit');
                setTimeout(function () { $toast.remove(); }, 300);
            }, duration);
        },

        // ===================================================
        // SHARE PROFILE BUTTON
        // ===================================================

        setupShareButton: function () {
            var self = this;
            var $btn = $('.memdir-share-btn');
            if ($btn.length === 0) return;

            $btn.on('click', function () {
                var url = $(this).data('url') || window.location.href.split('?')[0];

                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(url).then(function () {
                        self.toast('Profile link copied!', 'success');
                        $btn.addClass('memdir-share-btn--copied').text('✓ Copied!');
                        setTimeout(function () {
                            $btn.removeClass('memdir-share-btn--copied').html('🔗 Share Profile');
                        }, 2000);
                    });
                } else {
                    // Fallback for older browsers
                    var $temp = $('<input>');
                    $('body').append($temp);
                    $temp.val(url).select();
                    document.execCommand('copy');
                    $temp.remove();
                    self.toast('Profile link copied!', 'success');
                }
            });
        },

        // ===================================================
        // PORTFOLIO LIGHTBOX
        // ===================================================

        setupPortfolioLightbox: function () {
            var self = this;
            var items = [];
            var currentIndex = 0;

            // Collect portfolio items
            function refreshItems() {
                items = [];
                $('.memdir-portfolio__item').each(function () {
                    items.push({
                        src: $(this).find('img').attr('src'),
                        caption: $(this).find('.memdir-portfolio__item-overlay').text().trim() || ''
                    });
                });
            }

            // Open lightbox
            $(document).on('click', '.memdir-portfolio__item', function (e) {
                if ($(e.target).closest('.memdir-portfolio__remove').length) return;

                refreshItems();
                // Use index among sibling .memdir-portfolio__item only (excludes upload card)
                currentIndex = $(this).parent().children('.memdir-portfolio__item').index(this);
                showLightbox(currentIndex);
            });

            function showLightbox(index) {
                if (!items[index]) return;

                var item = items[index];
                var hasNav = items.length > 1;

                // Build lightbox using jQuery for safe attribute insertion (prevents XSS)
                var $overlay = $('<div>', { 'class': 'memdir-lightbox' });
                $overlay.append($('<button>', { 'class': 'memdir-lightbox__close', 'aria-label': 'Close', text: '\u2715' }));
                $overlay.append($('<img>', { 'class': 'memdir-lightbox__img', src: item.src, alt: 'Portfolio image' }));
                if (item.caption) {
                    $overlay.append($('<div>', { 'class': 'memdir-lightbox__caption', text: item.caption }));
                }
                if (hasNav) {
                    $overlay.append($('<button>', { 'class': 'memdir-lightbox__nav memdir-lightbox__nav--prev', 'aria-label': 'Previous', text: '\u2039' }));
                    $overlay.append($('<button>', { 'class': 'memdir-lightbox__nav memdir-lightbox__nav--next', 'aria-label': 'Next', text: '\u203A' }));
                }

                $('body').append($overlay);
                $('body').css('overflow', 'hidden');
            }

            function closeLightbox() {
                var $lb = $('.memdir-lightbox');
                if ($lb.length === 0) return;
                $lb.addClass('memdir-lightbox--exit');
                setTimeout(function () {
                    $lb.remove();
                    $('body').css('overflow', '');
                }, 200);
            }

            function navigate(direction) {
                currentIndex = (currentIndex + direction + items.length) % items.length;
                var item = items[currentIndex];
                if (!item) return;
                $('.memdir-lightbox__img').attr('src', item.src);
                var $cap = $('.memdir-lightbox__caption');
                if (item.caption) {
                    if ($cap.length) {
                        $cap.text(item.caption);
                    } else {
                        // Build caption safely via jQuery
                        $('.memdir-lightbox').append($('<div>', { 'class': 'memdir-lightbox__caption', text: item.caption }));
                    }
                } else {
                    $cap.remove();
                }
            }

            // Delegated event handlers
            $(document).on('click', '.memdir-lightbox__close', closeLightbox);
            $(document).on('click', '.memdir-lightbox', function (e) {
                if ($(e.target).hasClass('memdir-lightbox')) closeLightbox();
            });
            $(document).on('click', '.memdir-lightbox__nav--prev', function () { navigate(-1); });
            $(document).on('click', '.memdir-lightbox__nav--next', function () { navigate(1); });

            // Keyboard navigation
            $(document).on('keydown', function (e) {
                if ($('.memdir-lightbox').length === 0) return;
                if (e.key === 'Escape') closeLightbox();
                if (e.key === 'ArrowLeft') navigate(-1);
                if (e.key === 'ArrowRight') navigate(1);
            });

            // Portfolio remove button (edit mode)
            $(document).on('click', '.memdir-portfolio__remove', function (e) {
                e.stopPropagation();
                var $item = $(this).closest('.memdir-portfolio__item');
                var imageId = $item.data('image-id');

                if (!confirm('Remove this image from your portfolio?')) return;

                $.ajax({
                    url: memdirData.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'memdir_remove_portfolio_image',
                        nonce: memdirData.nonce,
                        post_id: memdirData.postId,
                        image_id: imageId
                    },
                    success: function (response) {
                        if (response.success) {
                            $item.fadeOut(300, function () { $(this).remove(); });
                            self.toast('Image removed', 'success');
                        } else {
                            self.toast(response.data || 'Failed to remove image', 'error');
                        }
                    }
                });
            });

            // Portfolio upload trigger (edit mode — opens WP Media Library)
            $(document).on('click', '.memdir-portfolio__upload', function () {
                if (typeof wp === 'undefined' || !wp.media) {
                    self.toast('Media library not available', 'error');
                    return;
                }

                var frame = wp.media({
                    title: 'Add Portfolio Images',
                    multiple: true,
                    library: { type: 'image' },
                    button: { text: 'Add to Portfolio' }
                });

                frame.on('select', function () {
                    var attachments = frame.state().get('selection').toJSON();
                    var imageIds = attachments.map(function (a) { return a.id; });

                    $.ajax({
                        url: memdirData.ajaxUrl,
                        type: 'POST',
                        data: {
                            action: 'memdir_add_portfolio_images',
                            nonce: memdirData.nonce,
                            post_id: memdirData.postId,
                            image_ids: imageIds
                        },
                        success: function (response) {
                            if (response.success) {
                                // Reload the page to show new images
                                self.toast('Images added! Refreshing…', 'success');
                                setTimeout(function () { location.reload(); }, 800);
                            } else {
                                self.toast(response.data || 'Upload failed', 'error');
                            }
                        }
                    });
                });

                frame.open();
            });
        },

        /**
         * Setup the sidebar refresh button
         */
        setupRefreshButton: function () {
            $(document).on('click', '#memdir-refresh-page', function (e) {
                e.preventDefault();
                e.stopPropagation();
                window.location.reload(true);
            });
        }
    };

})(jQuery);
