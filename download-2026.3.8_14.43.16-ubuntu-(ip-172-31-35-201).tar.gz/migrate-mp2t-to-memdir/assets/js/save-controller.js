/**
 * Member Directory Save Controller
 * Intercepts ACF form submits, tracks dirty state across sections,
 * and saves ALL dirty sections via a single AJAX call.
 *
 * Dependencies: jQuery, memdirData (localized from functions-setup.php)
 */
(function ($) {
    'use strict';

    if (typeof memdirData === 'undefined' || memdirData.viewerMode !== 'edit') {
        return;
    }

    const SaveController = {

        // Track which sections have unsaved changes
        dirtySections: new Set(),

        // Prevent double-saves
        isSaving: false,

        // Map form elements to section names
        formSectionMap: new Map(),

        init() {
            this.mapFormsToSections();
            this.interceptFormSubmits();
            this.trackDirtyState();
            this.setupBeforeUnload();
            this.setupKeyboardShortcuts();
            this.createFloatingBar();
        },

        /**
         * Build a map of <form> elements → section keys
         * Each ACF form lives inside .memdir-section[data-section="xxx"]
         */
        mapFormsToSections() {
            $('.memdir-section').each((_, section) => {
                const $section = $(section);
                const sectionKey = $section.data('section') || $section.attr('id');
                const $form = $section.find('form');

                if ($form.length && sectionKey) {
                    this.formSectionMap.set($form[0], sectionKey);
                }
            });
        },

        /**
         * Intercept all ACF form submits — replace with AJAX save-all
         */
        interceptFormSubmits() {
            const self = this;

            // Intercept native form submit
            this.formSectionMap.forEach((sectionKey, formEl) => {
                $(formEl).on('submit', function (e) {
                    e.preventDefault();
                    // Mark this section dirty too (in case they just typed + hit enter)
                    self.markDirty(sectionKey);
                    self.saveAll();
                });
            });
        },

        /**
         * Track input changes across all ACF forms
         */
        trackDirtyState() {
            const self = this;

            // Listen on all form inputs inside sections
            $('.memdir-section').each(function () {
                const $section = $(this);
                const sectionKey = $section.data('section') || $section.attr('id');

                if (!sectionKey) return;

                // Standard inputs — text, textarea, select, checkbox, radio
                $section.on('input change', 'input, textarea, select', function () {
                    // Ignore PMP controls (those save via their own AJAX)
                    if ($(this).closest('.memdir-section-privacy, .memdir-pmp-buttons, .memdir-field-privacy-toggle').length) {
                        return;
                    }
                    self.markDirty(sectionKey);
                });

                // ACF-specific: image/file fields trigger change events differently
                // ACF fires `change` on hidden inputs when media is selected
                $section.on('change', '.acf-field input[type="hidden"]', function () {
                    self.markDirty(sectionKey);
                });
            });

            // Also listen for ACF's own events if available
            if (typeof acf !== 'undefined' && acf.addAction) {
                acf.addAction('change', function (field) {
                    const $section = field.$el.closest('.memdir-section');
                    const sectionKey = $section.data('section') || $section.attr('id');
                    if (sectionKey) {
                        self.markDirty(sectionKey);
                    }
                });
            }
        },

        /**
         * Mark a section as dirty — update UI indicators
         */
        markDirty(sectionKey) {
            if (this.dirtySections.has(sectionKey)) return;

            this.dirtySections.add(sectionKey);

            // Add visual indicator to section title
            const $section = $(`.memdir-section[data-section="${sectionKey}"], #${sectionKey}`);
            $section.find('.memdir-section-title').first().addClass('memdir-unsaved');

            // Add indicator to nav pill
            $(`.memdir-pill[data-section="${sectionKey}"]`).addClass('memdir-pill-unsaved');

            this.updateFloatingBar();
        },

        /**
         * Clear dirty state for a section
         */
        clearDirty(sectionKey) {
            this.dirtySections.delete(sectionKey);

            const $section = $(`.memdir-section[data-section="${sectionKey}"], #${sectionKey}`);
            $section.find('.memdir-section-title').first().removeClass('memdir-unsaved');
            $(`.memdir-pill[data-section="${sectionKey}"]`).removeClass('memdir-pill-unsaved');
        },

        /**
         * Clear all dirty states
         */
        clearAllDirty() {
            for (const key of this.dirtySections) {
                this.clearDirty(key);
            }
            this.dirtySections.clear();
            this.updateFloatingBar();
        },

        /**
         * SAVE ALL — collect data from every dirty form and POST via AJAX
         */
        saveAll() {
            if (this.isSaving || this.dirtySections.size === 0) return;

            this.isSaving = true;
            this.updateFloatingBar('saving');

            // Collect serialized data from all dirty forms
            const allFormData = new FormData();
            allFormData.append('action', 'memdir_save_all_sections');
            allFormData.append('nonce', memdirData.nonce);
            allFormData.append('post_id', memdirData.postId);

            // Gather section keys being saved
            const sectionsBeingSaved = Array.from(this.dirtySections);
            allFormData.append('sections', JSON.stringify(sectionsBeingSaved));

            // For each dirty section's form, serialize its fields
            this.formSectionMap.forEach((sectionKey, formEl) => {
                if (!this.dirtySections.has(sectionKey)) return;

                // Serialize form data using jQuery (handles ACF fields)
                const formDataArray = $(formEl).serializeArray();
                formDataArray.forEach(item => {
                    allFormData.append(item.name, item.value);
                });

                // Also grab any file inputs (ACF image fields use hidden inputs)
                $(formEl).find('input[type="hidden"]').each(function () {
                    const name = $(this).attr('name');
                    const value = $(this).val();
                    if (name && value && !allFormData.has(name)) {
                        allFormData.append(name, value);
                    }
                });
            });

            // Also capture social links form if it's dirty
            if (this.dirtySections.has('profile')) {
                const $socialInputs = $('.memdir-social-links-block input');
                $socialInputs.each(function () {
                    const name = $(this).attr('name');
                    const value = $(this).val();
                    if (name) {
                        allFormData.append('social_links[' + name + ']', value);
                    }
                });
            }

            const self = this;

            $.ajax({
                url: memdirData.ajaxUrl,
                type: 'POST',
                data: allFormData,
                processData: false,
                contentType: false,
                success(response) {
                    if (response.success) {
                        self.clearAllDirty();
                        self.updateFloatingBar('saved');
                        self.showToast('✓ All changes saved', 'success');

                        // Brief delay then hide bar
                        setTimeout(() => {
                            self.updateFloatingBar();
                        }, 2000);
                    } else {
                        self.updateFloatingBar('error');
                        self.showToast('⚠ Save failed: ' + (response.data || 'Unknown error'), 'error');
                    }
                },
                error(xhr, status, error) {
                    self.updateFloatingBar('error');
                    self.showToast('⚠ Connection error. Please try again.', 'error');
                    console.error('MEMDIR Save Error:', status, error);
                },
                complete() {
                    self.isSaving = false;
                }
            });
        },

        /**
         * Create the floating save bar (hidden by default)
         */
        createFloatingBar() {
            const bar = $(`
                <div class="memdir-save-bar" style="display: none;">
                    <div class="memdir-save-bar-inner">
                        <span class="memdir-save-bar-status">
                            <span class="memdir-save-bar-dot"></span>
                            <span class="memdir-save-bar-text"></span>
                        </span>
                        <button type="button" class="memdir-save-bar-btn">
                            Save All Changes
                        </button>
                    </div>
                </div>
            `);

            bar.find('.memdir-save-bar-btn').on('click', () => this.saveAll());
            $('body').append(bar);
        },

        /**
         * Update the floating bar based on state
         */
        updateFloatingBar(state) {
            const $bar = $('.memdir-save-bar');
            const $text = $bar.find('.memdir-save-bar-text');
            const $btn = $bar.find('.memdir-save-bar-btn');
            const $dot = $bar.find('.memdir-save-bar-dot');

            if (state === 'saving') {
                $bar.removeClass('memdir-save-bar--error memdir-save-bar--saved').addClass('memdir-save-bar--saving');
                $text.text('Saving...');
                $btn.prop('disabled', true).text('Saving...');
                $bar.slideDown(200);
                return;
            }

            if (state === 'saved') {
                $bar.removeClass('memdir-save-bar--saving memdir-save-bar--error').addClass('memdir-save-bar--saved');
                $text.text('All changes saved');
                $btn.prop('disabled', false).text('Save All Changes');
                return;
            }

            if (state === 'error') {
                $bar.removeClass('memdir-save-bar--saving memdir-save-bar--saved').addClass('memdir-save-bar--error');
                $text.text('Save failed');
                $btn.prop('disabled', false).text('Retry Save');
                return;
            }

            // Default: show/hide based on dirty count
            const count = this.dirtySections.size;
            if (count > 0) {
                $bar.removeClass('memdir-save-bar--saving memdir-save-bar--saved memdir-save-bar--error');
                const label = count === 1 ? '1 unsaved section' : count + ' unsaved sections';
                $text.text(label);
                $btn.prop('disabled', false).text('Save All Changes');
                $bar.slideDown(200);
            } else {
                $bar.slideUp(200);
            }
        },

        /**
         * Warn user before navigating away with unsaved changes
         */
        setupBeforeUnload() {
            const self = this;
            $(window).on('beforeunload', function (e) {
                if (self.dirtySections.size > 0) {
                    const msg = 'You have unsaved changes. Are you sure you want to leave?';
                    e.originalEvent.returnValue = msg;
                    return msg;
                }
            });
        },

        /**
         * Keyboard shortcuts for edit mode
         * Ctrl/Cmd + S → Save all dirty sections
         */
        setupKeyboardShortcuts() {
            const self = this;
            $(document).on('keydown', function (e) {
                const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
                const modKey = isMac ? e.metaKey : e.ctrlKey;

                // Ctrl/Cmd + S → Save
                if (modKey && !e.shiftKey && e.key === 's') {
                    e.preventDefault();
                    if (self.dirtySections.size > 0) {
                        self.saveAll();
                    } else {
                        self.showToast('No unsaved changes', 'success');
                    }
                }
            });
        },

        /**
         * Show a toast notification (uses profile-core's toast system if available)
         */
        showToast(message, type) {
            if (typeof MEMDIR_Profile !== 'undefined' && MEMDIR_Profile.toast) {
                MEMDIR_Profile.toast(message, type);
                return;
            }

            // Fallback toast (uses .text() to prevent XSS)
            const $toast = $('<div>', { 'class': 'memdir-toast memdir-toast--' + type }).text(message);
            $('body').append($toast);
            setTimeout(() => $toast.addClass('memdir-toast--visible'), 10);
            setTimeout(() => {
                $toast.removeClass('memdir-toast--visible');
                setTimeout(() => $toast.remove(), 300);
            }, 3000);
        }
    };

    // Initialize when document is ready
    $(document).ready(() => SaveController.init());

})(jQuery);
