/**
 * Member Directory Endorsements — Vouch & Trust Toggle
 *
 * Handles:
 * 1. Skill vouch toggle on taxonomy tags
 * 2. Trust-as-repair-partner toggle on profiles
 *
 * @since 1.3.0
 */
(function ($) {
    'use strict';

    // Bail if localized data isn't available
    if (typeof memdirData === 'undefined') return;

    /**
     * Show a brief toast notification using the existing memdir toast system.
     */
    function showToast(message, type) {
        type = type || 'info';

        // Ensure the toast container exists
        var $container = $('.memdir-toast-container');
        if (!$container.length) {
            $container = $('<div class="memdir-toast-container"></div>');
            $('body').append($container);
        }

        var $toast = $('<div class="memdir-toast memdir-toast--' + type + '">' + message + '</div>');
        $container.append($toast);

        // Auto-dismiss after 3s
        setTimeout(function () {
            $toast.addClass('memdir-toast--exit');
            setTimeout(function () { $toast.remove(); }, 300);
        }, 3000);
    }

    /* ── Trust Button: Initial State from DOM ───────────── */
    // On page load, check if the current user appears in the
    // trusted-by member list and set the button state accordingly.
    $(function () {
        var userId = parseInt(memdirData.userId, 10);
        if (!userId) return;

        var $btn = $('.memdir-trust-btn');
        if (!$btn.length) return;

        var isTrusted = false;
        $('.memdir-trusted-network__member[data-user-id]').each(function () {
            if (parseInt($(this).data('user-id'), 10) === userId) {
                isTrusted = true;
                return false; // break
            }
        });

        if (isTrusted && !$btn.hasClass('memdir-trust-btn--active')) {
            $btn.addClass('memdir-trust-btn--active')
                .html('<span class="memdir-trust-icon">🛡️</span> Trusted Repair Partner')
                .attr('title', 'Remove trust designation');
        }
    });

    /* ── Skill Vouch Toggle ─────────────────────────────── */

    $(document).on('click', '.memdir-vouch-btn', function (e) {
        e.preventDefault();
        e.stopPropagation(); // Don't trigger the tag's link

        var $btn = $(this);
        var $wrap = $btn.closest('.memdir-tag-vouch-wrap');

        if ($btn.prop('disabled')) return;
        $btn.prop('disabled', true).addClass('memdir-vouch-btn--loading');

        $.ajax({
            url: memdirData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'memdir_toggle_vouch',
                nonce: memdirData.vouchNonce,
                post_id: $wrap.data('post-id'),
                type: 'skill_vouch',
                term_id: $wrap.data('term-id')
            },
            success: function (response) {
                if (!response.success) {
                    showToast(response.data || 'Could not save vouch.', 'error');
                    return;
                }

                var r = response.data;

                // Toggle button state
                if (r.action === 'added') {
                    $btn.addClass('memdir-vouch-btn--active')
                        .attr('title', 'Remove your vouch')
                        .text('✓ vouched');
                } else {
                    $btn.removeClass('memdir-vouch-btn--active')
                        .attr('title', 'Vouch for this skill')
                        .text('vouch');
                }

                // Show/hide the public badge based on threshold
                var $badge = $wrap.find('.memdir-vouch-badge');
                if (r.meets_threshold) {
                    if ($badge.length) {
                        $badge.removeClass('memdir-vouch-badge--hidden');
                    } else {
                        $wrap.find('.memdir-tag').first().after(
                            '<span class="memdir-vouch-badge" title="Vouched by community members">✓</span>'
                        );
                    }
                } else {
                    $badge.addClass('memdir-vouch-badge--hidden');
                }
            },
            error: function () {
                showToast('Network error — please try again.', 'error');
            },
            complete: function () {
                $btn.prop('disabled', false).removeClass('memdir-vouch-btn--loading');
            }
        });
    });

    /* ── Trusted Repair Partner Toggle ───────────────────── */

    $(document).on('click', '.memdir-trust-btn', function (e) {
        e.preventDefault();

        var $btn = $(this);
        if ($btn.prop('disabled')) return;
        $btn.prop('disabled', true).addClass('memdir-trust-btn--loading');

        $.ajax({
            url: memdirData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'memdir_toggle_vouch',
                nonce: memdirData.vouchNonce,
                post_id: $btn.data('post-id'),
                type: 'trusted_repair',
                term_id: 0
            },
            success: function (response) {
                if (!response.success) {
                    showToast(response.data || 'Could not update trust.', 'error');
                    return;
                }

                var r = response.data;

                if (r.action === 'added') {
                    $btn.addClass('memdir-trust-btn--active')
                        .html('<span class="memdir-trust-icon">🛡️</span> Trusted Repair Partner')
                        .attr('title', 'Remove trust designation');
                    showToast('Trust designation added.', 'success');
                } else {
                    $btn.removeClass('memdir-trust-btn--active')
                        .html('<span class="memdir-trust-icon">🤝</span> Trust as Repair Partner')
                        .attr('title', 'Designate as a trusted repair partner for your instruments');
                    showToast('Trust designation removed.', 'info');
                }
            },
            error: function () {
                showToast('Network error — please try again.', 'error');
            },
            complete: function () {
                $btn.prop('disabled', false).removeClass('memdir-trust-btn--loading');
            }
        });
    });

})(jQuery);
