/**
 * Member Directory — Interactive Map View
 *
 * Architecture for scale:
 *  - Leaflet.js + MarkerCluster for 10,000+ pin support
 *  - Canvas renderer (not SVG) for heavy marker counts
 *  - GeoJSON data loaded via AJAX (cached server-side as transient)
 *  - Lazy initialization — map only loads when user clicks "Map" toggle
 *  - Cluster spiderfying for overlapping pins at zoom
 *
 * Dependencies: Leaflet.js, Leaflet.markercluster (loaded from CDN)
 */

(function ($) {
    'use strict';

    const MEMDIR_Map = {

        map: null,
        clusterGroup: null,
        allMarkers: [],   // Every marker (never mutated after load)
        markers: [],      // Currently visible markers (after filtering)
        initialized: false,
        loading: false,

        /**
         * Initialize map view — called once when user first clicks Map toggle
         */
        init: function () {
            if (this.initialized || this.loading) return;
            this.loading = true;

            const self = this;
            const $container = $('#memdir-map-container');

            if (!$container.length) {
                this.loading = false;
                return;
            }

            // Show loading state
            $container.html(
                '<div class="memdir-map-loading">' +
                '<div class="memdir-map-spinner"></div>' +
                '<span>Loading member map…</span>' +
                '</div>'
            );

            // Load Leaflet CSS + JS from CDN (only when needed)
            this.loadDependencies(function () {
                self.createMap($container[0]);
                self.loadMemberData();
            });
        },

        /**
         * Dynamically load Leaflet + MarkerCluster from CDN
         * Only downloads when user actually opens map view — zero overhead otherwise
         *
         * Loading order matters:
         *  1. All CSS (parallel — no dependencies)
         *  2. Leaflet.js (must load before MarkerCluster)
         *  3. leaflet.markercluster.js (depends on L being defined)
         */
        loadDependencies: function (callback) {
            var self = this;

            // Helper: load a single <link> tag
            function loadCSS(url) {
                var link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = url;
                document.head.appendChild(link);
            }

            // Helper: load a single <script> tag, call cb when done
            function loadJS(url, cb) {
                var script = document.createElement('script');
                script.src = url;
                script.onload = function () {
                    console.log('[MEMDIR Map] Loaded:', url);
                    cb();
                };
                script.onerror = function () {
                    console.error('[MEMDIR Map] Failed to load:', url);
                    cb(); // Continue even on error to avoid hanging
                };
                document.head.appendChild(script);
            }

            // Phase 1: Load all CSS (no blocking, no waiting)
            loadCSS('https://unpkg.com/leaflet@1.9.4/dist/leaflet.css');
            loadCSS('https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css');
            loadCSS('https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css');

            // Phase 2: Load Leaflet.js first
            loadJS('https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', function () {
                // Phase 3: Then load MarkerCluster (depends on L)
                loadJS('https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js', function () {
                    console.log('[MEMDIR Map] All dependencies loaded');
                    callback();
                });
            });
        },

        /**
         * Create the Leaflet map instance with Canvas renderer
         */
        createMap: function (container) {
            // Clear loading state
            container.innerHTML = '';

            // Create map with Canvas renderer for performance
            this.map = L.map(container, {
                preferCanvas: true,       // Canvas > SVG for many markers
                zoomControl: true,
                scrollWheelZoom: true,
                attributionControl: true,
            }).setView([39.8283, -98.5795], 4); // Center on US

            // OpenStreetMap tiles (free, no API key)
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
                maxZoom: 18,
            }).addTo(this.map);

            // MarkerCluster group — the performance magic
            this.clusterGroup = L.markerClusterGroup({
                maxClusterRadius: 50,          // Cluster within 50px
                spiderfyOnMaxZoom: true,       // Spread overlapping at max zoom
                showCoverageOnHover: false,     // Less visual noise
                zoomToBoundsOnClick: true,      // Zoom into cluster on click
                chunkedLoading: true,           // Load markers in batches (no UI freeze)
                chunkInterval: 200,             // ms between batches
                chunkDelay: 50,                 // ms delay per chunk
                disableClusteringAtZoom: 16,    // Show individual pins at street level
                animate: true,
                // Custom cluster icon for sage/green branding
                iconCreateFunction: function (cluster) {
                    const count = cluster.getChildCount();
                    let size = 'small';
                    if (count >= 100) size = 'large';
                    else if (count >= 10) size = 'medium';

                    return L.divIcon({
                        html: '<div class="memdir-cluster-inner">' + count + '</div>',
                        className: 'memdir-cluster memdir-cluster--' + size,
                        iconSize: L.point(40, 40),
                    });
                }
            });

            this.map.addLayer(this.clusterGroup);
            this.initialized = true;
        },

        /**
         * Fetch member location data via AJAX (server caches as transient)
         */
        loadMemberData: function () {
            const self = this;

            $.ajax({
                url: memdirArchiveData.ajaxUrl,
                type: 'GET',
                data: {
                    action: 'memdir_get_map_data',
                    nonce: memdirArchiveData.nonce,
                },
                dataType: 'json',
                success: function (response) {
                    console.log('[MEMDIR Map] AJAX response:', response);
                    if (response.success && response.data && response.data.members) {
                        console.log('[MEMDIR Map] Members with location:', response.data.members.length);
                        self.addMarkers(response.data.members);
                    } else {
                        console.warn('[MEMDIR Map] No members in response:', response);
                        self.showEmptyState();
                    }
                    self.loading = false;
                },
                error: function (xhr, status, error) {
                    console.error('[MEMDIR Map] AJAX error:', status, error, xhr.responseText);
                    self.showEmptyState('Error loading map data. Please try again.');
                    self.loading = false;
                }
            });
        },

        /**
         * Add markers to the cluster group in one batch
         * This is where MarkerCluster shines — it indexes spatially
         * and renders only visible clusters, handling 50k+ pins smoothly
         */
        addMarkers: function (members) {
            if (!members.length) {
                this.showEmptyState();
                return;
            }

            console.log('[MEMDIR Map] Adding', members.length, 'markers');

            const markers = [];

            for (let i = 0; i < members.length; i++) {
                const m = members[i];
                if (!m.lat || !m.lng) continue;

                const marker = L.marker([m.lat, m.lng], {
                    icon: L.divIcon({
                        className: 'memdir-map-pin',
                        html: '<div class="memdir-map-pin__dot"></div>',
                        iconSize: [24, 24],
                        iconAnchor: [12, 12],
                        popupAnchor: [0, -14],
                    })
                });

                // Store member data on the marker for filtering + lazy popup
                marker._memdirData = {
                    id: m.id,
                    name: (m.name || '').toLowerCase(),
                    // Pre-convert taxonomy arrays to Sets for O(1) lookups
                    terms: {},
                    // Raw member data for lazy popup construction
                    raw: m
                };

                // Build Set-based term index for fast filtering
                var mTerms = m.terms || {};
                for (var tax in mTerms) {
                    if (mTerms.hasOwnProperty(tax) && Array.isArray(mTerms[tax])) {
                        marker._memdirData.terms[tax] = new Set(mTerms[tax]);
                    }
                }

                // Lazy popup: bind click handler to build HTML on demand
                // Saves ~2MB of pre-built HTML strings at 5,000 markers
                (function (mkr) {
                    mkr.on('click', function () {
                        if (!mkr.getPopup()) {
                            var d = mkr._memdirData.raw;
                            var popup = '<div class="memdir-map-popup">';
                            if (d.avatar) {
                                popup += '<img class="memdir-map-popup__avatar" src="' + d.avatar + '" alt="" loading="lazy" />';
                            }
                            popup += '<div class="memdir-map-popup__info">';
                            popup += '<a class="memdir-map-popup__name" href="' + d.url + '">' + d.name + '</a>';
                            if (d.tagline) {
                                popup += '<span class="memdir-map-popup__tagline">' + d.tagline + '</span>';
                            }
                            if (d.location) {
                                popup += '<span class="memdir-map-popup__location">📍 ' + d.location + '</span>';
                            }
                            popup += '</div></div>';
                            mkr.bindPopup(popup, {
                                maxWidth: 280,
                                minWidth: 200,
                                className: 'memdir-map-popup-wrapper'
                            });
                        }
                        mkr.openPopup();
                    });
                })(marker);

                markers.push(marker);
            }

            // Store all markers permanently (never mutated)
            this.allMarkers = markers;
            this.markers = markers;

            // Bulk-add to cluster group (single DOM operation)
            this.clusterGroup.addLayers(markers);

            // Fit map bounds to show all markers
            this.fitBoundsToMarkers(markers);

            // Apply any existing sidebar filters immediately
            this.filterMarkers();
        },

        /**
         * Fit map bounds to the given markers
         */
        fitBoundsToMarkers: function (markers) {
            if (markers.length > 0) {
                const group = L.featureGroup(markers);
                this.map.fitBounds(group.getBounds().pad(0.1), {
                    maxZoom: 12
                });
            }
        },

        /**
         * Filter visible map markers based on sidebar checkboxes and search input.
         * Reads the same filter controls that directory-search.js uses.
         *
         * Logic: AND between taxonomies, OR within a taxonomy.
         * e.g. (Instruments=Banjo OR Guitar) AND (Services=Repair)
         */
        filterMarkers: function () {
            if (!this.initialized || !this.allMarkers.length) return;

            // 1. Collect active taxonomy filters from sidebar checkboxes
            var activeFilters = {};
            var filterCount = 0;
            $('.memdir-filter-section[data-taxonomy]').each(function () {
                var taxonomy = $(this).data('taxonomy');
                var checked = [];
                $(this).find('input[type="checkbox"]:checked').each(function () {
                    checked.push(parseInt($(this).val(), 10));
                });
                if (checked.length > 0) {
                    activeFilters[taxonomy] = new Set(checked);
                    filterCount++;
                }
            });

            // 2. Collect search text
            var searchText = ($('#memdir-search-input').val() || '').trim().toLowerCase();

            var hasFilters = filterCount > 0 || searchText.length > 0;

            // 3. If no filters, show everything (fast path: no per-marker iteration)
            if (!hasFilters) {
                if (this.markers !== this.allMarkers) {
                    this.clusterGroup.clearLayers();
                    this.clusterGroup.addLayers(this.allMarkers);
                    this.markers = this.allMarkers;
                }
                return;
            }

            // 4. Filter markers — Set.has() for O(1) term lookups
            var visible = [];
            var activeTaxonomies = Object.keys(activeFilters);
            var taxCount = activeTaxonomies.length;

            for (var i = 0; i < this.allMarkers.length; i++) {
                var marker = this.allMarkers[i];
                var data = marker._memdirData;
                var match = true;

                // Text search filter (short-circuit first — cheapest check)
                if (searchText.length > 0 && data.name.indexOf(searchText) === -1) {
                    match = false;
                }

                // Taxonomy filters: AND between taxonomies, OR within
                if (match && taxCount > 0) {
                    for (var t = 0; t < taxCount; t++) {
                        var tax = activeTaxonomies[t];
                        var requiredTerms = activeFilters[tax]; // Set
                        var memberTerms = data.terms[tax]; // Set or undefined

                        if (!memberTerms || memberTerms.size === 0) {
                            match = false;
                            break;
                        }

                        // Check if member has ANY of the required terms
                        var hasAny = false;
                        requiredTerms.forEach(function (termId) {
                            if (memberTerms.has(termId)) hasAny = true;
                        });
                        if (!hasAny) {
                            match = false;
                            break;
                        }
                    }
                }

                if (match) {
                    visible.push(marker);
                }
            }

            console.log('[MEMDIR Map] Filter result:', visible.length, '/', this.allMarkers.length, 'visible');

            // 5. Rebuild cluster group with filtered markers
            this.clusterGroup.clearLayers();
            this.clusterGroup.addLayers(visible);
            this.markers = visible;

            // 6. Fit bounds to visible markers (if any)
            if (visible.length > 0) {
                this.fitBoundsToMarkers(visible);
            }
        },

        /**
         * Show empty/error state
         */
        showEmptyState: function (message) {
            const $container = $('#memdir-map-container');
            message = message || 'No members with location data found.';
            $container.html(
                '<div class="memdir-map-empty">' +
                '<span class="memdir-map-empty__icon">🗺️</span>' +
                '<p>' + message + '</p>' +
                '</div>'
            );
        },

        /**
         * Refresh map size (needed when container becomes visible after being hidden)
         */
        invalidateSize: function () {
            if (this.map) {
                setTimeout(function () {
                    this.map.invalidateSize();
                }.bind(this), 100);
            }
        },

        /**
         * Destroy the map instance (cleanup)
         */
        destroy: function () {
            if (this.map) {
                this.map.remove();
                this.map = null;
                this.clusterGroup = null;
                this.markers = [];
                this.initialized = false;
            }
        }
    };

    // Expose globally for the layout toggle to call
    window.MEMDIR_Map = MEMDIR_Map;

    // --- Wire sidebar filter events to map filtering ---
    // These fire in addition to the existing directory-search.js handlers

    // Taxonomy checkbox changes
    $(document).on('change', '.memdir-filter-checkbox input', function () {
        if (MEMDIR_Map.initialized) {
            MEMDIR_Map.filterMarkers();
        }
    });

    // Search text input (debounced)
    var mapSearchTimer = null;
    $('#memdir-search-input').on('input', function () {
        clearTimeout(mapSearchTimer);
        mapSearchTimer = setTimeout(function () {
            if (MEMDIR_Map.initialized) {
                MEMDIR_Map.filterMarkers();
            }
        }, 300);
    });

    // Clear all filters button
    $(document).on('click', '.memdir-clear-filters', function () {
        if (MEMDIR_Map.initialized) {
            // Small delay so checkboxes clear first
            setTimeout(function () {
                MEMDIR_Map.filterMarkers();
            }, 50);
        }
    });

})(jQuery);
