/**
 * Member Directory - PMP Privacy Controls
 * Handles all Privacy Management Panel interactions.
 * Only loaded in edit mode (profile owner).
 * 
 * Depends on: profile-core.js (for MEMDIR_Profile.showSaveIndicator)
 */

(function ($) {
    'use strict';

    window.MEMDIR_PMP = {

        /**
         * Initialize all PMP interactions
         */
        init: function () {
            this.setupPMPButtons();
            this.setupSectionToggles();
            this.setupSectionPrivacyToggles();
            this.setupFieldPrivacyBadges();
            this.setupHeaderPreference();
        },

        /**
         * Setup PMP button clicks (privacy controls)
         */
        setupPMPButtons: function () {
            $('.memdir-pmp-btn').on('click', function (e) {
                e.preventDefault();

                const $btn = $(this);
                const value = $btn.data('value');
                const field = $btn.data('field');

                // Update button states
                $btn.siblings('.memdir-pmp-btn').removeClass('active');
                $btn.addClass('active');

                // Update the underlying ACF field if it exists (for form submission)
                const $acfField = $('.acf-field[data-name="' + field + '"] select');
                if ($acfField.length) {
                    $acfField.val(value).trigger('change');
                }

                // Save via AJAX (for immediate save without form submission)
                MEMDIR_PMP.savePMPValue(field, value);
            });
        },

        /**
         * Setup section enable/disable toggles
         */
        setupSectionToggles: function () {
            $('.memdir-section-toggle').on('change', function () {
                const $toggle = $(this);
                const section = $toggle.data('section');
                const enabled = $toggle.is(':checked');

                // Save via AJAX
                MEMDIR_PMP.saveSectionEnabled(section, enabled);
            });
        },

        /**
         * Setup section privacy mode toggles (Adopt Global / Override Section)
         */
        setupSectionPrivacyToggles: function () {

            // Initial state - sync each section's hidden ACF field with current toggle state
            $('.memdir-section-privacy').each(function () {
                const $privacy = $(this);
                const $activeBtn = $privacy.find('.memdir-section-privacy-toggle .memdir-toggle-btn.active');
                if ($activeBtn.length) {
                    const initialMode = $activeBtn.data('mode');
                    const section = $activeBtn.data('section');
                    // ACF field name for this section's PMP mode (resolved from PHP field map)
                    const acfFieldName = memdirData.pmpFields[section] ? memdirData.pmpFields[section].mode : '';
                    const $hiddenField = $('.acf-field[data-name="' + acfFieldName + '"] input[type="radio"][value="' + initialMode + '"]');
                    if ($hiddenField.length) {
                        $hiddenField.prop('checked', true);
                    }
                }
            });

            // Handle toggle clicks
            $('.memdir-section-privacy-toggle .memdir-toggle-btn').on('click', function (e) {
                e.preventDefault();

                const $btn = $(this);
                const mode = $btn.data('mode'); // 'adopt' or 'override'
                const section = $btn.data('section');

                // Update button states
                $btn.siblings('.memdir-toggle-btn').removeClass('active');
                $btn.addClass('active');

                // CRITICAL: Update the hidden ACF field so form submission preserves our value
                // Resolved from PHP field map (no hardcoded prefix)
                const acfFieldName = memdirData.pmpFields[section] ? memdirData.pmpFields[section].mode : '';
                const $hiddenField = $('.acf-field[data-name="' + acfFieldName + '"] input[type="radio"][value="' + mode + '"]');
                if ($hiddenField.length) {
                    $hiddenField.prop('checked', true).trigger('change');
                }

                // Update UI based on mode — scoped to this section only
                const $section = $btn.closest('.memdir-section');
                MEMDIR_PMP.updateSectionPrivacyUI(mode, $section);

                // Save via AJAX (for immediate save without form submission)
                MEMDIR_PMP.saveSectionPrivacyMode(section, mode);
            });
        },

        /**
         * Update section privacy UI based on mode
         */
        updateSectionPrivacyUI: function (mode, $section) {
            // Scope to the specific section container, or fall back to all sections
            const $context = $section ? $section : $(document);
            const $sectionPrivacy = $context.find('.memdir-section-privacy');

            if (mode === 'adopt') {
                // Hide section PMP buttons, show helper text
                $sectionPrivacy.find('.memdir-pmp-buttons').hide();
                $sectionPrivacy.find('.memdir-helper-text').show();

                // Hide field-level privacy controls within this section
                $context.find('.acf-field[data-name*="memdir_pmp_override"]').hide();
                $context.find('.acf-field[data-name*="memdir_pmp_value"]').hide();

            } else {
                // Show section PMP buttons, hide helper text
                $sectionPrivacy.find('.memdir-pmp-buttons').show();
                $sectionPrivacy.find('.memdir-helper-text').hide();

                // Show field-level privacy override toggles within this section
                $context.find('.acf-field[data-name*="memdir_pmp_override"]').show();

                // Setup listeners for privacy override checkboxes
                // MEMDIR_PMP.setupFieldPrivacyOverrides(); // This is no longer needed with badges
            }
        },

        /**
         * Setup inline field privacy badge clicks and popover.
         * Injects badges into ACF form fields by scanning .acf-field elements.
         */
        setupFieldPrivacyBadges: function () {
            var self = this;
            var states = memdirData.fieldPrivacyStates || {};

            // No field states = nothing to badge
            if ($.isEmptyObject(states)) {
                return;
            }

            var iconMap = { public: '🌐', members: '👥', private: '🔒' };
            var defaultIcon = '👓';

            // Privacy options for the popover
            var options = [
                { value: 'public', icon: '🌐', label: 'Public' },
                { value: 'members', icon: '👥', label: 'Members Only' },
                { value: 'private', icon: '🔒', label: 'Private' },
                { value: 'inherit', icon: '👓', label: 'Inherit Section' }
            ];

            // Inject a badge into each recognized ACF field
            $('.acf-field').each(function () {
                var $field = $(this);
                var fieldName = $field.attr('data-name');

                // Only badge content fields we know about
                if (!fieldName || !states[fieldName]) {
                    return;
                }

                var state = states[fieldName];
                var currentValue = state.hasOverride ? state.value : 'inherit';
                var icon = state.hasOverride ? (iconMap[state.value] || defaultIcon) : defaultIcon;

                // Build the badge button
                var $badge = $('<button type="button" class="memdir-field-privacy-badge"'
                    + ' data-field="' + fieldName + '"'
                    + ' data-section="' + state.section + '"'
                    + ' data-privacy-state="' + currentValue + '"'
                    + '>'
                    + '<span class="memdir-field-privacy-badge__icon">' + icon + '</span>'
                    + '</button>');

                // Inject into the ACF field label area
                var $label = $field.find('> .acf-label');
                if ($label.length) {
                    $label.css('position', 'relative');
                    $label.append($badge);
                } else {
                    // Fallback: prepend to the field itself
                    $field.css('position', 'relative');
                    $field.prepend($badge);
                }
            });

            // Badge click handler — toggle popover
            $(document).on('click', '.memdir-field-privacy-badge', function (e) {
                e.preventDefault();
                e.stopPropagation();

                var $badge = $(this);
                var currentState = $badge.attr('data-privacy-state');

                // Remove any existing popover
                $('.memdir-privacy-popover').remove();

                // Build popover HTML
                var html = '<div class="memdir-privacy-popover">';
                html += '<div class="memdir-privacy-popover__header">Field Visibility</div>';
                options.forEach(function (opt) {
                    var activeClass = (currentState === opt.value) ? ' memdir-privacy-popover__option--active' : '';
                    html += '<button type="button" class="memdir-privacy-popover__option' + activeClass + '" data-value="' + opt.value + '">';
                    html += '<span class="memdir-privacy-popover__icon">' + opt.icon + '</span>';
                    html += '<span class="memdir-privacy-popover__label">' + opt.label + '</span>';
                    html += '</button>';
                });
                html += '</div>';

                var $popover = $(html);

                // Append to the badge's parent so it positions relative to the label
                $badge.parent().append($popover);

                // Position below the badge
                var badgePos = $badge.position();
                $popover.css({
                    position: 'absolute',
                    top: badgePos.top + $badge.outerHeight() + 4,
                    right: 0,
                    zIndex: 1000
                });

                // Animate in
                requestAnimationFrame(function () {
                    $popover.addClass('memdir-privacy-popover--visible');
                });
            });

            // Popover option click
            $(document).on('click', '.memdir-privacy-popover__option', function (e) {
                e.preventDefault();
                e.stopPropagation();

                var $option = $(this);
                var value = $option.data('value');
                var $popover = $option.closest('.memdir-privacy-popover');
                var $badge = $popover.siblings('.memdir-field-privacy-badge');
                if (!$badge.length) {
                    $badge = $popover.parent().find('.memdir-field-privacy-badge');
                }
                var field = $badge.attr('data-field');

                // Determine if setting override or clearing it
                var enabled = (value !== 'inherit') ? 1 : 0;
                var sendValue = (value !== 'inherit') ? value : '';

                // Update the badge immediately (optimistic update)
                var newIcon = (value !== 'inherit') ? (iconMap[value] || defaultIcon) : defaultIcon;
                $badge.find('.memdir-field-privacy-badge__icon').text(newIcon);
                $badge.attr('data-privacy-state', value);

                // Remove popover
                $popover.removeClass('memdir-privacy-popover--visible');
                setTimeout(function () { $popover.remove(); }, 200);

                // Save via AJAX
                self.saveFieldPrivacyOverride(field, enabled, sendValue);
            });

            // Close popover on outside click
            $(document).on('click', function (e) {
                if (!$(e.target).closest('.memdir-privacy-popover, .memdir-field-privacy-badge').length) {
                    $('.memdir-privacy-popover').remove();
                }
            });
        },


        /**
         * Setup header preference dropdown (business vs personal)
         */
        setupHeaderPreference: function () {
            $('.memdir-header-pref-select').on('change', function () {
                var value = $(this).val();

                // Update the data attribute immediately so switchHeader picks it up
                $('.memdir-wrap').data('default-header', value);

                $.ajax({
                    url: memdirData.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'memdir_save_default_header',
                        nonce: memdirData.nonce,
                        post_id: memdirData.postId,
                        value: value
                    },
                    success: function (response) {
                        if (response.success) {
                            MEMDIR_Profile.showSaveIndicator();
                            var label = value === 'business' ? 'Business' : 'Personal';
                            MEMDIR_Profile.toast('Default header set to ' + label, 'success');
                        }
                    },
                    error: function () {
                        alert('Error saving header preference. Please try again.');
                    }
                });
            });
        },

        /**
         * Save PMP value via AJAX
         */
        savePMPValue: function (field, value) {
            $.ajax({
                url: memdirData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'memdir_save_pmp',
                    nonce: memdirData.nonce,
                    post_id: memdirData.postId,
                    field: field,
                    value: value
                },
                success: function (response) {
                    if (response.success) {
                        MEMDIR_Profile.showSaveIndicator();

                        // Check if this is the global default field
                        if (field === memdirData.globalPrivacyField) {
                            MEMDIR_PMP.updateGlobalDefaultHelpers(value);
                        }
                    }
                },
                error: function () {
                    alert('Error saving privacy setting. Please try again.');
                }
            });
        },

        /**
         * Update global default helper text in all sections
         */
        updateGlobalDefaultHelpers: function (newValue) {
            // Capitalize first letter for display
            const displayValue = newValue.charAt(0).toUpperCase() + newValue.slice(1);

            // Update ALL helper texts (including hidden ones in override mode)
            // so they show the correct value when switched back to adopt mode
            $('.memdir-helper-text').each(function () {
                $(this).empty().append('Using Global Default: ').append($('<strong>').text(displayValue));
            });
        },

        /**
         * Save section enabled state via AJAX
         */
        saveSectionEnabled: function (section, enabled) {
            $.ajax({
                url: memdirData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'memdir_save_section_enabled',
                    nonce: memdirData.nonce,
                    post_id: memdirData.postId,
                    section: section,
                    enabled: enabled ? 1 : 0
                },
                success: function (response) {
                    if (response.success) {
                        MEMDIR_Profile.showSaveIndicator();
                        // Reload page to update nav pills
                        setTimeout(function () {
                            location.reload();
                        }, 500);
                    }
                },
                error: function () {
                    alert('Error toggling section. Please try again.');
                }
            });
        },

        /**
         * Save section privacy mode via AJAX
         */
        saveSectionPrivacyMode: function (section, mode) {
            $.ajax({
                url: memdirData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'memdir_save_section_privacy_mode',
                    nonce: memdirData.nonce,
                    post_id: memdirData.postId,
                    section: section,
                    mode: mode
                },
                success: function (response) {
                    if (response.success) {
                        MEMDIR_Profile.showSaveIndicator();
                    }
                },
                error: function () {
                    alert('Error saving privacy mode. Please try again.');
                }
            });
        },

        /**
         * Save field privacy override via AJAX
         */
        saveFieldPrivacyOverride: function (field, enabled, value) {
            var data = {
                action: 'memdir_save_field_privacy_override',
                nonce: memdirData.nonce,
                post_id: memdirData.postId,
                field: field,
                enabled: enabled ? 1 : 0
            };
            if (value) {
                data.value = value;
            }
            $.ajax({
                url: memdirData.ajaxUrl,
                type: 'POST',
                data: data,
                success: function (response) {
                    if (response.success) {
                        if (typeof MEMDIR_Profile !== 'undefined' && MEMDIR_Profile.showSaveIndicator) {
                            MEMDIR_Profile.showSaveIndicator();
                        }
                    }
                },
                error: function () {
                    alert('Error saving field privacy. Please try again.');
                }
            });
        }
    };

})(jQuery);
