<?php
/**
 * Profile Completeness Widget
 * Gamified progress bar with milestones and actionable suggestions.
 *
 * Required query var: memdir_post_id
 */

if (!defined('ABSPATH'))
    exit;

$post_id = get_query_var('memdir_post_id');
$viewer_mode = get_query_var('memdir_viewer_mode');

// Only show in edit mode
if ($viewer_mode !== 'edit') {
    return;
}

$result = Memdir_Profile_Completeness::calculate($post_id);
$percentage = $result['percentage'];
$suggestions = $result['suggestions'];

// Gamified tier system
if ($percentage >= 100) {
    $color_class = 'memdir-completeness--high';
    $emoji = '🏆';
    $tier_label = 'All-Star';
} elseif ($percentage >= 80) {
    $color_class = 'memdir-completeness--high';
    $emoji = '🎯';
    $tier_label = 'Almost there!';
} elseif ($percentage >= 50) {
    $color_class = 'memdir-completeness--mid';
    $emoji = '📈';
    $tier_label = 'Growing';
} elseif ($percentage >= 25) {
    $color_class = 'memdir-completeness--low';
    $emoji = '🌱';
    $tier_label = 'Newcomer';
} else {
    $color_class = 'memdir-completeness--low';
    $emoji = '🚀';
    $tier_label = 'Getting Started';
}

// Check if user dismissed
$dismissed = get_user_meta(get_current_user_id(), 'memdir_completeness_dismissed', true);
if ($dismissed && $percentage >= 80) {
    return; // Only stay dismissed if profile is fairly complete
}

?>

<div class="memdir-completeness <?php echo esc_attr($color_class); ?>">
    <div class="memdir-completeness__header">
        <span class="memdir-completeness__emoji">
            <?php echo $emoji; ?>
        </span>
        <div>
            <h4 class="memdir-completeness__title">Profile Strength</h4>
            <span class="memdir-completeness__tier"><?php echo esc_html($tier_label); ?></span>
        </div>
    </div>

    <div class="memdir-completeness__bar-container">
        <div class="memdir-completeness__bar" style="width: <?php echo esc_attr($percentage); ?>%;">
            <span class="memdir-completeness__percent">
                <?php echo esc_html($percentage); ?>%
            </span>
        </div>
    </div>

    <p class="memdir-completeness__summary">
        <?php echo esc_html($result['completed']); ?> of
        <?php echo esc_html($result['total']); ?> fields completed
    </p>

    <?php if (!empty($suggestions) && $percentage < 100): ?>
        <div class="memdir-completeness__suggestions">
            <p class="memdir-completeness__suggestions-title">
                <?php if ($percentage < 30): ?>
                    🎯 Quick wins to boost your profile:
                <?php elseif ($percentage < 70): ?>
                    💡 Next steps to level up:
                <?php else: ?>
                    ✨ Final touches:
                <?php endif; ?>
            </p>
            <ul>
                <?php foreach ($suggestions as $suggestion): ?>
                    <li>
                        <?php echo esc_html($suggestion); ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php elseif ($percentage >= 100): ?>
        <p class="memdir-completeness__complete">🎉 Your profile is complete! You're discoverable by the whole community.</p>
    <?php endif; ?>

    <!-- Per-section breakdown (collapsed by default) -->
    <details class="memdir-completeness__details">
        <summary>Section breakdown</summary>
        <div class="memdir-completeness__sections">
            <?php foreach ($result['sections'] as $key => $section): ?>
                <div class="memdir-completeness__section-row">
                    <span class="memdir-completeness__section-label">
                        <?php echo esc_html($section['label']); ?>
                    </span>
                    <span class="memdir-completeness__section-value">
                        <?php echo esc_html($section['filled']); ?>/
                        <?php echo esc_html($section['total']); ?>
                    </span>
                    <div class="memdir-completeness__mini-bar">
                        <div class="memdir-completeness__mini-fill"
                            style="width: <?php echo esc_attr($section['percent']); ?>%;"></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </details>
</div>