<?php
/**
 * Trusted Network Component
 *
 * Displays trust relationships on a member profile:
 * 1. "Trusted by X builders" — other members who trust this person
 * 2. "Trusted Repair Network" — luthiers this member trusts
 * 3. A "Trust as Repair Partner" button for logged-in members
 *
 * Only shown on non-edit views. Hidden if no trust data exists
 * AND the viewer can't add trust (not logged-in or is own profile).
 *
 * @since 1.3.0
 */

if (!defined('ABSPATH'))
    exit;

if (!class_exists('Memdir_Endorsements')) {
    return;
}

$post_id = get_query_var('memdir_post_id');
$viewer_mode = get_query_var('memdir_viewer_mode');

$post_author = (int) get_post_field('post_author', $post_id);
$current_user = get_current_user_id();
$is_own_profile = ($current_user === $post_author);

// Hide on own profile in edit mode (the vouch-summary handles edit-mode feedback)
if ($viewer_mode === 'edit' && $is_own_profile) {
    return;
}

// Get trust data
$trusted_by = Memdir_Endorsements::get_trusted_by($post_id);
$trust_network = Memdir_Endorsements::get_trust_network($post_author);

// Check if viewer has already trusted this person by scanning the data we already fetched
$viewer_has_trusted = false;
if ($current_user && !$is_own_profile && !empty($trusted_by)) {
    foreach ($trusted_by as $builder) {
        if (isset($builder['user_id']) && (int) $builder['user_id'] === $current_user) {
            $viewer_has_trusted = true;
            break;
        }
    }
}

// Determine if viewer can trust (logged-in, not own profile)
$can_trust = ($current_user > 0 && !$is_own_profile);

// Don't render anything if there's no data and no ability to act
if (empty($trusted_by) && empty($trust_network) && !$can_trust) {
    return;
}
?>

<section class="memdir-trusted-network">
    <h3 class="memdir-trusted-network__title">Trusted Network</h3>

    <?php if (!empty($trusted_by)): ?>
        <div class="memdir-trusted-network__section">
            <h4 class="memdir-trusted-network__subtitle">
                🛡️ Trusted by
                <?php echo count($trusted_by); ?>
                <?php echo count($trusted_by) === 1 ? 'builder' : 'builders'; ?>
            </h4>
            <p class="memdir-trusted-network__count">
                These builders trust this luthier to service their instruments.
            </p>
            <div class="memdir-trusted-network__list">
                <?php foreach ($trusted_by as $builder): ?>
                    <a href="<?php echo esc_url($builder['url']); ?>" class="memdir-trusted-network__member"
                        data-user-id="<?php echo esc_attr($builder['user_id']); ?>">
                        <?php if (!empty($builder['avatar'])): ?>
                            <img class="memdir-trusted-network__avatar" src="<?php echo esc_url($builder['avatar']); ?>"
                                alt="<?php echo esc_attr($builder['name']); ?>" loading="lazy" />
                        <?php endif; ?>
                        <span class="memdir-trusted-network__name">
                            <?php echo esc_html($builder['name']); ?>
                        </span>
                        <?php if (!empty($builder['location'])): ?>
                            <span class="memdir-trusted-network__member-location">
                                📍 <?php echo esc_html($builder['location']); ?>
                            </span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if (!empty($trust_network)): ?>
        <div class="memdir-trusted-network__section">
            <h4 class="memdir-trusted-network__subtitle">
                🔧 Trusted Repair Network
            </h4>
            <p class="memdir-trusted-network__count">
                For service on my instruments, I trust:
            </p>
            <div class="memdir-trusted-network__list">
                <?php foreach ($trust_network as $luthier): ?>
                    <a href="<?php echo esc_url($luthier['url']); ?>" class="memdir-trusted-network__member">
                        <?php if (!empty($luthier['avatar'])): ?>
                            <img class="memdir-trusted-network__avatar" src="<?php echo esc_url($luthier['avatar']); ?>"
                                alt="<?php echo esc_attr($luthier['name']); ?>" loading="lazy" />
                        <?php endif; ?>
                        <span class="memdir-trusted-network__name">
                            <?php echo esc_html($luthier['name']); ?>
                        </span>
                        <?php if (!empty($luthier['location'])): ?>
                            <span class="memdir-trusted-network__member-location">
                                📍 <?php echo esc_html($luthier['location']); ?>
                            </span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($can_trust): ?>
        <div class="memdir-trusted-network__action">
            <button type="button" class="memdir-trust-btn <?php echo $viewer_has_trusted ? 'memdir-trust-btn--active' : ''; ?>"
                data-post-id="<?php echo esc_attr($post_id); ?>"
                title="<?php echo $viewer_has_trusted ? 'Remove trust designation' : 'Designate as a trusted repair partner for your instruments'; ?>">
                <?php if ($viewer_has_trusted): ?>
                    <span class="memdir-trust-icon">🛡️</span> Trusted Repair Partner
                <?php else: ?>
                    <span class="memdir-trust-icon">🤝</span> Trust as Repair Partner
                <?php endif; ?>
            </button>
        </div>
    <?php endif; ?>

</section>