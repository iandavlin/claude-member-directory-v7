<?php
/**
 * Profile Header Component
 * Displays cover image banner, avatar, name, tagline, availability badge,
 * location, featured taxonomy tags, and social links.
 * All elements respect PMP privacy settings.
 */

if (!defined('ABSPATH'))
    exit;

// Get template variables from query vars (set by single-member-directory.php)
$post_id = get_query_var('memdir_post_id');
$viewer_mode = get_query_var('memdir_viewer_mode');

// Get post author
$post_author_id = get_post_field('post_author', $post_id);

// Check each field's PMP visibility
$show_avatar = Memdir_PMP_Visibility::can_view($post_id, 'profile', memdir_field('avatar'), $viewer_mode);
$show_cover = Memdir_PMP_Visibility::can_view($post_id, 'profile', memdir_field('cover_image'), $viewer_mode);
$show_name = Memdir_PMP_Visibility::can_view($post_id, 'profile', memdir_field('full_name'), $viewer_mode);
$show_location = Memdir_PMP_Visibility::can_view($post_id, 'business', memdir_field('business_location'), $viewer_mode);
$show_social = Memdir_PMP_Visibility::can_view($post_id, 'profile', 'social_links', $viewer_mode);

// Get field values only if visible
$full_name = $show_name ? get_field(memdir_field('full_name'), $post_id) : '';
$avatar = $show_avatar ? get_field(memdir_field('avatar'), $post_id) : null;
$cover_image = $show_cover ? get_field(memdir_field('cover_image'), $post_id) : null;
$tagline = ''; // Tagline field does not exist in live ACF — reserved for future use
$location = $show_location ? get_field(memdir_field('business_location'), $post_id) : null;
$location_precision = get_field(memdir_field('business_location_precision'), $post_id);

// Availability badge (system field, always visible when set)
$availability_badge = function_exists('memdir_render_availability_badge')
    ? memdir_render_availability_badge($post_id, 'header')
    : '';

// Get avatar URL - use uploaded image or fallback to WP avatar
if ($show_avatar && $avatar) {
    $avatar_url = is_array($avatar) ? $avatar['url'] : $avatar;
} else {
    $avatar_url = $show_avatar ? get_avatar_url($post_author_id, array('size' => 120)) : '';
}

// Cover image URL
$cover_url = '';
if ($show_cover && $cover_image) {
    $cover_url = is_array($cover_image) ? ($cover_image['sizes']['large'] ?? $cover_image['url']) : $cover_image;
}

// Process location based on precision setting
$location_text = '';
if ($show_location && $location) {
    $location_text = memdir_format_location($location, $location_precision);
}

// Featured taxonomy tags (instruments + services, max 5 combined)
$featured_tags = array();
$archive_url = get_post_type_archive_link('member-directory');
if (memdir_is_section_enabled($post_id, 'craft')) {
    $instruments = get_the_terms($post_id, 'memdir_instruments');
    if ($instruments && !is_wp_error($instruments)) {
        foreach (array_slice($instruments, 0, 3) as $term) {
            $featured_tags[] = array('name' => $term->name, 'term_id' => $term->term_id, 'type' => 'instruments', 'taxonomy' => 'memdir_instruments');
        }
    }
    $services = get_the_terms($post_id, 'memdir_services');
    if ($services && !is_wp_error($services)) {
        $remaining = max(0, 5 - count($featured_tags));
        foreach (array_slice($services, 0, $remaining) as $term) {
            $featured_tags[] = array('name' => $term->name, 'term_id' => $term->term_id, 'type' => 'services', 'taxonomy' => 'memdir_services');
        }
    }
}

?>

<?php if ($cover_url): ?>
    <div class="memdir-cover-banner" style="background-image: url('<?php echo esc_url($cover_url); ?>');">
        <div class="memdir-cover-overlay"></div>
    </div>
<?php endif; ?>

<header class="memdir-profile-header <?php echo $cover_url ? 'memdir-profile-header--has-cover' : ''; ?>">
    <div class="memdir-profile-header-inner">
        <?php if ($avatar_url): ?>
            <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo esc_attr($full_name ?: 'Profile'); ?>"
                class="memdir-avatar <?php echo $cover_url ? 'memdir-avatar--elevated' : ''; ?>">
        <?php endif; ?>

        <div class="memdir-profile-header-content">
            <div class="memdir-profile-header-top">
                <?php if ($show_name && $full_name): ?>
                    <h1><?php echo esc_html($full_name); ?></h1>
                <?php elseif ($show_name): ?>
                    <?php
                    // Fallback to WP user display name (not post title, which may be stale)
                    $wp_user = get_userdata($post_author_id);
                    $fallback_name = $wp_user ? $wp_user->display_name : get_the_title();
                    ?>
                    <h1><?php echo esc_html($fallback_name); ?></h1>
                <?php endif; ?>

                <?php if ($availability_badge): ?>
                    <?php echo $availability_badge; ?>
                <?php endif; ?>
            </div>

            <?php if ($tagline): ?>
                <p class="memdir-tagline"><?php echo esc_html($tagline); ?></p>
            <?php endif; ?>

            <?php if ($location_text): ?>
                <div class="memdir-location">
                    📍 <?php echo esc_html($location_text); ?>
                </div>
            <?php endif; ?>

            <?php if ($viewer_mode !== 'edit'):
                $modified_time = get_post_modified_time('U', false, $post_id);
                $last_updated = human_time_diff($modified_time, current_time('U'));
                ?>
                <div class="memdir-last-updated">
                    🕒 Profile updated <?php echo esc_html($last_updated); ?> ago
                </div>
            <?php endif; ?>

            <?php if (!empty($featured_tags)): ?>
                <div class="memdir-featured-tags">
                    <?php foreach ($featured_tags as $tag): ?>
                        <?php if ($archive_url && !empty($tag['term_id'])): ?>
                            <a href="<?php echo esc_url(add_query_arg($tag['taxonomy'] . '[]', $tag['term_id'], $archive_url)); ?>"
                                class="memdir-tag memdir-tag--link memdir-tag-<?php echo esc_attr($tag['type']); ?>"><?php echo esc_html($tag['name']); ?></a>
                        <?php else: ?>
                            <span
                                class="memdir-tag memdir-tag-<?php echo esc_attr($tag['type']); ?>"><?php echo esc_html($tag['name']); ?></span>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($show_social):
            $social_links = array(
                'website' => get_field(memdir_field('profile_website'), $post_id),
                'instagram' => get_field(memdir_field('profile_instagram'), $post_id),
                'facebook' => get_field(memdir_field('profile_facebook'), $post_id),
                'youtube' => get_field(memdir_field('profile_youtube'), $post_id),
                'linktree' => get_field(memdir_field('profile_linktree'), $post_id)
            );
            include MEMDIR_PLUGIN_DIR . 'templates/components/social-links.php';
        endif; ?>

        <!-- Share Profile Button -->
        <button type="button" class="memdir-share-btn" data-url="<?php echo esc_url(get_permalink($post_id)); ?>">
            🔗 Share Profile
        </button>
    </div>
</header>