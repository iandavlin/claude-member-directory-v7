<?php
/**
 * Preview Notice Component
 * Shows information about hidden sections when viewing in member/public mode.
 * 
 * Required query vars:
 *  - memdir_post_id (int)
 *  - memdir_viewer_mode (string)
 */

if (!defined('ABSPATH'))
    exit;

$post_id = get_query_var('memdir_post_id');
$viewer_mode = get_query_var('memdir_viewer_mode');

// Only show notice to owners/admins previewing as member/public
if (!memdir_can_edit($post_id)) {
    return;
}

// Only show when in preview mode (not actual edit mode)
if ($viewer_mode === 'edit') {
    return;
}

// Count how many sections are hidden
$all_sections = memdir_get_sections();
$hidden_count = 0;

foreach ($all_sections as $key => $section) {
    if ($key === 'profile') {
        continue; // Profile always visible
    }

    if (!memdir_is_section_enabled($post_id, $key)) {
        $hidden_count++;
        continue;
    }

    if (!Memdir_PMP_Visibility::section_has_content($post_id, $key, $viewer_mode)) {
        $hidden_count++;
    }
}

if ($hidden_count > 0):
    $mode_label = ($viewer_mode === 'member') ? 'a member' : 'the public';
    ?>
    <div class="memdir-preview-notice" role="status">
        <p>
            <strong>👁️ Preview Mode:</strong>
            Viewing as
            <?php echo esc_html($mode_label); ?>.
            <?php echo esc_html($hidden_count); ?> section
            <?php echo $hidden_count !== 1 ? 's' : ''; ?>
            hidden due to privacy settings or empty content.
            <a href="<?php echo esc_url(get_permalink($post_id)); ?>">Return to Edit Mode</a>
        </p>
    </div>
<?php endif; ?>