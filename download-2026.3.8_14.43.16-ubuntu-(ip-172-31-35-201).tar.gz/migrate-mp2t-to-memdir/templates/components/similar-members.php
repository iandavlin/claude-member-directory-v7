<?php
/**
 * Similar Members Component
 *
 * Shows 2-3 members who share taxonomy terms, experience level,
 * or geographic proximity with the current profile.
 * Uses multi-factor weighted scoring for relevance ranking.
 *
 * Only shown on non-edit views.
 */

if (!defined('ABSPATH'))
    exit;

$post_id = get_query_var('memdir_post_id');
$viewer_mode = get_query_var('memdir_viewer_mode');

// Only show on member/public views, not edit
if ($viewer_mode === 'edit') {
    return;
}

// ── Step 1: Collect current profile's taxonomy terms ──────────────
$scoring_taxonomies = array(
    'memdir_instruments' => 3,  // Strongest signal — same instrument family
    'memdir_services' => 2,  // Shared service offerings
    'memdir_knowledge_domains' => 2,  // Shared expertise areas
    'memdir_musical_contexts' => 1,  // Shared musical context
    'memdir_equipment' => 1,  // Shared equipment
);

$my_terms = array();
$tax_queries = array();

foreach ($scoring_taxonomies as $taxonomy => $weight) {
    $terms = get_the_terms($post_id, $taxonomy);
    if ($terms && !is_wp_error($terms)) {
        $term_ids = wp_list_pluck($terms, 'term_id');
        $my_terms[$taxonomy] = $term_ids;
        $tax_queries[] = array(
            'taxonomy' => $taxonomy,
            'field' => 'term_id',
            'terms' => $term_ids,
            'operator' => 'IN',
        );
    } else {
        $my_terms[$taxonomy] = array();
    }
}

// Need at least one taxonomy match to find candidates
if (empty($tax_queries)) {
    return;
}

// ── Step 2: Collect non-taxonomy signals ──────────────────────────
$my_experience_level = get_field(memdir_field('experience_level'), $post_id);
$my_location = get_field(memdir_field('location'), $post_id);

// ── Step 3: Fetch broad candidate pool ───────────────────────────
$tax_queries['relation'] = 'OR';

$args = array(
    'post_type' => 'member-directory',
    'post_status' => 'publish',
    'posts_per_page' => 30,
    'post__not_in' => array($post_id),
    'tax_query' => $tax_queries,
    'fields' => 'ids',
    'no_found_rows' => true,
    'update_post_term_cache' => true,
);

// Privacy filtering
$privacy_query = memdir_get_privacy_meta_query();
if ($privacy_query) {
    $args['meta_query'] = $privacy_query;
}

$candidate_ids = get_posts($args);

if (empty($candidate_ids)) {
    return;
}

// ── BATCH PREFETCH: eliminate N+1 in scoring loop ────────────────
// Without this: 5 taxonomy queries × 30 candidates + get_field × 2 × 30 = ~210+ queries
// With this: 1 meta query + 5 taxonomy queries = 6 queries total
update_postmeta_cache($candidate_ids);
foreach (array_keys($scoring_taxonomies) as $tax) {
    wp_get_object_terms($candidate_ids, $tax);
}

// L2/N4 Fix: Prime term cache for the current profile's terms.
// The scoring loop calls get_term($tid) for shared terms; without this,
// each call queries the DB individually. One query loads them all.
$all_my_term_ids = array();
foreach ($my_terms as $ids) {
    $all_my_term_ids = array_merge($all_my_term_ids, $ids);
}
if (!empty($all_my_term_ids)) {
    get_terms(array('include' => array_unique($all_my_term_ids), 'hide_empty' => false));
}

// ── Step 4: Score each candidate ─────────────────────────────────
$scored = array();

foreach ($candidate_ids as $cid) {
    $score = 0;
    $reasons = array();

    // Taxonomy overlap scoring
    foreach ($scoring_taxonomies as $taxonomy => $weight) {
        if (empty($my_terms[$taxonomy])) {
            continue;
        }

        $candidate_terms = get_the_terms($cid, $taxonomy);
        if (!$candidate_terms || is_wp_error($candidate_terms)) {
            continue;
        }

        $candidate_term_ids = wp_list_pluck($candidate_terms, 'term_id');
        $shared = array_intersect($my_terms[$taxonomy], $candidate_term_ids);

        if (!empty($shared)) {
            $score += count($shared) * $weight;

            // Collect shared term names for "why similar" badges
            $shared_names = array();
            foreach (array_slice($shared, 0, 2) as $tid) {
                $term = get_term($tid, $taxonomy);
                if ($term && !is_wp_error($term)) {
                    $shared_names[] = $term->name;
                }
            }
            if (!empty($shared_names)) {
                $reasons[] = array(
                    'label' => implode(', ', $shared_names),
                );
            }
        }
    }

    // Experience level match (+2)
    if ($my_experience_level) {
        $candidate_level = get_field(memdir_field('experience_level'), $cid);
        if ($candidate_level && $candidate_level === $my_experience_level) {
            $score += 2;
            $reasons[] = array(
                'label' => ucfirst($candidate_level) . ' level',
            );
        }
    }

    // Geographic proximity
    if ($my_location && is_array($my_location)) {
        $candidate_location = get_field(memdir_field('location'), $cid);
        if ($candidate_location && is_array($candidate_location)) {
            $my_state = isset($my_location['state_short'])
                ? $my_location['state_short']
                : (isset($my_location['state']) ? $my_location['state'] : '');
            $c_state = isset($candidate_location['state_short'])
                ? $candidate_location['state_short']
                : (isset($candidate_location['state']) ? $candidate_location['state'] : '');
            $my_country = isset($my_location['country_short'])
                ? $my_location['country_short']
                : (isset($my_location['country']) ? $my_location['country'] : '');
            $c_country = isset($candidate_location['country_short'])
                ? $candidate_location['country_short']
                : (isset($candidate_location['country']) ? $candidate_location['country'] : '');

            if ($my_state && $c_state && strtolower($my_state) === strtolower($c_state)) {
                $score += 3;
                $display_state = isset($candidate_location['state']) ? $candidate_location['state'] : $c_state;
                $reasons[] = array(
                    'label' => 'Near ' . $display_state,
                );
            } elseif ($my_country && $c_country && strtolower($my_country) === strtolower($c_country)) {
                $score += 1;
            }
        }
    }

    if ($score > 0) {
        $scored[$cid] = array(
            'score' => $score,
            'reasons' => $reasons,
        );
    }
}

if (empty($scored)) {
    return;
}

// ── Step 5: Sort by score descending, take top 3 ─────────────────
uasort($scored, function ($a, $b) {
    return $b['score'] - $a['score'];
});

$top_ids = array_keys(array_slice($scored, 0, 3, true));
?>

<section class="memdir-similar-members">
    <h3 class="memdir-similar-members__title">Similar Members</h3>
    <div class="memdir-similar-members__grid">
        <?php foreach ($top_ids as $cid):
            global $post;
            $post = get_post($cid);
            if (!$post)
                continue;
            setup_postdata($post);

            $member_reasons = array_slice($scored[$cid]['reasons'], 0, 2);
            $memdir_card_post = $post;
            $memdir_card_layout = 'grid';
            ?>
            <div class="memdir-similar-member-wrap">
                <?php include MEMDIR_PLUGIN_DIR . 'templates/components/member-card.php'; ?>
                <?php if (!empty($member_reasons)): ?>
                    <div class="memdir-similar-reasons">
                        <?php foreach ($member_reasons as $reason): ?>
                            <span class="memdir-similar-reason">
                                <?php echo esc_html($reason['label']); ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<?php wp_reset_postdata(); ?>