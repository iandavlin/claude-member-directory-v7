<?php
/**
 * Social Links Component
 * Shared partial for rendering social link icons in both headers.
 * 
 * Expects: $social_links (array) — set before include.
 * Icons are derived from memdir_get_social_platforms().
 */

if (!defined('ABSPATH'))
    exit;

if (!empty($social_links) && !empty(array_filter($social_links))): ?>
    <div class="memdir-header-social">
        <?php
        $platforms = memdir_get_social_platforms();

        foreach ($social_links as $platform => $url):
            if (!empty($url)):
                $icon = isset($platforms[$platform]) ? $platforms[$platform]['icon'] : '🔗';
                $label = isset($platforms[$platform]) ? $platforms[$platform]['label'] : ucfirst($platform);
                ?>
                <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" class="memdir-social-icon"
                    title="<?php echo esc_attr($label); ?>">
                    <?php echo $icon; ?>
                </a>
                <?php
            endif;
        endforeach;
        ?>
    </div>
<?php endif; ?>