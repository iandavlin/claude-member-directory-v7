<?php
/**
 * Member Card Component
 * Compact card for archive/directory grid views.
 * Shows avatar, name, tagline, availability badge, business name,
 * location, and taxonomy tags.
 *
 * Required variable: $memdir_card_post (WP_Post object)
 * Optional variable: $memdir_card_layout (string: 'grid' or 'list', default 'grid')
 */

if (!defined('ABSPATH'))
    exit;

$card_post = $memdir_card_post;
$card_post_id = $card_post->ID;
$card_layout = isset($memdir_card_layout) ? $memdir_card_layout : 'grid';

// Determine viewer context
$viewer_mode = is_user_logged_in() ? 'member' : 'public';

// ─── Pre-compute section visibility (avoid repeated checks per field) ───
$craft_visible = memdir_is_section_enabled($card_post_id, 'craft');
$business_visible = memdir_is_section_enabled($card_post_id, 'business');

// --- Avatar ---
$avatar = null;
$avatar_url = '';
if (Memdir_PMP_Visibility::can_view($card_post_id, 'profile', memdir_field('avatar'), $viewer_mode)) {
    $avatar = get_field(memdir_field('avatar'), $card_post_id);
}
if ($avatar && isset($avatar['sizes']['medium'])) {
    $avatar_url = $avatar['sizes']['medium'];
} elseif ($avatar && isset($avatar['url'])) {
    $avatar_url = $avatar['url'];
}

// --- Name ---
$full_name = get_field(memdir_field('full_name'), $card_post_id);
if (empty($full_name)) {
    $full_name = get_the_title($card_post_id);
}

// --- Initials (for placeholder) ---
$initials = '';
if ($full_name) {
    $parts = explode(' ', trim($full_name));
    $initials = strtoupper(substr($parts[0], 0, 1));
    if (count($parts) > 1) {
        $initials .= strtoupper(substr(end($parts), 0, 1));
    }
}

// --- Tagline ---
$tagline = '';
// Tagline field does not exist in live ACF — skip for now
if (false) {
    $tagline = '';
}

// --- Availability Badge ---
$availability_badge = function_exists('memdir_render_availability_badge')
    ? memdir_render_availability_badge($card_post_id, 'card')
    : '';

// --- Location ---
$location_display = '';
if (Memdir_PMP_Visibility::can_view($card_post_id, 'business', memdir_field('location'), $viewer_mode)) {
    $location = get_field(memdir_field('location'), $card_post_id);
    $specificity = get_field(memdir_field('location_specificity'), $card_post_id);
    $location_display = memdir_format_location($location, $specificity);
}

// --- Instruments (first 3 tags) ---
$instruments = array();
$instrument_tags = array();
if (
    $craft_visible &&
    Memdir_PMP_Visibility::can_view($card_post_id, 'craft', memdir_field('craft_instruments'), $viewer_mode)
) {
    $instruments = get_the_terms($card_post_id, 'memdir_instruments');
    if ($instruments && !is_wp_error($instruments)) {
        $instrument_tags = array_slice($instruments, 0, 3);
    } else {
        $instruments = array();
    }
}

// --- Services (first 2 tags) ---
$service_tags = array();
if (
    memdir_is_section_enabled($card_post_id, 'business') &&
    Memdir_PMP_Visibility::can_view($card_post_id, 'business', memdir_field('business_services'), $viewer_mode)
) {
    $services = get_the_terms($card_post_id, 'memdir_services');
    if ($services && !is_wp_error($services)) {
        $service_tags = array_slice($services, 0, 2);
    }
}

// --- Business Name ---
$business_name = '';
if (
    $business_visible &&
    Memdir_PMP_Visibility::can_view($card_post_id, 'business', memdir_field('business_name'), $viewer_mode)
) {
    $business_name = get_field(memdir_field('business_name'), $card_post_id);
}

$permalink = get_permalink($card_post_id);

// --- Last Updated ---
$modified_time = get_post_modified_time('U', false, $card_post_id);
$last_updated = human_time_diff($modified_time, current_time('U'));
?>

<article class="memdir-member-card memdir-member-card--<?php echo esc_attr($card_layout); ?>"
    data-post-id="<?php echo esc_attr($card_post_id); ?>">

    <a href="<?php echo esc_url($permalink); ?>" class="memdir-card-link"
        aria-label="View <?php echo esc_attr($full_name); ?>'s profile">

        <div class="memdir-card-inner">

            <div class="memdir-card-avatar">
                <?php if ($avatar_url): ?>
                    <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo esc_attr($full_name); ?>"
                        loading="lazy" />
                <?php else: ?>
                    <div class="memdir-card-initials">
                        <span>
                            <?php echo esc_html($initials); ?>
                        </span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="memdir-card-info">
                <div class="memdir-card-name-row">
                    <h3 class="memdir-card-name">
                        <?php echo esc_html($full_name); ?>
                    </h3>
                    <?php if ($availability_badge): ?>
                        <?php echo $availability_badge; ?>
                    <?php endif; ?>
                </div>

                <?php if ($tagline): ?>
                    <p class="memdir-card-tagline">
                        <?php echo esc_html($tagline); ?>
                    </p>
                <?php endif; ?>

                <?php if ($business_name): ?>
                    <p class="memdir-card-business">
                        <?php echo esc_html($business_name); ?>
                    </p>
                <?php endif; ?>

                <?php if ($location_display): ?>
                    <p class="memdir-card-location">
                        <span class="memdir-icon">📍</span>
                        <?php echo esc_html($location_display); ?>
                    </p>
                <?php endif; ?>

                <?php if (!empty($instrument_tags) || !empty($service_tags)): ?>
                    <div class="memdir-card-tags">
                        <?php foreach ($instrument_tags as $term): ?>
                            <span class="memdir-card-tag memdir-card-tag--instrument">
                                <?php echo esc_html($term->name); ?>
                            </span>
                        <?php endforeach; ?>
                        <?php foreach ($service_tags as $term): ?>
                            <span class="memdir-card-tag memdir-card-tag--service">
                                <?php echo esc_html($term->name); ?>
                            </span>
                        <?php endforeach; ?>
                        <?php
                        $total_tags = count($instruments) + count($service_tags);
                        $shown_tags = count($instrument_tags) + count($service_tags);
                        if ($total_tags > $shown_tags): ?>
                            <span class="memdir-card-tag memdir-card-tag--more">+<?php echo $total_tags - $shown_tags; ?></span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <p class="memdir-card-updated">
                    <span class="memdir-icon">🕒</span>
                    Updated <?php echo esc_html($last_updated); ?> ago
                </p>
            </div>

        </div>

    </a>

</article>