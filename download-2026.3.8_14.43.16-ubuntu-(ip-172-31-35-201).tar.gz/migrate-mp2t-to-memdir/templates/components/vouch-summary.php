<?php
/**
 * Vouch Summary — Edit Mode Sidebar Widget
 *
 * Shows the profile owner a private breakdown of received vouches:
 * - Which skills have been vouched and by whom (with progress indicator)
 * - Which builders trust them as a repair partner
 *
 * Only visible in edit mode (profile owner viewing their own profile).
 *
 * @since 1.3.0
 */

if (!defined('ABSPATH'))
    exit;

if (!class_exists('Memdir_Endorsements')) {
    return;
}

$post_id = get_query_var('memdir_post_id');
$viewer_mode = get_query_var('memdir_viewer_mode');

// Only show in edit mode
if ($viewer_mode !== 'edit') {
    return;
}

$summary = Memdir_Endorsements::get_edit_summary($post_id);
$skills = $summary['skills'];
$trusted_by = $summary['trusted_by'];

// Don't show if there's nothing to report
if (empty($skills) && empty($trusted_by)) {
    return;
}

$threshold = Memdir_Endorsements::VOUCH_THRESHOLD;
?>

<div class="memdir-vouch-summary">
    <h4 class="memdir-vouch-summary__title">🤝 Community Vouches</h4>

    <?php if (!empty($skills)): ?>
        <div class="memdir-vouch-summary__section">
            <h5 class="memdir-vouch-summary__section-title">Skill Vouches</h5>
            <?php foreach ($skills as $tid => $skill): ?>
                <div
                    class="memdir-vouch-summary__skill <?php echo $skill['meets_threshold'] ? 'memdir-vouch-summary__skill--active' : ''; ?>">
                    <div class="memdir-vouch-summary__skill-header">
                        <span class="memdir-vouch-summary__skill-icon">
                            <?php echo $skill['meets_threshold'] ? '✓' : '○'; ?>
                        </span>
                        <span class="memdir-vouch-summary__skill-name">
                            <?php echo esc_html($skill['term_name']); ?>
                        </span>
                        <span class="memdir-vouch-summary__skill-count">
                            <?php echo esc_html($skill['count']); ?>
                            <?php echo $skill['count'] === 1 ? 'vouch' : 'vouches'; ?>
                        </span>
                    </div>
                    <div class="memdir-vouch-summary__progress">
                        <div class="memdir-vouch-summary__progress-bar"
                            style="width: <?php echo esc_attr(min(100, ($skill['count'] / $threshold) * 100)); ?>%">
                        </div>
                    </div>
                    <div class="memdir-vouch-summary__endorsers">
                        <?php echo esc_html(implode(', ', $skill['endorsers'])); ?>
                        <?php if (!$skill['meets_threshold']): ?>
                            <span class="memdir-vouch-summary__needs-more">
                                (needs
                                <?php echo esc_html($threshold - $skill['count']); ?> more)
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($trusted_by)): ?>
        <div class="memdir-vouch-summary__section">
            <h5 class="memdir-vouch-summary__section-title">
                🛡️ Trusted by
                <?php echo count($trusted_by); ?>
                <?php echo count($trusted_by) === 1 ? 'builder' : 'builders'; ?>
            </h5>
            <ul class="memdir-vouch-summary__trusted-list">
                <?php foreach ($trusted_by as $b): ?>
                    <li><?php echo esc_html($b['name']); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
</div>