<?php
/**
 * Portfolio Gallery Component
 * Displays a grid of portfolio images with lightbox support.
 * In edit mode: shows upload button and remove controls.
 * In public/member mode: shows gallery with hover captions.
 *
 * Required query vars: memdir_post_id, memdir_viewer_mode
 */

if (!defined('ABSPATH'))
    exit;

$post_id = get_query_var('memdir_post_id');
$viewer_mode = get_query_var('memdir_viewer_mode');

// Portfolio respects Experience section PMP visibility
// In edit mode, always show (owner can manage their gallery)
// For other viewers, check if the experience section is visible
if ($viewer_mode !== 'edit') {
    if (!Memdir_PMP_Visibility::can_view($post_id, 'experience', null, $viewer_mode)) {
        return;
    }
}

// Get portfolio images from post meta (stored as array of attachment IDs)
$portfolio_ids = get_post_meta($post_id, memdir_field('portfolio_images'), true);
if (!is_array($portfolio_ids)) {
    $portfolio_ids = array();
}

// Filter out any deleted/invalid attachments
$portfolio_ids = array_filter($portfolio_ids, function ($id) {
    return wp_attachment_is_image($id);
});

// In non-edit modes, don't show section if empty
if ($viewer_mode !== 'edit' && empty($portfolio_ids)) {
    return;
}

?>

<div class="memdir-portfolio">
    <h3 class="memdir-section-subtitle">Portfolio</h3>
    <div class="memdir-portfolio__grid">
        <?php foreach ($portfolio_ids as $image_id):
            $image_url = wp_get_attachment_image_url($image_id, 'large');
            $image_thumb = wp_get_attachment_image_url($image_id, 'medium');
            $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);
            $image_caption = wp_get_attachment_caption($image_id);
            if (!$image_url)
                continue;
            ?>
            <div class="memdir-portfolio__item" data-image-id="<?php echo esc_attr($image_id); ?>">
                <img src="<?php echo esc_url($image_thumb); ?>"
                    alt="<?php echo esc_attr($image_alt ?: 'Portfolio image'); ?>" loading="lazy" />
                <?php if ($image_caption): ?>
                    <div class="memdir-portfolio__item-overlay">
                        <?php echo esc_html($image_caption); ?>
                    </div>
                <?php endif; ?>
                <?php if ($viewer_mode === 'edit'): ?>
                    <button type="button" class="memdir-portfolio__remove" aria-label="Remove image">✕</button>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

        <?php if ($viewer_mode === 'edit'): ?>
            <div class="memdir-portfolio__upload" role="button" tabindex="0" aria-label="Add portfolio images">
                <span class="memdir-portfolio__upload-icon">📷</span>
                <span>Add Images</span>
            </div>
        <?php endif; ?>
    </div>
</div>