<?php
/**
 * Business Header Component
 * Professional brand-focused layout: cover image, logo, business name,
 * availability badge, tagline, location, services taxonomy chips,
 * featured tags, social icons, share button.
 * Shown when the Business section is active (Focus Mode) or promoted.
 * All elements respect PMP privacy settings.
 */

if (!defined('ABSPATH'))
    exit;

// Get template variables from query vars (set by single-member-directory.php)
$post_id = get_query_var('memdir_post_id');
$viewer_mode = get_query_var('memdir_viewer_mode');

// Get post author
$post_author_id = get_post_field('post_author', $post_id);

// Check field visibility (business section fields)
$show_logo = Memdir_PMP_Visibility::can_view($post_id, 'business', memdir_field('business_logo'), $viewer_mode);
$show_name = Memdir_PMP_Visibility::can_view($post_id, 'business', memdir_field('business_name'), $viewer_mode);
$show_services = Memdir_PMP_Visibility::can_view($post_id, 'business', memdir_field('business_services'), $viewer_mode);
$show_social = Memdir_PMP_Visibility::can_view($post_id, 'profile', 'social_links', $viewer_mode);

// Profile-level fields for shared elements (cover image, member name)
// Location lives in the business group but is shared across both headers
$show_cover = Memdir_PMP_Visibility::can_view($post_id, 'profile', memdir_field('cover_image'), $viewer_mode);
$show_location = Memdir_PMP_Visibility::can_view($post_id, 'business', memdir_field('location'), $viewer_mode);
$show_member_name = Memdir_PMP_Visibility::can_view($post_id, 'profile', memdir_field('full_name'), $viewer_mode);

// Get field values only if visible
$business_name = $show_name ? get_field(memdir_field('business_name'), $post_id) : '';
$business_logo = $show_logo ? get_field(memdir_field('business_logo'), $post_id) : null;
$cover_image = $show_cover ? get_field(memdir_field('cover_image'), $post_id) : null;
$location = $show_location ? get_field(memdir_field('location'), $post_id) : null;
$location_precision = get_field(memdir_field('location_specificity'), $post_id);

// Member's personal name (shown as subtitle in business header)
$member_name = $show_member_name ? get_field(memdir_field('full_name'), $post_id) : '';
if (!$member_name && $show_member_name) {
    // Fallback to WP user display name (not post title, which may be stale)
    $wp_user = get_userdata($post_author_id);
    $member_name = $wp_user ? $wp_user->display_name : get_the_title($post_id);
}

// Get logo URL
$logo_url = '';
if ($show_logo && $business_logo) {
    $logo_url = is_array($business_logo) ? $business_logo['url'] : $business_logo;
}

// Get cover URL
$cover_url = '';
if ($show_cover && $cover_image) {
    $cover_url = is_array($cover_image) ? ($cover_image['sizes']['large'] ?? $cover_image['url']) : $cover_image;
}

// Process location
$location_text = '';
if ($show_location && $location) {
    $location_text = memdir_format_location($location, $location_precision);
}

// Availability badge (system field, always visible when set)
$availability_badge = function_exists('memdir_render_availability_badge')
    ? memdir_render_availability_badge($post_id, 'header')
    : '';

// Get services taxonomy terms if visible
$service_chips = array();
if ($show_services) {
    $terms = get_the_terms($post_id, 'memdir_services');
    if ($terms && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $service_chips[] = $term->name;
        }
    }
}

// Featured taxonomy tags (instruments, max 3 — services already shown as chips)
$featured_tags = array();
$archive_url = get_post_type_archive_link('member-directory');
if (memdir_is_section_enabled($post_id, 'craft')) {
    $instruments = get_the_terms($post_id, 'memdir_instruments');
    if ($instruments && !is_wp_error($instruments)) {
        foreach (array_slice($instruments, 0, 4) as $term) {
            $featured_tags[] = array(
                'name' => $term->name,
                'term_id' => $term->term_id,
                'type' => 'instruments',
                'taxonomy' => 'memdir_instruments'
            );
        }
    }
}

// Initial display: shown if business is promoted, hidden otherwise
$business_promoted = get_query_var('memdir_business_promoted', false);
$initial_display = (!empty($business_promoted) && $business_promoted) ? 'block' : 'none';
?>

<?php if ($cover_url): ?>
    <div class="memdir-biz-cover-banner"
        style="display: <?php echo $initial_display; ?>; background-image: url('<?php echo esc_url($cover_url); ?>');">
        <div class="memdir-biz-cover-overlay"></div>
    </div>
<?php endif; ?>

<header class="memdir-business-header <?php echo $cover_url ? 'memdir-business-header--has-cover' : ''; ?>"
    style="display: <?php echo $initial_display; ?>;" aria-label="Business profile">
    <div class="memdir-business-header-inner">

        <?php if ($logo_url): ?>
            <div class="memdir-business-logo-wrap">
                <img src="<?php echo esc_url($logo_url); ?>"
                    alt="<?php echo esc_attr($business_name ?: 'Business Logo'); ?>" class="memdir-business-logo">
            </div>
        <?php endif; ?>

        <div class="memdir-business-header-content">
            <div class="memdir-business-header-top">
                <?php if ($show_name && $business_name): ?>
                    <h1><?php echo esc_html($business_name); ?></h1>
                <?php endif; ?>

                <?php if ($availability_badge): ?>
                    <?php echo $availability_badge; ?>
                <?php endif; ?>
            </div>

            <?php if ($member_name): ?>
                <p class="memdir-biz-member-name">👤 <?php echo esc_html($member_name); ?></p>
            <?php endif; ?>

            <?php if ($location_text): ?>
                <div class="memdir-biz-location">
                    📍 <?php echo esc_html($location_text); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($service_chips)): ?>
                <div class="memdir-service-chips">
                    <?php foreach ($service_chips as $chip): ?>
                        <span class="memdir-chip">
                            <?php echo esc_html($chip); ?>
                        </span>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($featured_tags)): ?>
                <div class="memdir-biz-featured-tags">
                    <?php foreach ($featured_tags as $tag): ?>
                        <?php if ($archive_url && !empty($tag['term_id'])): ?>
                            <a href="<?php echo esc_url(add_query_arg($tag['taxonomy'] . '[]', $tag['term_id'], $archive_url)); ?>"
                                class="memdir-biz-tag"><?php echo esc_html($tag['name']); ?></a>
                        <?php else: ?>
                            <span class="memdir-biz-tag"><?php echo esc_html($tag['name']); ?></span>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($viewer_mode !== 'edit'):
                $modified_time = get_post_modified_time('U', false, $post_id);
                $last_updated = human_time_diff($modified_time, current_time('U'));
                ?>
                <div class="memdir-biz-last-updated">
                    🕒 Updated <?php echo esc_html($last_updated); ?> ago
                </div>
            <?php endif; ?>
        </div>

        <div class="memdir-business-header-actions">
            <?php if ($show_social):
                $social_links = array(
                    'website' => get_field(memdir_field('profile_website'), $post_id),
                    'instagram' => get_field(memdir_field('profile_instagram'), $post_id),
                    'facebook' => get_field(memdir_field('profile_facebook'), $post_id),
                    'youtube' => get_field(memdir_field('profile_youtube'), $post_id),
                    'linktree' => get_field(memdir_field('profile_linktree'), $post_id)
                );
                include MEMDIR_PLUGIN_DIR . 'templates/components/social-links.php';
            endif; ?>

            <!-- Share Profile Button -->
            <button type="button" class="memdir-share-btn" data-url="<?php echo esc_url(get_permalink($post_id)); ?>">
                🔗 Share Profile
            </button>
        </div>

    </div>
</header>