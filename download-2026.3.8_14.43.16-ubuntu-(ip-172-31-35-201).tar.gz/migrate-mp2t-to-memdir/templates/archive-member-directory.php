<?php
/**
 * Archive Template — Member Directory
 * Displays the browsable member directory with grid/list views,
 * search, taxonomy filters, sorting, and pagination.
 */

if (!defined('ABSPATH'))
    exit;

get_header();

// Viewer context
$viewer_mode = is_user_logged_in() ? 'member' : 'public';
$total_members = (int) wp_count_posts('member-directory')->publish;

// Current filter state from URL
$current_sort = isset($_GET['sort']) ? sanitize_key($_GET['sort']) : 'az';
$current_search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
$current_layout = isset($_GET['layout']) ? sanitize_key($_GET['layout']) : 'grid';

// Load available taxonomy terms for filters
$filter_taxonomies = array(
    'memdir_instruments' => 'Instruments',
    'memdir_services' => 'Services',
    'memdir_musical_contexts' => 'Musical Contexts',
);

?>

<div class="memdir-archive-wrap">

    <!-- Archive Header -->
    <header class="memdir-archive-header">
        <div class="memdir-archive-header__inner">
            <h1 class="memdir-archive-title">Member Directory</h1>
            <p class="memdir-archive-subtitle">
                <?php echo esc_html($total_members); ?> member
                <?php echo $total_members !== 1 ? 's' : ''; ?>
                in the community
            </p>
        </div>
    </header>

    <?php
    // Featured Member — algorithmically selected (most recently updated profile)
    // Respects the same PMP privacy filtering as the main archive query (H1 fix).
    $featured_args = array(
        'post_type'      => 'member-directory',
        'posts_per_page' => 1,
        'post_status'    => 'publish',
        'orderby'        => 'modified',
        'order'          => 'DESC',
        'no_found_rows'  => true,
    );
    $privacy_query = memdir_get_privacy_meta_query();
    if ($privacy_query) {
        $featured_args['meta_query'] = $privacy_query;
    }
    $featured_query = new WP_Query($featured_args);

    if ($featured_query->have_posts()):
        $featured_query->the_post();
        $featured_id = get_the_ID();
        $featured_name = get_field(memdir_field('full_name'), $featured_id);
        if (empty($featured_name))
            $featured_name = get_the_title($featured_id);
        $featured_tagline = ''; // Tagline field does not exist in live ACF
        $featured_avatar = get_field(memdir_field('avatar'), $featured_id);
        $featured_avatar_url = '';
        if ($featured_avatar && isset($featured_avatar['sizes']['medium'])) {
            $featured_avatar_url = $featured_avatar['sizes']['medium'];
        }
        $featured_link = get_permalink($featured_id);
        $featured_updated = human_time_diff(get_post_modified_time('U', false, $featured_id), current_time('U'));
        ?>
        <section class="memdir-featured-member" aria-label="Featured Member">
            <div class="memdir-featured-member__inner">
                <span class="memdir-featured-member__label">✨ Featured Member</span>
                <div class="memdir-featured-member__content">
                    <?php if ($featured_avatar_url): ?>
                        <img src="<?php echo esc_url($featured_avatar_url); ?>" alt="<?php echo esc_attr($featured_name); ?>"
                            class="memdir-featured-member__avatar" />
                    <?php endif; ?>
                    <div class="memdir-featured-member__info">
                        <h3 class="memdir-featured-member__name">
                            <a href="<?php echo esc_url($featured_link); ?>">
                                <?php echo esc_html($featured_name); ?>
                            </a>
                        </h3>
                        <?php if ($featured_tagline): ?>
                            <p class="memdir-featured-member__tagline">
                                <?php echo esc_html($featured_tagline); ?>
                            </p>
                        <?php endif; ?>
                        <span class="memdir-featured-member__meta">
                            Profile updated <?php echo esc_html($featured_updated); ?> ago
                        </span>
                    </div>
                    <a href="<?php echo esc_url($featured_link); ?>" class="memdir-featured-member__cta">View Profile →</a>
                </div>
            </div>
        </section>
        <?php
        wp_reset_postdata();
    endif;
    ?>

    <div class="memdir-archive-body">

        <!-- Filter Sidebar -->
        <aside class="memdir-archive-sidebar" role="complementary" aria-label="Filter members">

            <!-- Search -->
            <div class="memdir-filter-section">
                <label for="memdir-search-input" class="memdir-filter-label">Search</label>
                <input type="text" id="memdir-search-input" class="memdir-search-input" placeholder="Search by name…"
                    value="<?php echo esc_attr($current_search); ?>" autocomplete="off" />
            </div>

            <!-- Taxonomy Filters -->
            <?php foreach ($filter_taxonomies as $tax_slug => $tax_label):
                $terms = get_terms(array(
                    'taxonomy' => $tax_slug,
                    'hide_empty' => true,
                    'orderby' => 'name',
                    'order' => 'ASC',
                ));
                if (empty($terms) || is_wp_error($terms))
                    continue;

                // Check which terms are currently active
                $active_terms = array();
                if (isset($_GET[$tax_slug]) && is_array($_GET[$tax_slug])) {
                    $active_terms = array_map('intval', $_GET[$tax_slug]);
                }
                ?>
                <div class="memdir-filter-section" data-taxonomy="<?php echo esc_attr($tax_slug); ?>">
                    <h3 class="memdir-filter-label">
                        <?php echo esc_html($tax_label); ?>
                    </h3>
                    <div class="memdir-filter-options">
                        <?php foreach ($terms as $term): ?>
                            <label class="memdir-filter-checkbox">
                                <input type="checkbox" name="<?php echo esc_attr($tax_slug); ?>[]"
                                    value="<?php echo esc_attr($term->term_id); ?>" <?php checked(in_array($term->term_id, $active_terms)); ?> />
                                <span class="memdir-filter-checkbox__label">
                                    <?php echo esc_html($term->name); ?>
                                    <span class="memdir-filter-checkbox__count">(
                                        <?php echo esc_html($term->count); ?>)
                                    </span>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>

            <!-- Clear Filters -->
            <button type="button" class="memdir-clear-filters" style="display: none;">
                Clear All Filters
            </button>

        </aside>

        <!-- Main Content -->
        <main class="memdir-archive-main">

            <!-- Toolbar -->
            <div class="memdir-archive-toolbar">
                <div class="memdir-archive-toolbar__left">
                    <span class="memdir-results-count" aria-live="polite">
                        <?php
                        global $wp_query;
                        $found = $wp_query->found_posts;
                        echo esc_html($found) . ' result' . ($found !== 1 ? 's' : '');
                        ?>
                    </span>
                </div>

                <div class="memdir-archive-toolbar__right">
                    <!-- Sort -->
                    <select id="memdir-sort-select" class="memdir-sort-select" aria-label="Sort members">
                        <option value="az" <?php selected($current_sort, 'az'); ?>>A → Z</option>
                        <option value="za" <?php selected($current_sort, 'za'); ?>>Z → A</option>
                        <option value="newest" <?php selected($current_sort, 'newest'); ?>>Newest</option>
                        <option value="oldest" <?php selected($current_sort, 'oldest'); ?>>Oldest</option>
                    </select>

                    <!-- Layout Toggle -->
                    <div class="memdir-layout-toggle" role="radiogroup" aria-label="View layout">
                        <button type="button"
                            class="memdir-layout-btn <?php echo $current_layout === 'grid' ? 'active' : ''; ?>"
                            data-layout="grid" aria-label="Grid view" title="Grid view">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                                <rect x="0" y="0" width="7" height="7" rx="1" />
                                <rect x="9" y="0" width="7" height="7" rx="1" />
                                <rect x="0" y="9" width="7" height="7" rx="1" />
                                <rect x="9" y="9" width="7" height="7" rx="1" />
                            </svg>
                        </button>
                        <button type="button"
                            class="memdir-layout-btn <?php echo $current_layout === 'list' ? 'active' : ''; ?>"
                            data-layout="list" aria-label="List view" title="List view">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                                <rect x="0" y="0" width="16" height="3" rx="1" />
                                <rect x="0" y="5" width="16" height="3" rx="1" />
                                <rect x="0" y="10" width="16" height="3" rx="1" />
                            </svg>
                        </button>
                        <button type="button" class="memdir-layout-btn" data-layout="map" aria-label="Map view"
                            title="Map view">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                                <path
                                    d="M8 0C5.2 0 3 2.2 3 5c0 4.2 5 11 5 11s5-6.8 5-11C13 2.2 10.8 0 8 0zm0 7.5C6.6 7.5 5.5 6.4 5.5 5S6.6 2.5 8 2.5 10.5 3.6 10.5 5 9.4 7.5 8 7.5z" />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Member Grid -->
            <div id="memdir-member-grid"
                class="memdir-member-grid memdir-member-grid--<?php echo esc_attr($current_layout); ?>">
                <?php
                if (have_posts()):
                    // ─── BATCH PREFETCH for initial page load ───
                    // Same optimization as AJAX handler and map data.
                    // Prefetch all post meta + taxonomy terms in 3 queries
                    // instead of ~180 individual queries (15 per card × 12 cards).
                    global $wp_query;
                    $card_ids = wp_list_pluck($wp_query->posts, 'ID');
                    update_postmeta_cache($card_ids);
                    $card_taxonomies = array('memdir_instruments', 'memdir_services');
                    foreach ($card_taxonomies as $card_tax) {
                        wp_get_object_terms($card_ids, $card_tax);
                    }

                    while (have_posts()):
                        the_post();
                        $memdir_card_post = get_post();
                        $memdir_card_layout = $current_layout;
                        include MEMDIR_PLUGIN_DIR . 'templates/components/member-card.php';
                    endwhile;
                else:
                    ?>
                    <div class="memdir-no-results">
                        <p>No members found matching your criteria.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Map View Container (hidden by default, lazy-initialized) -->
            <div id="memdir-map-container" class="memdir-map-container" style="display: none;" aria-label="Member map">
            </div>

            <!-- Pagination -->
            <nav class="memdir-pagination memdir-pagination--cards" aria-label="Member directory pagination">
                <?php
                echo paginate_links(array(
                    'total' => $wp_query->max_num_pages,
                    'current' => max(1, get_query_var('paged')),
                    'prev_text' => '← Previous',
                    'next_text' => 'Next →',
                    'type' => 'list',
                    'mid_size' => 2,
                ));
                ?>
            </nav>

        </main>

    </div>

</div>

<!-- Map view toggle logic -->
<script>
    (function ($) {
        $(document).on('click', '.memdir-layout-btn[data-layout="map"]', function () {
            var $btn = $(this);
            var $grid = $('#memdir-member-grid');
            var $map = $('#memdir-map-container');
            var $pagination = $('.memdir-pagination--cards');

            // Toggle active button
            $btn.siblings().removeClass('active');
            $btn.addClass('active');

            // Show map, hide grid + pagination
            $grid.hide();
            $pagination.hide();
            $map.show();

            // Lazy-init the map (only loads Leaflet on first click)
            if (typeof window.MEMDIR_Map !== 'undefined') {
                if (!window.MEMDIR_Map.initialized) {
                    window.MEMDIR_Map.init();
                } else {
                    window.MEMDIR_Map.invalidateSize();
                }
            }
        });

        // When switching back to grid/list, hide map
        $(document).on('click', '.memdir-layout-btn[data-layout="grid"], .memdir-layout-btn[data-layout="list"]', function () {
            $('#memdir-map-container').hide();
            $('#memdir-member-grid').show();
            $('.memdir-pagination--cards').show();
        });
    })(jQuery);
</script>

<?php get_footer(); ?>