<?php
/**
 * Setup Profile Template
 * 
 * Displayed to logged-in users who do not yet have a member-directory post.
 * Shows a single "Page Name" input. On submit, creates the post and redirects 
 * to the new profile in edit mode.
 */

if (!defined('ABSPATH')) {
    exit;
}

// ── Handle form submission ──────────────────────────────────────────────────
if (
    isset($_POST['memdir_page_name'])
    && isset($_POST['memdir_setup_nonce'])
    && wp_verify_nonce($_POST['memdir_setup_nonce'], 'memdir_create_profile')
) {
    $page_name = sanitize_text_field(wp_unslash($_POST['memdir_page_name']));

    if (empty($page_name)) {
        $setup_error = 'Please enter a name for your page.';
    } else {
        $user_id = get_current_user_id();

        // Double-check they don't already have a post (race condition guard)
        $existing = memdir_get_user_post($user_id);
        if ($existing) {
            wp_safe_redirect(get_permalink($existing->ID) . '?mode=edit');
            exit;
        }

        // Create the post
        $post_id = wp_insert_post(array(
            'post_type' => 'member-directory',
            'post_status' => 'publish',
            'post_title' => $page_name,
            'post_name' => sanitize_title($page_name), // slug
            'post_author' => $user_id,
        ));

        if (!is_wp_error($post_id) && $post_id) {
            // Seed the ACF "Page Name" field so it appears pre-populated
            update_field('member_directory_page_name', $page_name, $post_id);

            // Redirect to the new profile in edit mode
            wp_safe_redirect(get_permalink($post_id) . '?mode=edit');
            exit;
        } else {
            $setup_error = 'Something went wrong creating your profile. Please try again.';
        }
    }
}

get_header();
?>

<div class="memdir-setup-wrap">
    <div class="memdir-setup-container">
        <div class="memdir-setup-form-card">

            <label for="memdir-page-name" class="memdir-setup-label">
                What do you want your Member Directory page to be called?
            </label>

            <?php if (!empty($setup_error)): ?>
                <div class="memdir-setup-error"><?php echo esc_html($setup_error); ?></div>
            <?php endif; ?>

            <form method="post" class="memdir-setup-form">
                <?php wp_nonce_field('memdir_create_profile', 'memdir_setup_nonce'); ?>

                <input type="text" id="memdir-page-name" name="memdir_page_name" placeholder="e.g. Ted's Guitar Shop"
                    value="<?php echo isset($_POST['memdir_page_name']) ? esc_attr(sanitize_text_field(wp_unslash($_POST['memdir_page_name']))) : ''; ?>"
                    required autocomplete="off" />

                <p class="memdir-setup-slug-preview">
                    Your URL will be: <code id="memdir-slug-preview">your-page-name</code>
                </p>

                <div class="memdir-setup-submit">
                    <button type="submit" class="memdir-setup-btn">Create My Page</button>
                </div>
            </form>

        </div>
    </div>
</div>

<style>
    .memdir-setup-wrap {
        max-width: 520px;
        margin: 80px auto;
        padding: 0 20px;
        font-family: 'Work Sans', -apple-system, BlinkMacSystemFont, sans-serif;
    }

    .memdir-setup-form-card {
        background: #fff;
        border: 1px solid #e0e0e0;
        border-radius: 10px;
        padding: 48px 40px;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.07);
    }

    .memdir-setup-label {
        display: block;
        font-size: 1.15rem;
        font-weight: 600;
        color: #1E2A22;
        margin-bottom: 20px;
        line-height: 1.4;
    }

    .memdir-setup-error {
        background: #fef2f2;
        color: #b91c1c;
        padding: 10px 14px;
        border-radius: 6px;
        font-size: 0.9rem;
        margin-bottom: 16px;
        border: 1px solid #fecaca;
    }

    .memdir-setup-form input[type="text"] {
        width: 100%;
        padding: 14px 16px;
        font-size: 1.1rem;
        font-family: inherit;
        border: 1px solid #ccc;
        border-radius: 6px;
        box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.04);
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
        box-sizing: border-box;
    }

    .memdir-setup-form input[type="text"]:focus {
        outline: none;
        border-color: #C9A24D;
        box-shadow: 0 0 0 3px rgba(201, 162, 77, 0.18);
    }

    .memdir-setup-slug-preview {
        margin: 12px 0 0;
        font-size: 0.85rem;
        color: #888;
    }

    .memdir-setup-slug-preview code {
        background: #f5f5f0;
        padding: 2px 6px;
        border-radius: 3px;
        font-size: 0.85rem;
        color: #4A5A3C;
    }

    .memdir-setup-submit {
        margin-top: 28px;
        text-align: right;
    }

    .memdir-setup-btn {
        background-color: #C9A24D;
        color: #fff;
        border: none;
        font-size: 1rem;
        font-weight: 600;
        font-family: inherit;
        padding: 13px 28px;
        border-radius: 6px;
        cursor: pointer;
        transition: background-color 0.2s ease;
    }

    .memdir-setup-btn:hover {
        background-color: #b08a30;
    }
</style>

<script>
    // Live slug preview as user types
    (funct ion () {
        var input = document.getElementById('memdir-page-name');
        var preview = document.getElementById('memdir-slug-preview');
        if (!input || !preview) return;

        input.addEventListener('input', func tion () {
            var val = this.value.trim();
            if (!val) {
                preview.textContent = 'your-page-name';
                return;
            }
            // Strip punctuation (except hyphens), replace spaces with dashes, lowercase
            var slug = val
                .toLowerCase()
                .replace(/[^\w\s-]/g, '')   // remove punctuation
                .replace(/\s+/g, '-')        // spaces → dashes
                .replace(/-+/g, '-')         // collapse multiple dashes
                .replace(/^-|-$/g, '');      // trim leading/trailing dashes
            preview.textContent = slug || 'your-page-name';
        });
    })();
</script>

<?php get_footer(); ?>