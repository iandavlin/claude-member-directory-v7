<?php
/**
 * Business Section Template
 * Fields: Business Name, Logo, Services, Contact Info, Hours, Location
 */

if (!defined('ABSPATH'))
    exit;

/* ============================================
   SECTION VARIABLES
   ============================================ */
$section = get_query_var('memdir_section'); // should be 'business'
$post_id = get_query_var('memdir_post_id');
$viewer_mode = get_query_var('memdir_viewer_mode');

?>

<section class="memdir-section memdir-section-business" data-section="business">

    <div class="memdir-section-inner">

        <h2 class="memdir-section-title">Business / Shop</h2>

        <?php if ($viewer_mode === 'edit'): ?>

            <!-- EDIT MODE — Privacy is managed via the ACF Privacy tab -->

            <!-- ACF Form -->
            <?php if (function_exists('acf_form')): ?>
                <div class="memdir-acf-form-wrapper">
                    <?php
                    acf_form(array(
                        'post_id' => $post_id,
                        'field_groups' => array('group_md_05_business'),
                        'form' => true,
                        'return' => '%post_url%?mode=edit',
                        'submit_value' => 'Save Business',
                        'updated_message' => '<div class="memdir-success-message">✓ Business info saved!</div>',
                        'html_before_fields' => '<div class="memdir-acf-fields">',
                        'html_after_fields' => '</div>',
                    ));
                    ?>
                </div>
            <?php else: ?>
                <div class="memdir-notice memdir-notice-error">
                    <p>ACF Pro Required.</p>
                </div>
            <?php endif; ?>

        <?php else: ?>

            <!-- ============================================
                 DISPLAY MODE — Auto-rendered from ACF group
                 Reads the live ACF field definitions and renders
                 each field by type (text, image, gallery, taxonomy,
                 google_map, repeater, url, etc.)
                 ============================================ -->

            <div class="memdir-section-content memdir-business-card">
                <?php
                // Exclude fields already rendered by header-business.php
                // and control toggles that aren't meaningful in display mode
                memdir_render_section_content($post_id, 'business', $viewer_mode, array(
                    memdir_field('business_name'),
                    memdir_field('business_logo'),
                    'member_directory_has_booking_app', // toggle for booking URL — the URL itself is enough
                ));
                ?>
            </div>

        <?php endif; ?>

    </div>

</section>