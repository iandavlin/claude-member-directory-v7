<?php
/**
 * Profile Section Template
 * ACF Forms with Custom Privacy Controls
 * Fields: Avatar Image, Cover Image, Bio, Featured Video, Social Links
 * 
 * BLOCK MARKERS: Used for easy navigation and updates
 */

if (!defined('ABSPATH'))
    exit;

/* ============================================
   SECTION VARIABLES
   ============================================ */
$section = get_query_var('memdir_section');
$post_id = get_query_var('memdir_post_id');
$viewer_mode = get_query_var('memdir_viewer_mode');

?>

<section class="memdir-section memdir-section-profile" data-section="profile">

    <div class="memdir-section-inner">

        <h2 class="memdir-section-title">Profile</h2>

        <?php if ($viewer_mode === 'edit'): ?>

            <!-- ============================================
                 EDIT MODE — Privacy is managed via the ACF Privacy tab
                 ============================================ -->

            <!-- ============================================
                 BEGIN: ACF Form
                 Native ACF form rendering
                 ============================================ -->
            <?php if (function_exists('acf_form')): ?>

                <div class="memdir-acf-form-wrapper">
                    <?php
                    acf_form(array(
                        'post_id' => $post_id,
                        'field_groups' => array('group_md_02_profile'),
                        'post_title' => false, // Page Name is now an ACF field in the group
                        'form' => true,
                        // IMPORTANT: Use %post_url% placeholder, NOT get_permalink().
                        // get_permalink() is evaluated at render time (before the save),
                        // so it would redirect to the OLD URL after a slug change.
                        // %post_url% is resolved by ACF *after* the post is saved,
                        // so it picks up the new slug from wp_insert_post_data.
                        'return' => '%post_url%?mode=edit',
                        'submit_value' => 'Save Profile',
                        'updated_message' => '<div class="memdir-success-message">✓ Profile saved successfully!</div>',
                        'html_before_fields' => '<div class="memdir-acf-fields">',
                        'html_after_fields' => '</div>',
                    ));
                    ?>
                </div>

                <!-- Social Links are now ACF fields in Group 02, rendered by acf_form() above -->

            <?php else: ?>

                <div class="memdir-notice memdir-notice-error">
                    <p><strong>ACF Pro Required.</strong> Advanced Custom Fields Pro is required to edit profiles.</p>
                </div>

            <?php endif; ?>
            <!-- END: ACF Form -->

            <!-- END: EDIT MODE -->

        <?php else: ?>

            <!-- ============================================
                 BEGIN: DISPLAY MODE
                 Show field values with PMP checks
                 Used for Member and Public views
                 Fields are now rendered dynamically from ACF.
                 ============================================ -->

            <div class="memdir-section-content">
                <?php
                // Avatar and cover are rendered by header-profile,
                // so exclude them from the section body.
                memdir_render_section_content($post_id, 'profile', $viewer_mode, array(
                    memdir_field('avatar'),
                    memdir_field('cover_image'),
                    memdir_field('full_name'),
                ));
                ?>
            </div>

            <!-- END: DISPLAY MODE -->

        <?php endif; ?>

    </div>

</section>