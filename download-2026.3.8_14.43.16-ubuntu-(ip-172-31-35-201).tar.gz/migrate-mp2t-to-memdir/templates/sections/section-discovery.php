<?php
/**
 * Discovery Section Template
 * Fields: Instruments, Musical Contexts, Knowledge Domains
 */

if (!defined('ABSPATH'))
    exit;

/* ============================================
   SECTION VARIABLES
   ============================================ */
$section = get_query_var('memdir_section');
$post_id = get_query_var('memdir_post_id');
$viewer_mode = get_query_var('memdir_viewer_mode');

?>

<section class="memdir-section memdir-section-discovery" data-section="discovery">

    <div class="memdir-section-inner">

        <h2 class="memdir-section-title">Discovery</h2>
        <p class="memdir-section-subtitle">What I play, know, and do.</p>

        <?php if ($viewer_mode === 'edit'): ?>

            <!-- EDIT MODE — Privacy is managed via the ACF Privacy tab -->

            <?php if (function_exists('acf_form')): ?>
                <div class="memdir-acf-form-wrapper">
                    <?php
                    acf_form(array(
                        'post_id' => $post_id,
                        'field_groups' => array('group_md_03_craft'),
                        'form' => true,
                        'return' => '%post_url%?mode=edit',
                        'submit_value' => 'Save Discovery',
                        'updated_message' => '<div class="memdir-success-message">✓ Discovery info saved!</div>',
                        'html_before_fields' => '<div class="memdir-acf-fields">',
                        'html_after_fields' => '</div>',
                    ));
                    ?>
                </div>
            <?php endif; ?>

        <?php else: ?>

            <!-- DISPLAY MODE -->
            <div class="memdir-section-content">
                <?php memdir_render_section_content($post_id, 'discovery', $viewer_mode); ?>
            </div>

        <?php endif; ?>

    </div>

</section>