<?php
/**
 * Vibe Section Template
 * Fields: Overview, Personality, Working Style
 */

if (!defined('ABSPATH'))
    exit;

$section = get_query_var('memdir_section');
$post_id = get_query_var('memdir_post_id');
$viewer_mode = get_query_var('memdir_viewer_mode');

?>

<section class="memdir-section memdir-section-vibe" data-section="vibe">

    <div class="memdir-section-inner">

        <h2 class="memdir-section-title">Vibe Check</h2>
        <p class="memdir-section-subtitle">What it's like to work with me.</p>

        <?php if ($viewer_mode === 'edit'): ?>

            <!-- EDIT MODE — Privacy is managed via the ACF Privacy tab -->

            <?php if (function_exists('acf_form')): ?>
                <div class="memdir-acf-form-wrapper">
                    <?php
                    acf_form(array(
                        'post_id' => $post_id,
                        'field_groups' => array('group_md_08_vibe'),
                        'form' => true,
                        'return' => '%post_url%?mode=edit',
                        'submit_value' => 'Save Vibe',
                        'updated_message' => '<div class="memdir-success-message">✓ Vibe info saved!</div>',
                        'html_before_fields' => '<div class="memdir-acf-fields">',
                        'html_after_fields' => '</div>',
                    ));
                    ?>
                </div>
            <?php endif; ?>

        <?php else: ?>

            <div class="memdir-section-content">
                <?php memdir_render_section_content($post_id, 'vibe', $viewer_mode); ?>
            </div>

        <?php endif; ?>

    </div>

</section>