<?php
/**
 * Single Member Directory Template
 * Displays the complete profile with all sections
 */

if (!defined('ABSPATH'))
    exit;

// Compute viewer mode early (safe before get_header — no template dependencies)
$post_id = get_the_ID();
$viewer_mode = memdir_get_viewer_mode($post_id);

// Initialize ACF only in edit mode (forms are only rendered for owners)
if ($viewer_mode === 'edit' && function_exists('acf_form_head')) {
    acf_form_head();
}

get_header();

$can_edit = memdir_can_edit($post_id);
$sections = memdir_get_ordered_sections($post_id, $viewer_mode);

// Pass shared variables to all included templates via query vars (explicit scope)
set_query_var('memdir_post_id', $post_id);
set_query_var('memdir_viewer_mode', $viewer_mode);

// Determine which header to show on initial load
// User preference (saved as post meta), defaults to 'personal'
$default_header = get_post_meta($post_id, memdir_field('default_header'), true);
if (!$default_header) {
    $default_header = 'personal';
}

// Business header can only be promoted if the section exists and has content
$business_available = (memdir_is_section_enabled($post_id, 'business')
    && Memdir_PMP_Visibility::section_has_content($post_id, 'business', $viewer_mode));

// In edit mode, always show profile header. Otherwise, respect the preference.
$business_promoted = ($viewer_mode !== 'edit'
    && $business_available
    && $default_header === 'business');

?>

<div class="memdir-wrap" data-viewer-mode="<?php echo esc_attr($viewer_mode); ?>"
    data-default-header="<?php echo esc_attr($default_header); ?>">


    <?php if ($can_edit): ?>
        <!-- System Sidebar (only for owners/admins) -->
        <aside class="memdir-sidebar" role="complementary" aria-label="Profile controls">
            <div class="memdir-sidebar-inner">

                <div class="memdir-sidebar-header">
                    <h3>Controls</h3>
                </div>

                <!-- View Mode Toggle -->
                <div class="memdir-sidebar-section">
                    <h4>View as</h4>
                    <div class="memdir-view-modes">
                        <?php
                        $modes = array(
                            'edit' => 'Edit',
                            'member' => 'Member',
                            'public' => 'Public'
                        );

                        foreach ($modes as $mode => $label):
                            $is_active = ($viewer_mode === $mode);
                            $url = add_query_arg('mode', $mode, get_permalink($post_id));
                            $class = $is_active ? 'memdir-view-mode active' : 'memdir-view-mode';
                            ?>
                            <a href="<?php echo esc_url($url); ?>" class="<?php echo esc_attr($class); ?>">
                                <?php echo esc_html($label); ?>
                                <?php if ($is_active)
                                    echo '<span class="current-indicator">→</span>'; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($viewer_mode !== 'edit'): ?>
                        <a href="<?php echo esc_url(add_query_arg('mode', $viewer_mode, get_permalink($post_id))); ?>"
                            class="memdir-update-preview-btn">
                            🔄 Update Preview
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Global Privacy Default -->
                <div class="memdir-sidebar-section">
                    <h4>Global Default</h4>
                    <?php
                    $global_pmp = Memdir_PMP_Visibility::get_global_pmp($post_id);
                    ?>
                    <?php $global_pmp_field = memdir_field('member_pmp_default'); ?>
                    <div class="memdir-pmp-buttons">
                        <button type="button"
                            class="memdir-pmp-btn <?php echo ($global_pmp === 'public') ? 'active' : ''; ?>"
                            data-value="public" data-field="<?php echo esc_attr($global_pmp_field); ?>">
                            🌍 Public
                        </button>
                        <button type="button"
                            class="memdir-pmp-btn <?php echo ($global_pmp === 'members') ? 'active' : ''; ?>"
                            data-value="members" data-field="<?php echo esc_attr($global_pmp_field); ?>">
                            👥 Members
                        </button>
                        <button type="button"
                            class="memdir-pmp-btn <?php echo ($global_pmp === 'private') ? 'active' : ''; ?>"
                            data-value="private" data-field="<?php echo esc_attr($global_pmp_field); ?>">
                            🔒 Private
                        </button>
                    </div>
                </div>

                <!-- Default Header Preference -->
                <?php if (memdir_is_section_enabled($post_id, 'business')): ?>
                    <div class="memdir-sidebar-section">
                        <h4>Default Header</h4>
                        <p class="memdir-sidebar-hint">Which header do visitors see first?</p>
                        <div class="memdir-header-pref">
                            <select class="memdir-header-pref-select" data-field="memdir_default_header">
                                <option value="personal" <?php selected($default_header, 'personal'); ?>>👤 Personal</option>
                                <option value="business" <?php selected($default_header, 'business'); ?>>🏢 Business</option>
                            </select>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Section Enable Toggles -->
                <div class="memdir-sidebar-section">
                    <h4>Enable Sections</h4>
                    <?php foreach ($sections as $key => $section):
                        if ($key === 'profile')
                            continue; // Profile always enabled
                        $enabled = memdir_is_section_enabled($post_id, $key);
                        ?>
                        <label class="memdir-toggle">
                            <input type="checkbox" class="memdir-section-toggle" data-section="<?php echo esc_attr($key); ?>"
                                <?php checked($enabled); ?>>
                            <span><?php echo esc_html($section['label']); ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>

                <?php
                // Profile Completeness Widget (edit mode only)
                include MEMDIR_PLUGIN_DIR . 'templates/components/profile-completeness.php';
                ?>

                <!-- Refresh Button — helps less savvy users see changes after saving -->
                <div class="memdir-sidebar-section memdir-sidebar-refresh">
                    <a href="<?php echo esc_url(add_query_arg(null, null)); ?>" class="memdir-refresh-btn">
                        🔄 Refresh Page
                    </a>
                    <p class="memdir-sidebar-hint">Reload after making changes to see updates.</p>
                </div>

            </div>
        </aside>
    <?php endif; ?>

    <!-- Main Content Area -->
    <main class="memdir-main" role="main">

        <?php
        // Preview notice — shown when owners/admins preview as member/public
        include MEMDIR_PLUGIN_DIR . 'templates/components/preview-notice.php';
        ?>

        <!-- Debug Info (only shown when WP_DEBUG is true) -->
        <?php if (defined('WP_DEBUG') && WP_DEBUG): ?>
            <div class="memdir-debug">
                <strong>Debug:</strong>
                Mode: <?php echo esc_html($viewer_mode); ?> |
                Post: <?php echo esc_html($post_id); ?>
            </div>
        <?php endif; ?>

        <!-- Profile Header (hidden when business is promoted for public/member views) -->
        <div class="memdir-profile-header-wrap" <?php if ($business_promoted)
            echo 'style="display: none;"'; ?>>
            <?php include MEMDIR_PLUGIN_DIR . 'templates/components/header-profile.php'; ?>
        </div>

        <!-- Business Header (shown when promoted, toggled via JS on pill click) -->
        <?php if (memdir_is_section_enabled($post_id, 'business')): ?>
            <?php
            set_query_var('memdir_business_promoted', $business_promoted);
            include MEMDIR_PLUGIN_DIR . 'templates/components/header-business.php';
            ?>
        <?php endif; ?>

        <!-- Navigation Pills (Edit mode only — viewers see all sections flowing naturally) -->
        <?php if ($viewer_mode === 'edit'): ?>
            <nav class="memdir-nav-pills" role="navigation" aria-label="Profile sections">
                <!-- All Sections Pill (scroll mode) -->
                <button type="button" class="memdir-pill memdir-pill-all active" data-section="all">
                    ☰ All Sections
                </button>

                <?php foreach ($sections as $key => $section):
                    // Check if section should be visible
                    if (!memdir_is_section_enabled($post_id, $key)) {
                        continue;
                    }
                    ?>
                    <button type="button" class="memdir-pill" data-section="<?php echo esc_attr($key); ?>">
                        <?php echo esc_html($section['label']); ?>
                    </button>
                <?php endforeach; ?>
            </nav>
        <?php endif; ?>

        <!-- Sections Container -->
        <div class="memdir-sections-container">
            <?php
            // Load each section template
            foreach ($sections as $key => $section):

                // Check if section should be rendered
                if (!memdir_is_section_enabled($post_id, $key)) {
                    continue;
                }

                // In preview modes, check if section has content
                if ($viewer_mode !== 'edit' && !Memdir_PMP_Visibility::section_has_content($post_id, $key, $viewer_mode)) {
                    continue;
                }

                // Load the section template
                $template_path = MEMDIR_PLUGIN_DIR . 'templates/sections/' . $section['template'];

                if (file_exists($template_path)) {
                    // Make variables available to section template
                    set_query_var('memdir_section', $key);
                    set_query_var('memdir_post_id', $post_id);
                    set_query_var('memdir_viewer_mode', $viewer_mode);

                    include $template_path;
                } else {
                    echo '<div class="memdir-section-error">';
                    echo '<p>Template not found: ' . esc_html($section['template']) . '</p>';
                    echo '</div>';
                }

            endforeach;
            ?>
        </div>


        <?php
        // Portfolio Gallery — images of instruments/work
        include MEMDIR_PLUGIN_DIR . 'templates/components/portfolio-gallery.php';
        ?>

        <?php
        // View counter — shown to profile owner in edit mode
        if ($viewer_mode === 'edit'):
            $view_count = memdir_get_profile_views($post_id);
            ?>
            <div class="memdir-view-counter">
                👁️ <?php echo esc_html(number_format_i18n($view_count)); ?> profile
                view<?php echo $view_count !== 1 ? 's' : ''; ?>
            </div>
        <?php endif; ?>

        <?php
        // Similar members — shown to visitors (not profile owner)
        include MEMDIR_PLUGIN_DIR . 'templates/components/similar-members.php';
        ?>

        <?php
        // Trusted repair network — shown on member/public views
        include MEMDIR_PLUGIN_DIR . 'templates/components/trusted-network.php';
        ?>

        <?php
        // Vouch summary — private widget shown only in edit mode
        include MEMDIR_PLUGIN_DIR . 'templates/components/vouch-summary.php';
        ?>

    </main>

</div><!-- .memdir-wrap --><?php get_footer(); ?>