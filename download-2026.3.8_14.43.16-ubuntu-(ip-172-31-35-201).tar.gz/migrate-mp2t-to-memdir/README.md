# MP2T Member Directory

A WordPress plugin for managing member profiles within the MP2T community.

## Requirements

- **WordPress** 6.0+
- **ACF Pro** (Advanced Custom Fields Pro) — hard dependency
- **BuddyBoss Platform** — soft dependency (optional integration)

## Installation

1. Upload the `mp2t-member-directory-v3` folder to `wp-content/plugins/`
2. Ensure ACF Pro is installed and activated
3. Activate "MP2T Member Directory" from the Plugins page
4. ACF field groups will auto-load from `acf-json/`

## Features

- **7 Profile Sections**: Profile, Discovery, Connect, Business, Workspace, Experience, Vibe Check
- **Hierarchical Privacy (PMP)**: Global → Section → Field cascade with 3 visibility levels (Public, Members, Private)
- **3 Viewer Modes**: Edit (owner/admin), Member (logged-in), Public (anonymous)
- **Social Link Sync**: Bi-directional sync between user meta and post meta
- **BuddyBoss Tab**: Optional "Member Profile" tab in BuddyBoss user profiles
- **5 Custom Taxonomies**: Instruments, Musical Contexts, Knowledge Domains, Services, Equipment
- **Contact Form**: Visitors can message members directly (routed via `wp_mail`, rate-limited)
- **Profile View Counter**: Tracks unique views per 24h session (excludes owner visits)
- **Similar Members**: Shows 2–3 profiles sharing taxonomy terms for cross-discovery
- **Admin Dashboard Widget**: Overview of directory stats, completeness, and most-viewed profiles
- **Open Graph for Instagram**: Rich link previews optimized for Instagram bios, stories, and DMs
- **Dark Mode Toggle**: Persistent dark theme via CSS custom property swap + localStorage

## File Structure

```
mp2t-member-directory-v3/
├── mp2t-member-directory.php       # Main plugin file
├── acf-json/                       # ACF field group definitions (9 groups)
├── assets/
│   ├── css/profile-styles.css      # All plugin styles
│   └── js/
│       ├── profile-core.js         # Navigation, headers, social links
│       ├── pmp-controls.js         # Privacy management (edit mode only)
│       └── directory-search.js     # Archive search & filter AJAX
├── includes/
│   ├── classes/
│   │   ├── class-pmp-visibility.php        # Privacy cascade logic
│   │   ├── class-ajax-handler.php          # AJAX endpoints (search, contact, PMP)
│   │   ├── class-schema-output.php         # JSON-LD + Open Graph meta tags
│   │   ├── class-profile-completeness.php  # Profile progress tracker
│   │   ├── class-admin-dashboard.php       # WP dashboard stats widget
│   │   └── class-buddyboss-integration.php # BuddyBoss tab
│   └── functions/
│       ├── functions-setup.php           # Post type, taxonomies, assets
│       ├── functions-setup-flow.php      # New profile creation
│       ├── functions-social-sync.php     # Social link sync
│       ├── functions-profile-views.php   # View counter tracking
│       └── helpers.php                   # Viewer mode, permissions, utilities
└── templates/
    ├── single-member-directory.php       # Main profile template
    ├── archive-member-directory.php      # Directory listing page
    ├── sections/                         # 7 section templates
    └── components/                       # Shared partials (headers, cards, contact form, similar members)
```

## Privacy System (PMP)

The Profile Member Privacy system uses a 4-gate check:

1. **Gate 1**: Is the section enabled?
2. **Gate 2**: Does the viewer have permission? (edit mode bypasses all gates)
3. **Gate 3**: Does the effective PMP value allow viewing?
4. **Gate 4**: Is there content to display?

Privacy cascades: **Global Default** → **Section Override** → **Field Override**

## Development

Define `MP2T_DEBUG` as `true` in `wp-config.php` to enable debug logging:

```php
define('MP2T_DEBUG', true);
```

Logs are written to `wp-content/debug.log` (requires `WP_DEBUG_LOG` to be on).

## License

Proprietary — MP2T Community
