# MP2T Member Directory — Handoff

> Last updated: 2026-02-20

---

## Goal

Enable members to **create, name, and rename** their Member Directory profile pages — with the URL slug always staying in sync with the page name. The system should be:
- **Opt-in** — profiles are only created when users actively choose to, not auto-generated
- **Self-service** — members can change their page name (and thus URL) from the front-end edit form
- **Seamless** — after saving a name change, the browser redirects to the new URL without a full page reload or 404

---

## Where We Are

All implementation is **complete**. The remaining item is **manual verification** on a live or staging WordPress instance.

---

## What We've Done

### 1. Opt-in Profile Creation Flow
- Rewrote [setup-profile.php](file:///c:/Users/tedbe/OneDrive/Documents/Code/Looth%20Group%20Business%20Page/mp2t-member-directory/templates/setup-profile.php) — a single "Page Name" input + plain HTML form (no ACF dependency at creation time)
- [functions-setup-flow.php](file:///c:/Users/tedbe/OneDrive/Documents/Code/Looth%20Group%20Business%20Page/mp2t-member-directory/includes/functions/functions-setup-flow.php) intercepts `?memdir_setup=1`, shows the form for new users, and redirects existing users to edit mode

### 2. Page Name as a Proper ACF Field
- Added `field_md_profile_page_name` (text, required) to [group_md_02_profile.json](file:///c:/Users/tedbe/OneDrive/Documents/Code/Looth%20Group%20Business%20Page/acf-json-import/group_md_02_profile.json) as the first tab/field in the Profile group
- Set `'post_title' => false` in [section-profile.php](file:///c:/Users/tedbe/OneDrive/Documents/Code/Looth%20Group%20Business%20Page/mp2t-member-directory/templates/sections/section-profile.php) — the ACF field replaces the built-in title input
- Setup form seeds the ACF field via `update_field()` on post creation

### 3. Slug Sync — Dual-Hook Approach
Located in [functions-setup.php](file:///c:/Users/tedbe/OneDrive/Documents/Code/Looth%20Group%20Business%20Page/mp2t-member-directory/includes/functions/functions-setup.php) (lines 568–664):

| Hook | Priority | Purpose |
|------|----------|---------|
| `wp_insert_post_data` filter | 99 | Catches non-ACF saves (setup form, admin). Syncs `post_name` to `post_title` before DB write. Uses `wp_unslash()` to handle apostrophes. |
| `acf/save_post` action | 20 | Catches ACF front-end form saves. Reads `member_directory_page_name` ACF field, syncs **both** `post_title` and `post_name`. Includes backward-compat migration for existing profiles without the ACF field. Uses `remove_action`/`add_action` to prevent infinite loops. |

### 4. Redirect After Save
- All 10 section templates use `'return' => '%post_url%?mode=edit'` — ACF resolves `%post_url%` **after** the save, so it picks up the new slug
- Previously used `get_permalink($post_id)` which evaluated **before** save → redirected to old URL

### 5. CSS Cleanup
- Removed the old CSS hack in [profile-styles.css](file:///c:/Users/tedbe/OneDrive/Documents/Code/Looth%20Group%20Business%20Page/mp2t-member-directory/assets/css/profile-styles.css) that hid the "Title" label and faked "Page Name" via `::after`
- Replaced with clean styles targeting `[data-name="member_directory_page_name"]`

---

## What Needs To Be Done

### Immediate — Manual Verification
1. **Re-import the ACF JSON**: WP Admin → ACF → Tools → Import → select `acf-json-import/group_md_02_profile.json`
2. **Test slug update**: Edit Page Name on Profile tab → save → verify redirect to new URL in edit mode
3. **Test new profile creation**: Visit `?memdir_setup=1` → enter a name → verify post is created with correct slug and ACF field populated
4. **Test existing profile redirect**: Visit `?memdir_setup=1` when profile exists → verify redirect to edit mode
5. **Test special characters**: Use a name like "Ted's Shop" → verify slug is `teds-shop` (not `ted-s-shop`)
6. **Test backward compat**: For an existing profile that was created *before* the ACF field was added, save the profile form → verify the ACF field auto-seeds from the existing post title

### Later — Possible Improvements
- **Slug collision handling**: If two members choose the same page name, WordPress appends `-2`, `-3` etc. Consider adding a user-facing warning or preview of the final slug
- **Old URL redirects**: When a slug changes, old URLs 404. Consider adding a `301` redirect from old slug → new slug (via a `_wp_old_slug` lookup or custom redirect table)
- **Page Name in other sections**: Currently only the Profile section shows the Page Name field. Consider whether it should appear in a global/shared location visible from all sections

---

## Key Files Reference

| File | Role |
|------|------|
| `templates/setup-profile.php` | Onboarding — single-field form, creates post |
| `templates/sections/section-profile.php` | Profile edit — ACF form with Page Name field |
| `includes/functions/functions-setup.php` | Slug sync hooks (lines 568–664) |
| `includes/functions/functions-setup-flow.php` | `?memdir_setup=1` routing logic |
| `acf-json-import/group_md_02_profile.json` | ACF field group definition (importable) |
| `assets/css/profile-styles.css` | Page Name field styling (end of file) |
