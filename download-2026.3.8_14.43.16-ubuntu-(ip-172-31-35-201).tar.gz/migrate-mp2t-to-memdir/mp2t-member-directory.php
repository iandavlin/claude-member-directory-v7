<?php
/**
 * Plugin Name: Member Directory
 * Description: Advanced member profile system with hierarchical privacy controls
 * Version: 1.2.0
 * Author: The Looth Group
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH'))
    exit;

// Plugin constants
define('MEMDIR_VERSION', '1.3.1');
define('MEMDIR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MEMDIR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MEMDIR_MAP_CACHE_VERSION', 'v3');

// ── M1 Fix: Runtime ACF availability guard ──────────────────────────
// The activation hook blocks initial activation without ACF, but if ACF
// is deactivated *after* this plugin is active, we must degrade gracefully
// rather than trigger fatal errors from get_field() calls in templates.
if (!function_exists('get_field')) {
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p>';
        echo '<strong>Member Directory</strong> requires ';
        echo '<strong>Advanced Custom Fields PRO</strong> to be active. ';
        echo 'Profile features are disabled until ACF Pro is reactivated.';
        echo '</p></div>';
    });
    return; // Bail — no CPT, no templates, no AJAX. Reactivate ACF to restore.
}

// Load dependencies
require_once MEMDIR_PLUGIN_DIR . 'includes/acf-field-groups.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/functions/functions-field-map.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/functions/helpers.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/functions/functions-setup.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/functions/functions-field-renderer.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/functions/functions-social-sync.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/functions/functions-setup-flow.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/classes/class-pmp-visibility.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/classes/class-ajax-handler.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/classes/class-schema-output.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/classes/class-profile-completeness.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/classes/class-admin-dashboard.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/functions/functions-profile-views.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/functions/functions-data-export.php';
require_once MEMDIR_PLUGIN_DIR . 'includes/classes/class-endorsements.php';

// One-time migration script (delete after running)
if (is_admin() && file_exists(MEMDIR_PLUGIN_DIR . 'migrate-mp2t-to-memdir.php')) {
    require_once MEMDIR_PLUGIN_DIR . 'migrate-mp2t-to-memdir.php';
}

/**
 * ACF Local JSON — Register save path
 *
 * Tells ACF where to write updated field group JSON when saved in admin.
 * The load path is already registered in functions-setup.php (Finding #8).
 */
function memdir_acf_json_save_point($path)
{
    return MEMDIR_PLUGIN_DIR . 'acf-json';
}
add_filter('acf/settings/save_json', 'memdir_acf_json_save_point');

/**
 * Plugin activation
 */
function memdir_activate()
{
    // Finding #7: ACF activation check — DOCs require ACF Pro
    if (!function_exists('acf_add_local_field_group')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            'Member Directory requires <strong>Advanced Custom Fields PRO</strong> to be installed and activated.',
            'Plugin Activation Error',
            array('back_link' => true)
        );
    }

    memdir_register_post_type();
    memdir_register_taxonomies();
    Memdir_Endorsements::create_table();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'memdir_activate');

/**
 * Plugin deactivation
 */
function memdir_deactivate()
{
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'memdir_deactivate');

/**
 * Initialize Plugin Classes
 */
function memdir_init_classes()
{
    new Memdir_Ajax_Handler();
    new Memdir_Schema_Output();
    new Memdir_Admin_Dashboard();
    Memdir_Endorsements::register();

    // BuddyBoss integration (soft dependency)
    if (function_exists('bp_is_active')) {
        require_once MEMDIR_PLUGIN_DIR . 'includes/classes/class-buddyboss-integration.php';
        new Memdir_BuddyBoss_Integration();
    }
}
add_action('plugins_loaded', 'memdir_init_classes');

