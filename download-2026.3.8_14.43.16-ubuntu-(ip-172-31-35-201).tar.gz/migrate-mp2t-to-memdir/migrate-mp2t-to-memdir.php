<?php
/**
 * Database Migration: mp2t_ → memdir_
 *
 * Renames all database-stored identifiers from the old "mp2t_" prefix
 * to the new "memdir_" prefix. Run this ONCE after deploying the renamed code.
 *
 * Usage:
 *   1. Upload this file to the plugin root (mp2t-member-directory/)
 *   2. Visit: /wp-admin/admin.php?page=memdir-migrate&confirm=yes
 *   3. Review the output
 *   4. Delete this file after successful migration
 *
 * Safety:
 *   - Each step is idempotent (safe to run multiple times)
 *   - Does NOT delete old data until explicitly confirmed
 *   - Outputs counts for verification
 *
 * @since 1.3.0
 */

if (!defined('ABSPATH'))
    exit;

// Register a temporary admin page for the migration
add_action('admin_menu', function () {
    add_management_page(
        'Member Directory Migration',
        'MEMDIR Migration',
        'manage_options',
        'memdir-migrate',
        'memdir_run_migration'
    );
});

function memdir_run_migration()
{
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized');
    }

    $confirm = isset($_GET['confirm']) && $_GET['confirm'] === 'yes';
    $cleanup = isset($_GET['cleanup']) && $_GET['cleanup'] === 'yes';

    echo '<div class="wrap">';
    echo '<h1>Member Directory — Database Migration</h1>';
    echo '<p>Migrating database identifiers from <code>mp2t_</code> to <code>memdir_</code>.</p>';

    if (!$confirm) {
        echo '<div class="notice notice-warning"><p>';
        echo '<strong>Dry run mode.</strong> No changes will be made. ';
        echo 'Review the counts below, then <a href="' . esc_url(admin_url('tools.php?page=memdir-migrate&confirm=yes')) . '">click here to run the migration</a>.';
        echo '</p></div>';
    }

    global $wpdb;
    $results = array();

    // ─── 1. Taxonomy Slugs ──────────────────────────────────────────
    echo '<h2>1. Taxonomy Slugs</h2>';
    $tax_map = array(
        'mp2t_instruments' => 'memdir_instruments',
        'mp2t_musical_contexts' => 'memdir_musical_contexts',
        'mp2t_knowledge_domains' => 'memdir_knowledge_domains',
        'mp2t_services' => 'memdir_services',
        'mp2t_equipment' => 'memdir_equipment',
    );

    foreach ($tax_map as $old => $new) {
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->term_taxonomy} WHERE taxonomy = %s",
            $old
        ));
        $already = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->term_taxonomy} WHERE taxonomy = %s",
            $new
        ));

        echo "<p><code>{$old}</code> → <code>{$new}</code>: {$count} rows to migrate ({$already} already migrated)</p>";

        if ($confirm && $count > 0) {
            $updated = $wpdb->update(
                $wpdb->term_taxonomy,
                array('taxonomy' => $new),
                array('taxonomy' => $old)
            );
            echo "<p style='color:green'>✓ Updated {$updated} rows</p>";
            $results[] = "Taxonomy {$old}: {$updated} rows";
        }
    }

    // ─── 2. Post Meta Keys (PMP Override & Value) ───────────────────
    echo '<h2>2. Post Meta Keys</h2>';
    $meta_prefixes = array(
        'mp2t_pmp_override_' => 'memdir_pmp_override_',
        'mp2t_pmp_value_' => 'memdir_pmp_value_',
    );

    foreach ($meta_prefixes as $old_prefix => $new_prefix) {
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key LIKE %s",
            $wpdb->esc_like($old_prefix) . '%'
        ));
        $already = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key LIKE %s",
            $wpdb->esc_like($new_prefix) . '%'
        ));

        echo "<p><code>{$old_prefix}*</code> → <code>{$new_prefix}*</code>: {$count} rows to migrate ({$already} already migrated)</p>";

        if ($confirm && $count > 0) {
            // Use REPLACE to swap the prefix
            $updated = $wpdb->query($wpdb->prepare(
                "UPDATE {$wpdb->postmeta} SET meta_key = REPLACE(meta_key, %s, %s) WHERE meta_key LIKE %s",
                $old_prefix,
                $new_prefix,
                $wpdb->esc_like($old_prefix) . '%'
            ));
            echo "<p style='color:green'>✓ Updated {$updated} rows</p>";
            $results[] = "Post meta {$old_prefix}*: {$updated} rows";
        }
    }

    // ─── 3. User Meta Key ───────────────────────────────────────────
    echo '<h2>3. User Meta</h2>';
    $old_meta = 'mp2t_completeness_dismissed';
    $new_meta = 'memdir_completeness_dismissed';
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s",
        $old_meta
    ));
    $already = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s",
        $new_meta
    ));

    echo "<p><code>{$old_meta}</code> → <code>{$new_meta}</code>: {$count} rows ({$already} already migrated)</p>";

    if ($confirm && $count > 0) {
        $updated = $wpdb->update(
            $wpdb->usermeta,
            array('meta_key' => $new_meta),
            array('meta_key' => $old_meta)
        );
        echo "<p style='color:green'>✓ Updated {$updated} rows</p>";
        $results[] = "User meta: {$updated} rows";
    }

    // ─── 4. Endorsements Table Rename ───────────────────────────────
    echo '<h2>4. Endorsements Table</h2>';
    $old_table = $wpdb->prefix . 'mp2t_endorsements';
    $new_table = $wpdb->prefix . 'memdir_endorsements';

    $old_exists = $wpdb->get_var("SHOW TABLES LIKE '{$old_table}'") === $old_table;
    $new_exists = $wpdb->get_var("SHOW TABLES LIKE '{$new_table}'") === $new_table;

    if ($old_exists && !$new_exists) {
        echo "<p><code>{$old_table}</code> → <code>{$new_table}</code>: ready to rename</p>";
        if ($confirm) {
            $wpdb->query("RENAME TABLE `{$old_table}` TO `{$new_table}`");
            echo "<p style='color:green'>✓ Table renamed</p>";
            $results[] = "Table renamed: {$old_table} → {$new_table}";
        }
    } elseif ($new_exists) {
        echo "<p style='color:blue'>Already migrated: <code>{$new_table}</code> exists</p>";
    } elseif (!$old_exists && !$new_exists) {
        echo "<p style='color:orange'>Neither table exists — will be created on next activation</p>";
    }

    // ─── 5. Clean up old transients ─────────────────────────────────
    echo '<h2>5. Transient Cleanup</h2>';
    $old_transients = $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE '%mp2t_%'"
    );
    echo "<p>Old transients/options with 'mp2t_': {$old_transients}</p>";

    if ($confirm && $old_transients > 0) {
        // Delete old transients (they'll regenerate with new names)
        $deleted = $wpdb->query(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE '%_transient_mp2t_%'"
        );
        echo "<p style='color:green'>✓ Deleted {$deleted} old transient rows</p>";
        $results[] = "Transients cleaned: {$deleted}";

        // Also clean old rewrite version option
        delete_option('mp2t_rewrite_version');
        echo "<p style='color:green'>✓ Deleted old rewrite version option</p>";
    }

    // ─── Summary ────────────────────────────────────────────────────
    if ($confirm && count($results) > 0) {
        echo '<h2>✅ Migration Complete</h2>';
        echo '<div class="notice notice-success"><p>';
        echo '<strong>Summary:</strong><br>';
        echo implode('<br>', $results);
        echo '</p></div>';
        echo '<p><strong>Next steps:</strong></p>';
        echo '<ol>';
        echo '<li>Flush permalinks: Settings → Permalinks → Save Changes</li>';
        echo '<li>Deactivate and reactivate the Member Directory plugin</li>';
        echo '<li>Verify the site works correctly</li>';
        echo '<li>Delete this migration file: <code>migrate-mp2t-to-memdir.php</code></li>';
        echo '</ol>';
    } elseif ($confirm) {
        echo '<div class="notice notice-info"><p>No changes needed — everything appears already migrated.</p></div>';
    }

    echo '</div>';
}
