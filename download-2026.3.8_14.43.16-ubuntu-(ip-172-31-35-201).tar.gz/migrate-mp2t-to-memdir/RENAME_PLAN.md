# MP2T → MEMDIR Rename — COMPLETE ✅

## Status: All Tiers Complete

All code references have been migrated from `mp2t_` to `memdir_`.

### Naming Convention

| Context          | Old                    | New                          |
|------------------|------------------------|------------------------------|
| PHP functions    | `mp2t_*()`             | `memdir_*()`                 |
| PHP classes      | `MP2T_*`               | `Memdir_*`                   |
| PHP constants    | `MP2T_VERSION`, etc.   | `MEMDIR_VERSION`, etc.       |
| CSS classes      | `.mp2t-*`              | `.memdir-*`                  |
| JS namespaces    | `MP2T_Profile`, etc.   | `MEMDIR_Profile`, etc.       |
| JS localized data| `mp2tData`             | `memdirData`                 |
| AJAX actions     | `mp2t_save_pmp`, etc.  | `memdir_save_pmp`, etc.      |
| Nonces           | `mp2t_nonce`           | `memdir_nonce`               |
| Script handles   | `mp2t-profile-core`    | `memdir-profile-core`        |
| REST namespace   | `mp2t/v1`              | `memdir/v1`                  |
| Taxonomy slugs   | `mp2t_instruments`     | `memdir_instruments`         |
| Meta keys        | `mp2t_pmp_override_*`  | `memdir_pmp_override_*`      |
| User meta        | `mp2t_completeness_*`  | `memdir_completeness_*`      |
| DB table suffix  | `mp2t_endorsements`    | `memdir_endorsements`        |
| Plugin Name      | `MP2T Member Directory`| `Member Directory`           |

### Intentionally Unchanged (Tier 4)
- **Plugin directory**: `mp2t-member-directory/` (WordPress identifies plugins by path)
- **Plugin filename**: `mp2t-member-directory.php` (same reason)
- **Post type slug**: `member-directory` (already clean — never had mp2t prefix)

---

## Database Migration Required

After deploying the code, run the one-time migration script:

1. Go to: **Tools → MEMDIR Migration** in wp-admin
2. First visit shows a **dry run** with row counts
3. Click the link to **confirm** and execute the migration
4. Follow the post-migration steps (flush permalinks, reactivate plugin)
5. **Delete** `migrate-mp2t-to-memdir.php` after successful migration

The migration handles:
- Taxonomy slug renaming in `wp_term_taxonomy`
- Post meta key prefix swapping (`mp2t_pmp_override_*` → `memdir_pmp_override_*`)
- User meta key renaming (`mp2t_completeness_dismissed` → `memdir_completeness_dismissed`)
- Endorsements table rename (`wp_mp2t_endorsements` → `wp_memdir_endorsements`)
- Old transient cleanup
