<?php
/**
 * ACF Field Group Registration — Member Directory (v2)
 *
 * IMPORTANT: Field groups are now stored in the WordPress database (imported
 * via ACF → Tools → Import) so they can be edited by non-developers through
 * the WordPress admin interface.
 *
 * The JSON import files are located in:
 *   /acf-json-import/group_md_01_system.json
 *   /acf-json-import/group_md_02_profile.json
 *   /acf-json-import/group_md_03_craft.json
 *   /acf-json-import/group_md_04_connect.json
 *   /acf-json-import/group_md_05_business.json
 *   /acf-json-import/group_md_06_workspace.json
 *   /acf-json-import/group_md_07_experience.json
 *   /acf-json-import/group_md_08_vibe.json
 *
 * DO NOT re-enable the acf_add_local_field_group() calls below — doing so
 * will create read-only PHP-registered groups that override the editable
 * database versions and prevent your partner from making changes in WP Admin.
 *
 * Naming convention (still applies to the JSON files):
 *   Group keys:  group_md_{nn}_{section}
 *   Field keys:  field_md_{section}_{field}
 *   Field names: member_directory_{section}_{field}
 *   Privacy:     member_directory_{section}_privacy_mode / member_directory_{section}_privacy_level
 *   Toggles:     member_directory_enable_{section}
 *
 * @package Member_Directory
 */

if (!defined('ABSPATH'))
    exit;

// Field groups are now managed in the database. No PHP registration needed.
// add_action('acf/init', 'memdir_register_acf_field_groups');

function memdir_register_acf_field_groups()
{
    if (!function_exists('acf_add_local_field_group')) {
        return;
    }

    // ─────────────────────────────────────────────────────────
    // Group 01: System
    // ─────────────────────────────────────────────────────────
    acf_add_local_field_group(array(
        'key' => 'group_md_01_system',
        'title' => 'Member Directory — System',
        'fields' => array(
            array(
                'key' => 'field_md_global_privacy',
                'label' => 'Global Privacy Default',
                'name' => 'member_directory_global_privacy',
                'type' => 'select',
                'choices' => array(
                    'public' => 'Public',
                    'members' => 'Members Only',
                    'private' => 'Private',
                ),
                'default_value' => 'members',
            ),
            array(
                'key' => 'field_md_display_name',
                'label' => 'Display Name',
                'name' => 'member_directory_display_name',
                'type' => 'text',
            ),
            array(
                'key' => 'field_md_tagline',
                'label' => 'Tagline',
                'name' => 'member_directory_tagline',
                'type' => 'text',
                'placeholder' => 'Acoustic repair specialist in Denver',
            ),
            array(
                'key' => 'field_md_availability',
                'label' => 'Availability',
                'name' => 'member_directory_availability',
                'type' => 'select',
                'choices' => array(
                    '' => '— Not Set —',
                    'available' => 'Available',
                    'limited' => 'Limited Availability',
                    'unavailable' => 'Unavailable',
                ),
                'allow_null' => 1,
            ),
            array(
                'key' => 'field_md_default_header',
                'label' => 'Default Header',
                'name' => 'member_directory_default_header',
                'type' => 'select',
                'choices' => array(
                    'personal' => 'Personal',
                    'business' => 'Business',
                ),
                'default_value' => 'personal',
            ),
            // ── Tab: Section Toggles ──
            array(
                'key' => 'field_md_tab_section_toggles',
                'label' => 'Section Toggles',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_enable_craft',
                'label' => 'Enable Craft & Skills',
                'name' => 'member_directory_enable_craft',
                'type' => 'true_false',
                'default_value' => 1,
                'ui' => 1,
            ),
            array(
                'key' => 'field_md_enable_network',
                'label' => 'Enable Network',
                'name' => 'member_directory_enable_network',
                'type' => 'true_false',
                'default_value' => 0,
                'ui' => 1,
            ),
            array(
                'key' => 'field_md_enable_business',
                'label' => 'Enable Business',
                'name' => 'member_directory_enable_business',
                'type' => 'true_false',
                'default_value' => 0,
                'ui' => 1,
            ),
            array(
                'key' => 'field_md_enable_workshop',
                'label' => 'Enable Workshop',
                'name' => 'member_directory_enable_workshop',
                'type' => 'true_false',
                'default_value' => 0,
                'ui' => 1,
            ),
            array(
                'key' => 'field_md_enable_experience',
                'label' => 'Enable Experience',
                'name' => 'member_directory_enable_experience',
                'type' => 'true_false',
                'default_value' => 0,
                'ui' => 1,
            ),
            array(
                'key' => 'field_md_enable_vibe',
                'label' => 'Enable Vibe',
                'name' => 'member_directory_enable_vibe',
                'type' => 'true_false',
                'default_value' => 0,
                'ui' => 1,
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'member-directory',
                ),
            ),
        ),
        'position' => 'side',
        'menu_order' => 0,
        'style' => 'default',
        'active' => true,
    ));

    // ─────────────────────────────────────────────────────────
    // Group 02: Profile
    // ─────────────────────────────────────────────────────────
    acf_add_local_field_group(array(
        'key' => 'group_md_02_profile',
        'title' => 'Member Directory — Profile',
        'fields' => array(
            // ── Tab: Privacy ──
            array(
                'key' => 'field_md_tab_profile_privacy',
                'label' => 'Privacy',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_profile_privacy_mode',
                'label' => 'Privacy Mode',
                'name' => 'member_directory_profile_privacy_mode',
                'type' => 'button_group',
                'choices' => array(
                    'inherit' => 'Inherit Global',
                    'custom' => 'Custom',
                ),
                'default_value' => 'inherit',
            ),
            array(
                'key' => 'field_md_profile_privacy_level',
                'label' => 'Privacy Level',
                'name' => 'member_directory_profile_privacy_level',
                'type' => 'select',
                'choices' => array(
                    'public' => 'Public',
                    'members' => 'Members Only',
                    'private' => 'Private',
                ),
                'default_value' => 'members',
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_md_profile_privacy_mode',
                            'operator' => '==',
                            'value' => 'custom',
                        ),
                    ),
                ),
            ),
            // ── Tab: Header ──
            array(
                'key' => 'field_md_tab_profile_header',
                'label' => 'Header',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_profile_avatar',
                'label' => 'Profile Photo',
                'name' => 'member_directory_profile_avatar',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ),
            array(
                'key' => 'field_md_profile_cover',
                'label' => 'Cover Image',
                'name' => 'member_directory_profile_cover',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ),
            // ── Tab: About ──
            array(
                'key' => 'field_md_tab_profile_about',
                'label' => 'About',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_profile_bio',
                'label' => 'Bio',
                'name' => 'member_directory_profile_bio',
                'type' => 'textarea',
                'rows' => 6,
            ),
            array(
                'key' => 'field_md_profile_video',
                'label' => 'Featured Video',
                'name' => 'member_directory_profile_video',
                'type' => 'url',
                'placeholder' => 'https://youtube.com/watch?v=...',
            ),

            // ── Tab: Social Links ──
            array(
                'key' => 'field_md_tab_profile_social',
                'label' => 'Social Links',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_profile_website',
                'label' => 'Website',
                'name' => 'member_directory_profile_website',
                'type' => 'url',
            ),
            array(
                'key' => 'field_md_profile_instagram',
                'label' => 'Instagram',
                'name' => 'member_directory_profile_instagram',
                'type' => 'url',
            ),
            array(
                'key' => 'field_md_profile_facebook',
                'label' => 'Facebook',
                'name' => 'member_directory_profile_facebook',
                'type' => 'url',
            ),
            array(
                'key' => 'field_md_profile_youtube',
                'label' => 'YouTube',
                'name' => 'member_directory_profile_youtube',
                'type' => 'url',
            ),
            array(
                'key' => 'field_md_profile_linktree',
                'label' => 'Linktree',
                'name' => 'member_directory_profile_linktree',
                'type' => 'url',
            ),
            array(
                'key' => 'field_md_profile_social_privacy',
                'label' => 'Social Links Privacy',
                'name' => 'member_directory_profile_social_privacy',
                'type' => 'select',
                'choices' => array(
                    'inherit' => 'Inherit from Section',
                    'public' => 'Public',
                    'members' => 'Members Only',
                    'private' => 'Private',
                ),
                'default_value' => 'inherit',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'member-directory',
                ),
            ),
        ),
        'position' => 'normal',
        'menu_order' => 2,
        'style' => 'default',
        'active' => true,
    ));

    // ─────────────────────────────────────────────────────────
    // Group 03: Discovery (Craft & Skills)
    // ─────────────────────────────────────────────────────────
    acf_add_local_field_group(array(
        'key' => 'group_md_03_craft',
        'title' => 'Member Directory — Discovery',
        'fields' => array(
            // ── Tab: Privacy ──
            array(
                'key' => 'field_md_tab_craft_privacy',
                'label' => 'Privacy',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_craft_privacy_mode',
                'label' => 'Privacy Mode',
                'name' => 'member_directory_craft_privacy_mode',
                'type' => 'button_group',
                'choices' => array(
                    'inherit' => 'Inherit Global',
                    'custom' => 'Custom',
                ),
                'default_value' => 'inherit',
            ),
            array(
                'key' => 'field_md_craft_privacy_level',
                'label' => 'Privacy Level',
                'name' => 'member_directory_craft_privacy_level',
                'type' => 'select',
                'choices' => array(
                    'public' => 'Public',
                    'members' => 'Members Only',
                    'private' => 'Private',
                ),
                'default_value' => 'members',
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_md_craft_privacy_mode',
                            'operator' => '==',
                            'value' => 'custom',
                        ),
                    ),
                ),
            ),
            // ── Tab: Instruments ──
            array(
                'key' => 'field_md_tab_craft_instruments',
                'label' => 'Instruments',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_craft_instruments',
                'label' => 'Instruments I Work On',
                'name' => 'member_directory_craft_instruments',
                'type' => 'taxonomy',
                'taxonomy' => 'memdir_instruments',
                'field_type' => 'multi_select',
                'allow_null' => 1,
                'save_terms' => 1,
                'load_terms' => 1,
                'return_format' => 'id',
            ),
            array(
                'key' => 'field_md_craft_featured_instruments',
                'label' => 'Featured Instruments',
                'name' => 'member_directory_craft_featured_instruments',
                'type' => 'taxonomy',
                'taxonomy' => 'memdir_instruments',
                'field_type' => 'multi_select',
                'allow_null' => 1,
                'save_terms' => 0,
                'load_terms' => 0,
                'return_format' => 'id',
                'instructions' => 'Select up to 3 instruments to highlight in your header.',
            ),
            // ── Tab: Knowledge ──
            array(
                'key' => 'field_md_tab_craft_knowledge',
                'label' => 'Knowledge',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_craft_domains',
                'label' => 'Knowledge Domains',
                'name' => 'member_directory_craft_domains',
                'type' => 'taxonomy',
                'taxonomy' => 'memdir_knowledge_domains',
                'field_type' => 'multi_select',
                'allow_null' => 1,
                'save_terms' => 1,
                'load_terms' => 1,
                'return_format' => 'id',
            ),
            array(
                'key' => 'field_md_craft_contexts',
                'label' => 'Musical Contexts',
                'name' => 'member_directory_craft_contexts',
                'type' => 'taxonomy',
                'taxonomy' => 'memdir_musical_contexts',
                'field_type' => 'multi_select',
                'allow_null' => 1,
                'save_terms' => 1,
                'load_terms' => 1,
                'return_format' => 'id',
            ),
            // ── Tab: Level ──
            array(
                'key' => 'field_md_tab_craft_level',
                'label' => 'Level',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_craft_level',
                'label' => 'Experience Level',
                'name' => 'member_directory_craft_level',
                'type' => 'select',
                'choices' => array(
                    '' => '— Not Set —',
                    'student' => 'Student',
                    'hobbyist' => 'Hobbyist',
                    'apprentice' => 'Apprentice',
                    'journeyman' => 'Journeyman',
                    'professional' => 'Professional',
                    'master' => 'Master',
                ),
                'allow_null' => 1,
            ),
            array(
                'key' => 'field_md_craft_years',
                'label' => 'Years in the Craft',
                'name' => 'member_directory_craft_years',
                'type' => 'number',
                'min' => 0,
                'max' => 100,
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'member-directory',
                ),
            ),
        ),
        'position' => 'normal',
        'menu_order' => 3,
        'style' => 'default',
        'active' => true,
    ));

    // ─────────────────────────────────────────────────────────
    // Group 04: Connect (Network)
    // ─────────────────────────────────────────────────────────
    acf_add_local_field_group(array(
        'key' => 'group_md_04_connect',
        'title' => 'Member Directory — Connect',
        'fields' => array(
            // ── Tab: Privacy ──
            array(
                'key' => 'field_md_tab_network_privacy',
                'label' => 'Privacy',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_network_privacy_mode',
                'label' => 'Privacy Mode',
                'name' => 'member_directory_network_privacy_mode',
                'type' => 'button_group',
                'choices' => array(
                    'inherit' => 'Inherit Global',
                    'custom' => 'Custom',
                ),
                'default_value' => 'inherit',
            ),
            array(
                'key' => 'field_md_network_privacy_level',
                'label' => 'Privacy Level',
                'name' => 'member_directory_network_privacy_level',
                'type' => 'select',
                'choices' => array(
                    'public' => 'Public',
                    'members' => 'Members Only',
                    'private' => 'Private',
                ),
                'default_value' => 'members',
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_md_network_privacy_mode',
                            'operator' => '==',
                            'value' => 'custom',
                        ),
                    ),
                ),
            ),
            // ── Tab: Mentorship ──
            array(
                'key' => 'field_md_tab_network_mentorship',
                'label' => 'Mentorship',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_network_mentorship_status',
                'label' => 'Mentorship Status',
                'name' => 'member_directory_network_mentorship_status',
                'type' => 'select',
                'choices' => array(
                    '' => '— Not Set —',
                    'offering' => 'Offering Mentorship',
                    'seeking' => 'Seeking a Mentor',
                    'both' => 'Both',
                    'not_available' => 'Not Available',
                ),
                'allow_null' => 1,
            ),
            array(
                'key' => 'field_md_network_mentorship_notes',
                'label' => 'Mentorship Notes',
                'name' => 'member_directory_network_mentorship_notes',
                'type' => 'textarea',
                'rows' => 4,
            ),
            // ── Tab: Apprenticeship ──
            array(
                'key' => 'field_md_tab_network_apprenticeship',
                'label' => 'Apprenticeship',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_network_apprenticeship_status',
                'label' => 'Apprenticeship Status',
                'name' => 'member_directory_network_apprenticeship_status',
                'type' => 'select',
                'choices' => array(
                    '' => '— Not Set —',
                    'offering' => 'Offering Apprenticeship',
                    'seeking' => 'Seeking Apprenticeship',
                    'both' => 'Both',
                    'not_available' => 'Not Available',
                ),
                'allow_null' => 1,
            ),
            array(
                'key' => 'field_md_network_apprenticeship_notes',
                'label' => 'Apprenticeship Notes',
                'name' => 'member_directory_network_apprenticeship_notes',
                'type' => 'textarea',
                'rows' => 4,
            ),
            // ── Tab: Employment ──
            array(
                'key' => 'field_md_tab_network_employment',
                'label' => 'Employment',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_network_employment_status',
                'label' => 'Employment Status',
                'name' => 'member_directory_network_employment_status',
                'type' => 'select',
                'choices' => array(
                    '' => '— Not Set —',
                    'hiring' => 'Hiring',
                    'seeking' => 'Seeking Employment',
                    'both' => 'Both',
                    'not_available' => 'Not Available',
                ),
                'allow_null' => 1,
            ),
            array(
                'key' => 'field_md_network_employment_notes',
                'label' => 'Employment Notes',
                'name' => 'member_directory_network_employment_notes',
                'type' => 'textarea',
                'rows' => 4,
            ),
            array(
                'key' => 'field_md_network_willing_to_relocate',
                'label' => 'Willing to Relocate',
                'name' => 'member_directory_network_willing_to_relocate',
                'type' => 'true_false',
                'ui' => 1,
            ),
            // ── Tab: Collaboration ──
            array(
                'key' => 'field_md_tab_network_collaboration',
                'label' => 'Collaboration',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_network_collaboration_notes',
                'label' => 'Collaboration Interests',
                'name' => 'member_directory_network_collaboration_notes',
                'type' => 'textarea',
                'rows' => 4,
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'member-directory',
                ),
            ),
        ),
        'position' => 'normal',
        'menu_order' => 4,
        'style' => 'default',
        'active' => true,
    ));

    // ─────────────────────────────────────────────────────────
    // Group 05: Business
    // ─────────────────────────────────────────────────────────
    acf_add_local_field_group(array(
        'key' => 'group_md_05_business',
        'title' => 'Member Directory — Business',
        'fields' => array(
            // ── Tab: Privacy ──
            array(
                'key' => 'field_md_tab_business_privacy',
                'label' => 'Privacy',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_business_privacy_mode',
                'label' => 'Privacy Mode',
                'name' => 'member_directory_business_privacy_mode',
                'type' => 'button_group',
                'choices' => array(
                    'inherit' => 'Inherit Global',
                    'custom' => 'Custom',
                ),
                'default_value' => 'inherit',
            ),
            array(
                'key' => 'field_md_business_privacy_level',
                'label' => 'Privacy Level',
                'name' => 'member_directory_business_privacy_level',
                'type' => 'select',
                'choices' => array(
                    'public' => 'Public',
                    'members' => 'Members Only',
                    'private' => 'Private',
                ),
                'default_value' => 'members',
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_md_business_privacy_mode',
                            'operator' => '==',
                            'value' => 'custom',
                        ),
                    ),
                ),
            ),
            // ── Tab: Identity ──
            array(
                'key' => 'field_md_tab_business_identity',
                'label' => 'Identity',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_business_name',
                'label' => 'Business Name',
                'name' => 'member_directory_business_name',
                'type' => 'text',
            ),
            array(
                'key' => 'field_md_business_logo',
                'label' => 'Business Logo',
                'name' => 'member_directory_business_logo',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ),
            array(
                'key' => 'field_md_business_hero',
                'label' => 'Business Hero Image',
                'name' => 'member_directory_business_hero',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'large',
                'instructions' => 'Banner image for the business header (e.g. storefront photo).',
            ),
            array(
                'key' => 'field_md_business_description',
                'label' => 'Business Description',
                'name' => 'member_directory_business_description',
                'type' => 'textarea',
                'rows' => 4,
                'instructions' => 'Brief mission statement or elevator pitch.',
            ),
            // ── Tab: Contact ──
            array(
                'key' => 'field_md_tab_business_contact',
                'label' => 'Contact',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_business_phone',
                'label' => 'Phone',
                'name' => 'member_directory_business_phone',
                'type' => 'text',
            ),
            array(
                'key' => 'field_md_business_email',
                'label' => 'Email',
                'name' => 'member_directory_business_email',
                'type' => 'email',
            ),
            array(
                'key' => 'field_md_business_contact_notes',
                'label' => 'Contact Notes',
                'name' => 'member_directory_business_contact_notes',
                'type' => 'textarea',
                'rows' => 3,
                'instructions' => 'Best way to reach you, preferred contact method, etc.',
            ),
            // ── Tab: Services ──
            array(
                'key' => 'field_md_tab_business_services',
                'label' => 'Services',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_business_services',
                'label' => 'Services Offered',
                'name' => 'member_directory_business_services',
                'type' => 'taxonomy',
                'taxonomy' => 'memdir_services',
                'field_type' => 'multi_select',
                'allow_null' => 1,
                'save_terms' => 1,
                'load_terms' => 1,
                'return_format' => 'id',
            ),
            array(
                'key' => 'field_md_business_featured_services',
                'label' => 'Featured Services',
                'name' => 'member_directory_business_featured_services',
                'type' => 'taxonomy',
                'taxonomy' => 'memdir_services',
                'field_type' => 'multi_select',
                'allow_null' => 1,
                'save_terms' => 0,
                'load_terms' => 0,
                'return_format' => 'id',
                'instructions' => 'Select up to 3 services to highlight.',
            ),
            array(
                'key' => 'field_md_business_instruments',
                'label' => 'Instruments Serviced',
                'name' => 'member_directory_business_instruments',
                'type' => 'taxonomy',
                'taxonomy' => 'memdir_instruments',
                'field_type' => 'multi_select',
                'allow_null' => 1,
                'save_terms' => 0,
                'load_terms' => 0,
                'return_format' => 'id',
                'instructions' => 'What instruments the business works on (may differ from personal craft).',
            ),
            array(
                'key' => 'field_md_business_warranty',
                'label' => 'Warranty',
                'name' => 'member_directory_business_warranty',
                'type' => 'textarea',
                'rows' => 3,
            ),
            // ── Tab: Location & Hours ──
            array(
                'key' => 'field_md_tab_business_location',
                'label' => 'Location & Hours',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_business_location',
                'label' => 'Business Location',
                'name' => 'member_directory_business_location',
                'type' => 'google_map',
                'center_lat' => '39.7392',
                'center_lng' => '-104.9903',
                'zoom' => 10,
            ),
            array(
                'key' => 'field_md_business_location_precision',
                'label' => 'Location Precision',
                'name' => 'member_directory_business_location_precision',
                'type' => 'select',
                'choices' => array(
                    'exact' => 'Exact Address',
                    'neighborhood' => 'Neighborhood',
                    'city' => 'City Only',
                    'hide' => 'Hide Location',
                ),
                'default_value' => 'exact',
            ),
            array(
                'key' => 'field_md_business_parking',
                'label' => 'Parking',
                'name' => 'member_directory_business_parking',
                'type' => 'text',
                'placeholder' => 'Street parking available, lot in rear, etc.',
            ),
            array(
                'key' => 'field_md_business_accessibility',
                'label' => 'Accessibility',
                'name' => 'member_directory_business_accessibility',
                'type' => 'textarea',
                'rows' => 3,
            ),
            array(
                'key' => 'field_md_business_hours',
                'label' => 'Business Hours',
                'name' => 'member_directory_business_hours',
                'type' => 'textarea',
                'rows' => 4,
                'instructions' => 'Free-form hours (flexible for "by appointment only", seasonal hours, etc.)',
            ),
            // ── Tab: Booking ──
            array(
                'key' => 'field_md_tab_business_booking',
                'label' => 'Booking',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_business_booking_url',
                'label' => 'Booking URL',
                'name' => 'member_directory_business_booking_url',
                'type' => 'url',
                'placeholder' => 'https://calendly.com/...',
                'instructions' => 'Link to your scheduling system (Calendly, Square, etc.)',
            ),
            array(
                'key' => 'field_md_business_languages',
                'label' => 'Languages',
                'name' => 'member_directory_business_languages',
                'type' => 'repeater',
                'layout' => 'table',
                'min' => 0,
                'max' => 10,
                'sub_fields' => array(
                    array(
                        'key' => 'field_md_business_language_name',
                        'label' => 'Language',
                        'name' => 'language',
                        'type' => 'text',
                    ),
                ),
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'member-directory',
                ),
            ),
        ),
        'position' => 'normal',
        'menu_order' => 5,
        'style' => 'default',
        'active' => true,
    ));

    // ─────────────────────────────────────────────────────────
    // Group 06: Workspace (Workshop)
    // ─────────────────────────────────────────────────────────
    acf_add_local_field_group(array(
        'key' => 'group_md_06_workspace',
        'title' => 'Member Directory — Workspace',
        'fields' => array(
            // ── Tab: Privacy ──
            array(
                'key' => 'field_md_tab_workshop_privacy',
                'label' => 'Privacy',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_workshop_privacy_mode',
                'label' => 'Privacy Mode',
                'name' => 'member_directory_workshop_privacy_mode',
                'type' => 'button_group',
                'choices' => array(
                    'inherit' => 'Inherit Global',
                    'custom' => 'Custom',
                ),
                'default_value' => 'inherit',
            ),
            array(
                'key' => 'field_md_workshop_privacy_level',
                'label' => 'Privacy Level',
                'name' => 'member_directory_workshop_privacy_level',
                'type' => 'select',
                'choices' => array(
                    'public' => 'Public',
                    'members' => 'Members Only',
                    'private' => 'Private',
                ),
                'default_value' => 'members',
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_md_workshop_privacy_mode',
                            'operator' => '==',
                            'value' => 'custom',
                        ),
                    ),
                ),
            ),
            // ── Tab: Overview ──
            array(
                'key' => 'field_md_tab_workshop_overview',
                'label' => 'Overview',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_workshop_description',
                'label' => 'Workshop Description',
                'name' => 'member_directory_workshop_description',
                'type' => 'textarea',
                'rows' => 6,
            ),
            array(
                'key' => 'field_md_workshop_photos',
                'label' => 'Workshop Photos',
                'name' => 'member_directory_workshop_photos',
                'type' => 'gallery',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ),
            // ── Tab: Equipment ──
            array(
                'key' => 'field_md_tab_workshop_equipment',
                'label' => 'Equipment',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_workshop_equipment',
                'label' => 'Equipment',
                'name' => 'member_directory_workshop_equipment',
                'type' => 'taxonomy',
                'taxonomy' => 'memdir_equipment',
                'field_type' => 'multi_select',
                'allow_null' => 1,
                'save_terms' => 1,
                'load_terms' => 1,
                'return_format' => 'id',
            ),
            array(
                'key' => 'field_md_workshop_accessibility',
                'label' => 'Accessibility Notes',
                'name' => 'member_directory_workshop_accessibility',
                'type' => 'textarea',
                'rows' => 3,
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'member-directory',
                ),
            ),
        ),
        'position' => 'normal',
        'menu_order' => 6,
        'style' => 'default',
        'active' => true,
    ));

    // ─────────────────────────────────────────────────────────
    // Group 07: Experience
    // ─────────────────────────────────────────────────────────
    acf_add_local_field_group(array(
        'key' => 'group_md_07_experience',
        'title' => 'Member Directory — Experience',
        'fields' => array(
            // ── Tab: Privacy ──
            array(
                'key' => 'field_md_tab_experience_privacy',
                'label' => 'Privacy',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_experience_privacy_mode',
                'label' => 'Privacy Mode',
                'name' => 'member_directory_experience_privacy_mode',
                'type' => 'button_group',
                'choices' => array(
                    'inherit' => 'Inherit Global',
                    'custom' => 'Custom',
                ),
                'default_value' => 'inherit',
            ),
            array(
                'key' => 'field_md_experience_privacy_level',
                'label' => 'Privacy Level',
                'name' => 'member_directory_experience_privacy_level',
                'type' => 'select',
                'choices' => array(
                    'public' => 'Public',
                    'members' => 'Members Only',
                    'private' => 'Private',
                ),
                'default_value' => 'members',
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_md_experience_privacy_mode',
                            'operator' => '==',
                            'value' => 'custom',
                        ),
                    ),
                ),
            ),
            // ── Tab: Work History ──
            array(
                'key' => 'field_md_tab_experience_history',
                'label' => 'Work History',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_experience_history',
                'label' => 'Work History',
                'name' => 'member_directory_experience_history',
                'type' => 'repeater',
                'layout' => 'block',
                'min' => 0,
                'max' => 20,
                'button_label' => 'Add Position',
                'sub_fields' => array(
                    array(
                        'key' => 'field_md_experience_history_role',
                        'label' => 'Role / Title',
                        'name' => 'role',
                        'type' => 'text',
                    ),
                    array(
                        'key' => 'field_md_experience_history_org',
                        'label' => 'Organization',
                        'name' => 'organization',
                        'type' => 'text',
                    ),
                    array(
                        'key' => 'field_md_experience_history_years',
                        'label' => 'Years',
                        'name' => 'years',
                        'type' => 'text',
                        'placeholder' => '2018–2022',
                    ),
                    array(
                        'key' => 'field_md_experience_history_desc',
                        'label' => 'Description',
                        'name' => 'description',
                        'type' => 'textarea',
                        'rows' => 3,
                    ),
                ),
            ),
            // ── Tab: Education ──
            array(
                'key' => 'field_md_tab_experience_education',
                'label' => 'Education',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_experience_education',
                'label' => 'Education & Training',
                'name' => 'member_directory_experience_education',
                'type' => 'repeater',
                'layout' => 'block',
                'min' => 0,
                'max' => 20,
                'button_label' => 'Add Education',
                'sub_fields' => array(
                    array(
                        'key' => 'field_md_experience_education_program',
                        'label' => 'Program / Degree',
                        'name' => 'program',
                        'type' => 'text',
                    ),
                    array(
                        'key' => 'field_md_experience_education_institution',
                        'label' => 'Institution',
                        'name' => 'institution',
                        'type' => 'text',
                    ),
                    array(
                        'key' => 'field_md_experience_education_year',
                        'label' => 'Year',
                        'name' => 'year',
                        'type' => 'text',
                    ),
                ),
            ),
            // ── Tab: Achievements ──
            array(
                'key' => 'field_md_tab_experience_achievements',
                'label' => 'Achievements',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_experience_achievements',
                'label' => 'Achievements',
                'name' => 'member_directory_experience_achievements',
                'type' => 'textarea',
                'rows' => 6,
                'instructions' => 'Awards, certifications, notable projects.',
            ),
            // ── Tab: Portfolio ──
            array(
                'key' => 'field_md_tab_experience_portfolio',
                'label' => 'Portfolio',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_experience_portfolio_url',
                'label' => 'Portfolio Link',
                'name' => 'member_directory_experience_portfolio_url',
                'type' => 'url',
            ),
            array(
                'key' => 'field_md_experience_portfolio_gallery',
                'label' => 'Portfolio Gallery',
                'name' => 'member_directory_experience_portfolio_gallery',
                'type' => 'gallery',
                'return_format' => 'array',
                'preview_size' => 'medium',
                'instructions' => 'Photos of instruments built, repairs completed, etc.',
            ),
            array(
                'key' => 'field_md_experience_resume',
                'label' => 'Resume / CV',
                'name' => 'member_directory_experience_resume',
                'type' => 'file',
                'return_format' => 'array',
                'mime_types' => 'pdf,doc,docx',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'member-directory',
                ),
            ),
        ),
        'position' => 'normal',
        'menu_order' => 7,
        'style' => 'default',
        'active' => true,
    ));

    // ─────────────────────────────────────────────────────────
    // Group 08: Vibe
    // ─────────────────────────────────────────────────────────
    acf_add_local_field_group(array(
        'key' => 'group_md_08_vibe',
        'title' => 'Member Directory — Vibe',
        'fields' => array(
            // ── Tab: Privacy ──
            array(
                'key' => 'field_md_tab_vibe_privacy',
                'label' => 'Privacy',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_vibe_privacy_mode',
                'label' => 'Privacy Mode',
                'name' => 'member_directory_vibe_privacy_mode',
                'type' => 'button_group',
                'choices' => array(
                    'inherit' => 'Inherit Global',
                    'custom' => 'Custom',
                ),
                'default_value' => 'inherit',
            ),
            array(
                'key' => 'field_md_vibe_privacy_level',
                'label' => 'Privacy Level',
                'name' => 'member_directory_vibe_privacy_level',
                'type' => 'select',
                'choices' => array(
                    'public' => 'Public',
                    'members' => 'Members Only',
                    'private' => 'Private',
                ),
                'default_value' => 'members',
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_md_vibe_privacy_mode',
                            'operator' => '==',
                            'value' => 'custom',
                        ),
                    ),
                ),
            ),
            // ── Tab: Personality ──
            array(
                'key' => 'field_md_tab_vibe_personality',
                'label' => 'Personality',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_vibe_overview',
                'label' => 'Vibe Overview',
                'name' => 'member_directory_vibe_overview',
                'type' => 'textarea',
                'rows' => 4,
                'instructions' => 'What it\'s like to work with you.',
            ),
            array(
                'key' => 'field_md_vibe_personality',
                'label' => 'Personality Traits',
                'name' => 'member_directory_vibe_personality',
                'type' => 'checkbox',
                'choices' => array(
                    'detail_oriented' => 'Detail-Oriented',
                    'laid_back' => 'Laid Back',
                    'collaborative' => 'Collaborative',
                    'independent' => 'Independent',
                    'mentor_type' => 'Mentor Type',
                    'perfectionist' => 'Perfectionist',
                    'experimental' => 'Experimental',
                    'traditional' => 'Traditional',
                    'fast_paced' => 'Fast-Paced',
                    'methodical' => 'Methodical',
                ),
                'layout' => 'horizontal',
            ),
            array(
                'key' => 'field_md_vibe_working_style',
                'label' => 'Working Style',
                'name' => 'member_directory_vibe_working_style',
                'type' => 'textarea',
                'rows' => 4,
            ),
            // ── Tab: Fun Stuff ──
            array(
                'key' => 'field_md_tab_vibe_fun',
                'label' => 'Fun Stuff',
                'type' => 'tab',
            ),
            array(
                'key' => 'field_md_vibe_photos',
                'label' => 'Personality Photos',
                'name' => 'member_directory_vibe_photos',
                'type' => 'gallery',
                'return_format' => 'array',
                'preview_size' => 'medium',
                'instructions' => 'Shop dog, finished builds, community events.',
            ),
            array(
                'key' => 'field_md_vibe_playlist',
                'label' => 'Shop Playlist',
                'name' => 'member_directory_vibe_playlist',
                'type' => 'url',
                'instructions' => 'Link to your Spotify/Apple Music playlist.',
            ),
            array(
                'key' => 'field_md_vibe_sayings',
                'label' => 'Things I Say in the Shop',
                'name' => 'member_directory_vibe_sayings',
                'type' => 'repeater',
                'layout' => 'table',
                'min' => 0,
                'max' => 10,
                'button_label' => 'Add Saying',
                'sub_fields' => array(
                    array(
                        'key' => 'field_md_vibe_saying_text',
                        'label' => 'Saying',
                        'name' => 'saying',
                        'type' => 'text',
                    ),
                ),
            ),
            array(
                'key' => 'field_md_vibe_workshop_buddies',
                'label' => 'Workshop Buddies',
                'name' => 'member_directory_vibe_workshop_buddies',
                'type' => 'repeater',
                'layout' => 'table',
                'min' => 0,
                'max' => 10,
                'button_label' => 'Add Buddy',
                'sub_fields' => array(
                    array(
                        'key' => 'field_md_vibe_buddy_name',
                        'label' => 'Name',
                        'name' => 'name',
                        'type' => 'text',
                    ),
                    array(
                        'key' => 'field_md_vibe_buddy_relationship',
                        'label' => 'Relationship',
                        'name' => 'relationship',
                        'type' => 'text',
                        'placeholder' => 'Mentor, collaborator, etc.',
                    ),
                ),
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'member-directory',
                ),
            ),
        ),
        'position' => 'normal',
        'menu_order' => 8,
        'style' => 'default',
        'active' => true,
    ));
}
