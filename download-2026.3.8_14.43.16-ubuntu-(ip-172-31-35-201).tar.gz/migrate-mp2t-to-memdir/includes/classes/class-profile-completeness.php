<?php
/**
 * Profile Completeness Calculator
 * Calculates how complete a member's profile is based on weighted field groups.
 *
 * Fields are discovered dynamically from ACF — adding a field in ACF
 * automatically includes it in completeness scoring.
 */

if (!defined('ABSPATH'))
    exit;

class Memdir_Profile_Completeness
{

    /**
     * Section weights (must total 100).
     * These represent the relative importance of each section.
     * Fields within each section are discovered from ACF at runtime.
     */
    private static $section_weights = array(
        'profile' => 30,
        'craft' => 15,
        'business' => 20,
        'network' => 10,
        'workshop' => 10,
        'experience' => 10,
        'vibe' => 5,
    );

    /**
     * Calculate profile completeness for a post.
     *
     * @param int $post_id The member directory post ID
     * @return array {
     *     'percentage'  => int     0-100 overall completion
     *     'completed'   => int     number of filled fields
     *     'total'       => int     number of applicable fields
     *     'suggestions' => array   top 3 next actions to improve completion
     *     'sections'    => array   per-section breakdown
     * }
     */
    public static function calculate($post_id)
    {
        $total_weight = 0;
        $earned_weight = 0;
        $total_fields = 0;
        $filled_fields = 0;
        $suggestions = array();
        $sections = array();

        foreach (self::$section_weights as $section_key => $section_weight) {
            // Profile is always "enabled" — others depend on toggle
            $is_enabled = ($section_key === 'profile') || memdir_is_section_enabled($post_id, $section_key);

            if (!$is_enabled) {
                continue;
            }

            // Get content fields dynamically from ACF
            $section_fields = self::get_section_fields($section_key);
            $section_total = count($section_fields);
            $section_filled = 0;

            foreach ($section_fields as $field) {
                $total_fields++;

                $value = self::get_field_value($post_id, $field);

                if (!empty($value)) {
                    $section_filled++;
                    $filled_fields++;
                } else {
                    // Collect suggestion (prioritized by section weight)
                    $suggestions[] = array(
                        'text' => self::generate_suggestion($field),
                        'weight' => $section_weight,
                        'section' => $section_key,
                    );
                }
            }

            // Calculate weighted contribution
            $total_weight += $section_weight;
            if ($section_total > 0) {
                $earned_weight += $section_weight * ($section_filled / $section_total);
            }

            $sections[$section_key] = array(
                'label' => ucfirst($section_key),
                'filled' => $section_filled,
                'total' => $section_total,
                'percent' => $section_total > 0 ? round(($section_filled / $section_total) * 100) : 0,
            );
        }

        // Overall percentage (weighted)
        $percentage = $total_weight > 0 ? round(($earned_weight / $total_weight) * 100) : 0;

        // Sort suggestions by weight (highest section weight first) and take top 3
        usort($suggestions, function ($a, $b) {
            return $b['weight'] - $a['weight'];
        });
        $top_suggestions = array_slice(array_column($suggestions, 'text'), 0, 3);

        return array(
            'percentage' => $percentage,
            'completed' => $filled_fields,
            'total' => $total_fields,
            'suggestions' => $top_suggestions,
            'sections' => $sections,
        );
    }

    /**
     * Get content fields for a section, dynamically from ACF.
     * Falls back to empty array if ACF or the renderer isn't available.
     *
     * @param string $section Section key
     * @return array ACF field definitions
     */
    private static function get_section_fields($section)
    {
        if (!function_exists('memdir_get_section_content_fields')) {
            return array();
        }

        // For profile section, include system fields (full_name)
        $fields = memdir_get_section_content_fields($section);

        if ($section === 'profile' && function_exists('acf_get_fields')) {
            // Add full_name from system group — it's in group_01, not group_02
            $system_fields = acf_get_fields('group_01_system');
            if ($system_fields) {
                foreach ($system_fields as $field) {
                    if ($field['name'] === memdir_field('full_name')) {
                        array_unshift($fields, $field);
                        break;
                    }
                }
            }
        }

        return $fields;
    }

    /**
     * Get field value, auto-detecting taxonomy fields from ACF type.
     *
     * @param int   $post_id The post ID
     * @param array $field   ACF field definition
     * @return mixed Field value
     */
    private static function get_field_value($post_id, $field)
    {
        // Taxonomy fields: use get_the_terms for more reliable results
        if ($field['type'] === 'taxonomy' && !empty($field['taxonomy'])) {
            $terms = get_the_terms($post_id, $field['taxonomy']);
            return ($terms && !is_wp_error($terms)) ? $terms : '';
        }

        return get_field($field['name'], $post_id);
    }

    /**
     * Generate a user-friendly suggestion from a field definition.
     *
     * @param array $field ACF field definition
     * @return string Suggestion text
     */
    private static function generate_suggestion($field)
    {
        $label = $field['label'] ?? $field['name'];

        switch ($field['type']) {
            case 'image':
                return 'Upload your ' . strtolower($label);
            case 'taxonomy':
                return 'Select your ' . strtolower($label);
            case 'textarea':
            case 'wysiwyg':
                return 'Write your ' . strtolower($label);
            case 'url':
                return 'Add a ' . strtolower($label) . ' link';
            case 'select':
            case 'radio':
                return 'Choose your ' . strtolower($label);
            case 'checkbox':
                return 'Pick your ' . strtolower($label);
            default:
                return 'Add your ' . strtolower($label);
        }
    }
}
