<?php
/**
 * Admin Dashboard Widget
 * Shows member directory stats on the WordPress admin dashboard.
 */

if (!defined('ABSPATH'))
    exit;

class Memdir_Admin_Dashboard
{

    public function __construct()
    {
        add_action('wp_dashboard_setup', array($this, 'register_widget'));
    }

    /**
     * Register the dashboard widget.
     */
    public function register_widget()
    {
        wp_add_dashboard_widget(
            'memdir_directory_stats',
            '📋 Member Directory Overview',
            array($this, 'render_widget')
        );
    }

    /**
     * Render the dashboard widget content.
     */
    public function render_widget()
    {
        // Total published profiles
        $total = wp_count_posts('member-directory');
        $published = isset($total->publish) ? $total->publish : 0;
        $drafts = isset($total->draft) ? $total->draft : 0;

        // Recent profiles (last 7 days)
        $recent_args = array(
            'post_type' => 'member-directory',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'date_query' => array(
                array(
                    'after' => '1 week ago',
                    'inclusive' => true,
                ),
            ),
        );
        $recent = new WP_Query($recent_args);
        $new_this_week = $recent->found_posts;

        // Average completeness (if class exists) — cached for performance
        $avg_completeness = null;
        if (class_exists('Memdir_Profile_Completeness')) {
            $avg_completeness = get_transient('memdir_avg_completeness');
            if ($avg_completeness === false) {
                $all_profiles = get_posts(array(
                    'post_type' => 'member-directory',
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                    'fields' => 'ids',
                ));

                if (!empty($all_profiles)) {
                    // Batch prefetch all post meta — calculate() does ~56 get_field calls each.
                    update_postmeta_cache($all_profiles);

                    $total_pct = 0;
                    foreach ($all_profiles as $pid) {
                        $completeness = Memdir_Profile_Completeness::calculate($pid);
                        $total_pct += $completeness['percentage'];
                    }
                    $avg_completeness = round($total_pct / count($all_profiles));
                } else {
                    $avg_completeness = null;
                }

                // Cache for 1 hour — recalculated automatically
                set_transient('memdir_avg_completeness', $avg_completeness !== null ? $avg_completeness : 'none', HOUR_IN_SECONDS);
            }

            // Handle cached 'none' value
            if ($avg_completeness === 'none') {
                $avg_completeness = null;
            }
        }

        // Most viewed profiles (top 5)
        $top_viewed = get_posts(array(
            'post_type' => 'member-directory',
            'post_status' => 'publish',
            'posts_per_page' => 5,
            'meta_key' => memdir_field('profile_views'),
            'orderby' => 'meta_value_num',
            'order' => 'DESC',
            'meta_query' => array(
                array(
                    'key' => memdir_field('profile_views'),
                    'value' => '0',
                    'compare' => '>',
                    'type' => 'NUMERIC',
                ),
            ),
        ));

        ?>
        <div class="memdir-dashboard-widget">
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 16px;">
                <div style="text-align: center; padding: 12px; background: #f0f6ec; border-radius: 8px;">
                    <div style="font-size: 28px; font-weight: 700; color: #4a6741;">
                        <?php echo esc_html($published); ?>
                    </div>
                    <div style="font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 0.5px;">Published</div>
                </div>
                <div style="text-align: center; padding: 12px; background: #fdf6e3; border-radius: 8px;">
                    <div style="font-size: 28px; font-weight: 700; color: #b8860b;">
                        <?php echo esc_html($drafts); ?>
                    </div>
                    <div style="font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 0.5px;">Drafts</div>
                </div>
                <div style="text-align: center; padding: 12px; background: #e8f4f8; border-radius: 8px;">
                    <div style="font-size: 28px; font-weight: 700; color: #2e6da4;">
                        <?php echo esc_html($new_this_week); ?>
                    </div>
                    <div style="font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 0.5px;">New This Week
                    </div>
                </div>
            </div>

            <?php if ($avg_completeness !== null): ?>
                <div style="margin-bottom: 16px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                        <span style="font-size: 13px; font-weight: 600;">Avg. Profile Completeness</span>
                        <span style="font-size: 13px; font-weight: 600;">
                            <?php echo esc_html($avg_completeness); ?>%
                        </span>
                    </div>
                    <div style="height: 8px; background: #e5e5e5; border-radius: 4px; overflow: hidden;">
                        <div style="height: 100%; width: <?php echo esc_attr($avg_completeness); ?>%;
                             background: <?php echo $avg_completeness >= 70 ? '#6b8f5e' : ($avg_completeness >= 40 ? '#daa520' : '#cd5c5c'); ?>;
                             border-radius: 4px; transition: width 0.6s ease;"></div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($top_viewed)): ?>
                <div>
                    <h4 style="margin: 0 0 8px; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; color: #333;">
                        Most Viewed Profiles
                    </h4>
                    <table style="width: 100%; border-collapse: collapse;">
                        <?php foreach ($top_viewed as $profile): ?>
                            <tr style="border-bottom: 1px solid #eee;">
                                <td style="padding: 6px 0;">
                                    <a href="<?php echo esc_url(get_edit_post_link($profile->ID)); ?>"
                                        style="text-decoration: none; color: #2271b1; font-size: 13px;">
                                        <?php
                                        $name = get_field(memdir_field('full_name'), $profile->ID);
                                        echo esc_html($name ?: $profile->post_title);
                                        ?>
                                    </a>
                                </td>
                                <td style="padding: 6px 0; text-align: right; color: #666; font-size: 13px;">
                                    <?php echo esc_html(number_format_i18n(memdir_get_profile_views($profile->ID))); ?> views
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
            <?php endif; ?>

            <div style="margin-top: 12px; text-align: right;">
                <a href="<?php echo esc_url(admin_url('edit.php?post_type=member-directory')); ?>" style="font-size: 13px;">
                    View All Profiles →
                </a>
            </div>
        </div>
        <?php
    }
}
