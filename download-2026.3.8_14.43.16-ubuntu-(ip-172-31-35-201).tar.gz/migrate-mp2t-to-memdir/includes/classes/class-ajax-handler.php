<?php
/**
 * AJAX Handler Class
 * Handles all AJAX endpoints for the Member Directory plugin
 */

if (!defined('ABSPATH'))
    exit;

class Memdir_Ajax_Handler
{

    /**
     * Initialize the AJAX handler
     */
    public function __construct()
    {
        $this->register_endpoints();
    }

    /**
     * Register all AJAX action hooks
     */
    private function register_endpoints()
    {
        // Save PMP value
        add_action('wp_ajax_memdir_save_pmp', array($this, 'save_pmp'));

        // Save section enabled state
        add_action('wp_ajax_memdir_save_section_enabled', array($this, 'save_section_enabled'));

        // Save section privacy mode
        add_action('wp_ajax_memdir_save_section_privacy_mode', array($this, 'save_section_privacy_mode'));

        // Save custom form fields
        add_action('wp_ajax_memdir_save_form_fields', array($this, 'save_form_fields'));

        // Save field privacy override
        add_action('wp_ajax_memdir_save_field_privacy_override', array($this, 'save_field_privacy_override'));

        // Save social links
        add_action('wp_ajax_memdir_save_social_links', array($this, 'save_social_links'));

        // Search members (public-facing — both logged-in and anonymous)
        add_action('wp_ajax_memdir_search_members', array($this, 'search_members'));
        add_action('wp_ajax_nopriv_memdir_search_members', array($this, 'search_members'));

        // Contact form (public-facing — both logged-in and anonymous)
        add_action('wp_ajax_memdir_contact_member', array($this, 'contact_member'));
        add_action('wp_ajax_nopriv_memdir_contact_member', array($this, 'contact_member'));

        // Portfolio management (owner only)
        add_action('wp_ajax_memdir_add_portfolio_images', array($this, 'add_portfolio_images'));
        add_action('wp_ajax_memdir_remove_portfolio_image', array($this, 'remove_portfolio_image'));

        // Save all sections at once (unified save controller)
        add_action('wp_ajax_memdir_save_all_sections', array($this, 'save_all_sections'));

        // Save default header preference
        add_action('wp_ajax_memdir_save_default_header', array($this, 'save_default_header'));

        // Map data (public-facing — both logged-in and anonymous)
        add_action('wp_ajax_memdir_get_map_data', array($this, 'get_map_data'));
        add_action('wp_ajax_nopriv_memdir_get_map_data', array($this, 'get_map_data'));
    }

    /**
     * Verify request validity (nonce and permission)
     * Terminates with JSON error if invalid — does NOT return on failure.
     * 
     * @param int $post_id The post ID to check edit permissions for
     * @return void
     */
    private function verify_request($post_id)
    {
        // Verify nonce — wp_send_json_error calls wp_die(), so no return needed
        if (!check_ajax_referer('memdir_nonce', 'nonce', false)) {
            wp_send_json_error('Invalid security token');
        }

        // Verify user can edit
        if (!memdir_can_edit($post_id)) {
            wp_send_json_error('Permission denied');
        }
    }

    /**
     * Allowed PMP field names for the save_pmp endpoint.
     * Built dynamically from the centralized map.
     */
    private static function get_pmp_fields()
    {
        static $fields = null;
        if ($fields === null) {
            $fields = array(memdir_field('global_privacy'));
            foreach (array('profile', 'craft', 'network', 'business', 'workshop', 'experience', 'vibe') as $s) {
                $pmp = memdir_get_section_pmp_fields($s);
                $fields[] = $pmp['value'];
            }
            $fields = array_unique($fields);
        }
        return $fields;
    }

    /**
     * AJAX handler: Save PMP value
     */
    public function save_pmp()
    {
        $post_id = intval($_POST['post_id']);
        $this->verify_request($post_id);

        $field = sanitize_key($_POST['field']);
        $value = sanitize_key($_POST['value']);

        // Validate field name
        if (!in_array($field, self::get_pmp_fields())) {
            wp_send_json_error('Invalid PMP field');
        }

        // Validate PMP value
        $allowed_values = array('public', 'members', 'private');
        if (!in_array($value, $allowed_values)) {
            wp_send_json_error('Invalid PMP value');
        }

        // Update field
        update_field($field, $value, $post_id);

        wp_send_json_success();
    }

    /**
     * AJAX handler: Save default header preference
     */
    public function save_default_header()
    {
        $post_id = intval($_POST['post_id']);
        $this->verify_request($post_id);

        $value = sanitize_key($_POST['value']);

        // Validate value
        $allowed = array('personal', 'business');
        if (!in_array($value, $allowed)) {
            wp_send_json_error('Invalid header preference');
        }

        update_post_meta($post_id, memdir_field('default_header'), $value);

        wp_send_json_success();
    }

    /**
     * Allowed section keys for enable/disable and privacy mode endpoints.
     */
    private static $allowed_sections = array(
        'profile',
        'craft',
        'network',
        'business',
        'workshop',
        'experience',
        'vibe'
    );

    /**
     * AJAX handler: Save section enabled state
     */
    public function save_section_enabled()
    {
        $post_id = intval($_POST['post_id']);
        $this->verify_request($post_id);

        $section = sanitize_key($_POST['section']);
        $enabled = intval($_POST['enabled']);

        // Validate section name
        if (!in_array($section, self::$allowed_sections)) {
            wp_send_json_error('Invalid section');
        }

        // Update field — resolve through memdir_field() to get the current
        // ACF field name (member_directory_enable_{section})
        $field_name = memdir_field("enable_{$section}");
        update_field($field_name, $enabled, $post_id);

        wp_send_json_success();
    }

    /**
     * AJAX handler: Save section privacy mode
     */
    public function save_section_privacy_mode()
    {
        $post_id = intval($_POST['post_id']);
        $this->verify_request($post_id);

        $section = sanitize_key($_POST['section']);
        $mode = sanitize_key($_POST['mode']); // 'adopt' or 'override'

        // Validate section name
        if (!in_array($section, self::$allowed_sections)) {
            wp_send_json_error('Invalid section');
        }

        // Validate mode value (ACF uses 'adopt' / 'section'; legacy used 'adopt' / 'override')
        if (!in_array($mode, array('adopt', 'override', 'section'))) {
            wp_send_json_error('Invalid privacy mode');
        }

        // Resolve correct ACF PMP field name for this section
        $pmp = memdir_get_section_pmp_fields($section);
        update_field($pmp['mode'], $mode, $post_id);

        wp_send_json_success();
    }

    /**
     * ACF groups whose content fields are editable via the frontend.
     * PMP control fields (containing '_pmp_') are automatically excluded.
     */
    private static $editable_groups = array(
        'group_md_01_system',
        'group_md_02_profile',
        'group_md_03_craft',
        'group_md_04_connect',
        'group_md_05_business',
        'group_md_06_workspace',
        'group_md_07_experience',
        'group_md_08_vibe',
    );

    /**
     * Runtime cache for the dynamic editable fields whitelist.
     */
    private static $editable_fields_cache = null;

    /**
     * Build the editable fields whitelist dynamically from ACF groups.
     * Only content fields are included — PMP control fields and section
     * enable/mode toggles are excluded.
     *
     * @return array Flat array of allowed field names.
     */
    private static function get_editable_fields()
    {
        if (self::$editable_fields_cache !== null) {
            return self::$editable_fields_cache;
        }

        $fields = array();

        if (!function_exists('acf_get_fields')) {
            self::$editable_fields_cache = $fields;
            return $fields;
        }

        foreach (self::$editable_groups as $group_key) {
            $group_fields = acf_get_fields($group_key);
            if (!$group_fields) {
                continue;
            }
            foreach ($group_fields as $field) {
                // Skip PMP/privacy control fields (infix _privacy_ or suffix _privacy)
                if (strpos($field['name'], '_pmp_') !== false || strpos($field['name'], '_privacy_') !== false) {
                    continue;
                }
                if (substr($field['name'], -8) === '_privacy') {
                    continue;
                }
                // Skip admin-only control fields (precision selectors, header preference)
                if (substr($field['name'], -10) === '_precision') {
                    continue;
                }
                if (strpos($field['name'], '_default_header') !== false) {
                    continue;
                }
                // Skip section enable toggles
                if (strpos($field['name'], '_enable_') !== false) {
                    continue;
                }
                // Skip block-level enable toggles
                if (substr($field['name'], -8) === '_enabled') {
                    continue;
                }
                // Skip non-data ACF types (admin UI only)
                if (in_array($field['type'], array('message', 'button_group', 'tab'), true)) {
                    continue;
                }
                $fields[] = $field['name'];
            }
        }

        self::$editable_fields_cache = $fields;
        return $fields;
    }

    /**
     * N6 Fix: Sanitize a field value based on its ACF field type.
     *
     * The previous approach used sanitize_textarea_field() for all types,
     * which strips HTML from WYSIWYG fields and mangles URL fields.
     * This method looks up the ACF field definition and applies the
     * appropriate WordPress sanitization function.
     *
     * @param string $field_name The ACF field name
     * @param mixed  $value      The raw submitted value
     * @return mixed Sanitized value
     */
    private static function sanitize_field_value($field_name, $value)
    {
        $acf_field = function_exists('acf_get_field') ? acf_get_field($field_name) : null;
        $field_type = $acf_field ? ($acf_field['type'] ?? '') : '';

        switch ($field_type) {
            case 'wysiwyg':
                return wp_kses_post($value);

            case 'url':
                return esc_url_raw($value);

            case 'email':
                return sanitize_email($value);

            case 'number':
            case 'range':
                return is_numeric($value) ? floatval($value) : 0;

            case 'true_false':
                return intval($value);

            case 'textarea':
            case 'text':
            case 'select':
            case 'radio':
            case 'color_picker':
            default:
                return sanitize_textarea_field($value);
        }
    }

    /**
     * AJAX handler: Save custom form fields
     */
    public function save_form_fields()
    {
        $post_id = intval($_POST['post_id']);
        $this->verify_request($post_id);

        $fields = isset($_POST['fields']) ? $_POST['fields'] : array();
        $editable = self::get_editable_fields();

        // Save each field (whitelist validated)
        foreach ($fields as $field_name => $value) {
            $field_name = sanitize_key($field_name);

            if (!in_array($field_name, $editable, true)) {
                continue; // Skip unknown fields
            }

            $value = self::sanitize_field_value($field_name, $value);
            update_field($field_name, $value, $post_id);
        }

        wp_send_json_success();
    }

    /**
     * AJAX handler: Save field privacy override
     */
    public function save_field_privacy_override()
    {
        $post_id = intval($_POST['post_id']);
        $this->verify_request($post_id);

        $field = sanitize_key($_POST['field']);
        $enabled = intval($_POST['enabled']);

        // Validate field is a known editable content field
        $editable = self::get_editable_fields();
        if (!in_array($field, $editable, true)) {
            wp_send_json_error('Invalid field');
        }

        // Build override field name: memdir_pmp_override_{field_name}
        $override_field = "memdir_pmp_override_{$field}";
        update_post_meta($post_id, $override_field, $enabled);

        // If enabling an override, also save the chosen privacy value
        if ($enabled && !empty($_POST['value'])) {
            $value = sanitize_key($_POST['value']);
            $allowed = array('public', 'members', 'private');
            if (in_array($value, $allowed, true)) {
                $value_field = "memdir_pmp_value_{$field}";
                update_post_meta($post_id, $value_field, $value);
            }
        }

        wp_send_json_success();
    }

    /**
     * AJAX handler: Save social links
     */
    public function save_social_links()
    {
        $post_id = intval($_POST['post_id']);
        $this->verify_request($post_id);

        $links = isset($_POST['links']) ? $_POST['links'] : array();

        // Get the post author (the user whose profile this is)
        $user_id = get_post_field('post_author', $post_id);

        // Save each social link to user meta
        $allowed_platforms = array('website', 'instagram', 'facebook', 'youtube', 'linktree');

        foreach ($links as $platform => $url) {
            if (!in_array($platform, $allowed_platforms)) {
                continue;
            }

            $url = esc_url_raw($url);

            if (!empty($url)) {
                update_user_meta($user_id, "author_{$platform}", $url);
            } else {
                delete_user_meta($user_id, "author_{$platform}");
            }
        }

        // Sync user meta → post meta (update_user_meta doesn't fire profile_update)
        if (function_exists('memdir_sync_user_to_post')) {
            memdir_sync_user_to_post($user_id);
        }

        wp_send_json_success();
    }

    /**
     * AJAX handler: Search and filter members for the directory archive.
     * Public endpoint — no post_id permission check needed.
     */
    public function search_members()
    {
        check_ajax_referer('memdir_archive_nonce', 'nonce');

        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        $sort = isset($_POST['sort']) ? sanitize_key($_POST['sort']) : 'az';
        $page = isset($_POST['page']) ? max(1, intval($_POST['page'])) : 1;
        $taxonomies = isset($_POST['taxonomies']) ? json_decode(stripslashes($_POST['taxonomies']), true) : array();

        // Build query args
        $args = array(
            'post_type' => 'member-directory',
            'post_status' => 'publish',
            'posts_per_page' => 12,
            'paged' => $page,
        );

        // Search
        if (!empty($search)) {
            $args['s'] = $search;
        }

        // Sort
        switch ($sort) {
            case 'za':
                $args['orderby'] = 'title';
                $args['order'] = 'DESC';
                break;
            case 'newest':
                $args['orderby'] = 'date';
                $args['order'] = 'DESC';
                break;
            case 'oldest':
                $args['orderby'] = 'date';
                $args['order'] = 'ASC';
                break;
            case 'az':
            default:
                $args['orderby'] = 'title';
                $args['order'] = 'ASC';
                break;
        }

        // Privacy filtering for non-logged-in users
        $privacy_query = memdir_get_privacy_meta_query();
        if ($privacy_query) {
            $args['meta_query'] = $privacy_query;
        }

        // Taxonomy filters
        $allowed_taxonomies = array('memdir_instruments', 'memdir_services', 'memdir_musical_contexts');
        $tax_query = array();

        if (is_array($taxonomies)) {
            foreach ($taxonomies as $taxonomy => $term_ids) {
                $taxonomy = sanitize_key($taxonomy);
                if (!in_array($taxonomy, $allowed_taxonomies)) {
                    continue;
                }
                if (!empty($term_ids) && is_array($term_ids)) {
                    $tax_query[] = array(
                        'taxonomy' => $taxonomy,
                        'field' => 'term_id',
                        'terms' => array_map('intval', $term_ids),
                        'operator' => 'IN',
                    );
                }
            }
        }

        if (!empty($tax_query)) {
            $tax_query['relation'] = 'AND';
            $args['tax_query'] = $tax_query;
        }

        $query = new WP_Query($args);

        // ─── BATCH PREFETCH (same pattern as get_map_data) ───
        // Without this: ~15 queries per card × 12 cards = ~180 queries.
        // With this: 3 queries total for meta + terms + post objects.
        if ($query->have_posts()) {
            $card_ids = wp_list_pluck($query->posts, 'ID');

            // 1. Prefetch ALL post meta for these posts in one query.
            //    Subsequent get_field() / get_post_meta() calls hit WP's
            //    in-memory object cache instead of the database.
            update_postmeta_cache($card_ids);

            // 2. Batch-fetch taxonomy terms (instruments + services)
            //    displayed on cards. 2 queries instead of 2 × 12 = 24.
            $card_taxonomies = array('memdir_instruments', 'memdir_services');
            foreach ($card_taxonomies as $card_tax) {
                wp_get_object_terms($card_ids, $card_tax);
            }
        }

        // Render member cards
        ob_start();
        if ($query->have_posts()) {
            $layout = isset($_POST['layout']) ? sanitize_key($_POST['layout']) : 'grid';
            while ($query->have_posts()) {
                $query->the_post();
                $memdir_card_post = get_post();
                $memdir_card_layout = $layout;
                include MEMDIR_PLUGIN_DIR . 'templates/components/member-card.php';
            }
            wp_reset_postdata();
        } else {
            echo '<div class="memdir-no-results"><p>No members found matching your criteria.</p></div>';
        }
        $html = ob_get_clean();

        // Render pagination
        $pagination = paginate_links(array(
            'total' => $query->max_num_pages,
            'current' => $page,
            'prev_text' => '← Previous',
            'next_text' => 'Next →',
            'type' => 'list',
            'mid_size' => 2,
        ));

        wp_send_json_success(array(
            'html' => $html,
            'total' => $query->found_posts,
            'pages' => $query->max_num_pages,
            'pagination' => $pagination ? $pagination : '',
        ));
    }

    /**
     * AJAX handler: Contact member via email.
     * Public endpoint — accepts messages from both anonymous and logged-in users.
     * Includes rate limiting via transient to prevent spam.
     */
    public function contact_member()
    {
        check_ajax_referer('memdir_nonce', 'nonce');

        // Honeypot check — bots fill hidden fields, humans don't
        if (!empty($_POST['memdir_website_url'])) {
            // Silently "succeed" to avoid tipping off the bot
            wp_send_json_success('Message sent successfully!');
        }

        $post_id = intval($_POST['post_id']);

        // Get the member's email
        $author_id = get_post_field('post_author', $post_id);
        $author = get_userdata($author_id);

        if (!$author || empty($author->user_email)) {
            wp_send_json_error('Unable to send message at this time.');
        }

        // Rate limiting: 1 message per IP per member per 5 minutes
        $rate_key = 'memdir_contact_' . md5($_SERVER['REMOTE_ADDR'] . '_' . $post_id);
        if (get_transient($rate_key)) {
            wp_send_json_error('Please wait a few minutes before sending another message to this member.');
        }

        // Get sender info
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            $sender_name = $current_user->display_name;
            $sender_email = $current_user->user_email;
        } else {
            $sender_name = isset($_POST['sender_name']) ? sanitize_text_field($_POST['sender_name']) : '';
            $sender_email = isset($_POST['sender_email']) ? sanitize_email($_POST['sender_email']) : '';
        }

        $subject = isset($_POST['subject']) ? sanitize_text_field($_POST['subject']) : '';
        $message = isset($_POST['message']) ? sanitize_textarea_field($_POST['message']) : '';

        // Validate required fields
        if (empty($sender_name) || empty($sender_email) || empty($subject) || empty($message)) {
            wp_send_json_error('All fields are required.');
        }

        if (!is_email($sender_email)) {
            wp_send_json_error('Please provide a valid email address.');
        }

        // Build email
        $member_name = get_field(memdir_field('full_name'), $post_id);
        if (empty($member_name)) {
            $member_name = get_the_title($post_id);
        }

        $site_name = get_bloginfo('name');
        $email_subject = '[' . $site_name . '] ' . $subject;

        $email_body = sprintf(
            "Hi %s,\n\nYou have received a new message through your member profile on %s.\n\n" .
            "From: %s (%s)\nSubject: %s\n\n---\n\n%s\n\n---\n\n" .
            "You can reply directly to this email to respond.\n" .
            "Profile: %s",
            $member_name,
            $site_name,
            $sender_name,
            $sender_email,
            $subject,
            $message,
            get_permalink($post_id)
        );

        $headers = array(
            'Reply-To: ' . $sender_name . ' <' . $sender_email . '>',
            'Content-Type: text/plain; charset=UTF-8',
        );

        $sent = wp_mail($author->user_email, $email_subject, $email_body, $headers);

        if ($sent) {
            // Set rate limit transient (5 minutes)
            set_transient($rate_key, true, 5 * MINUTE_IN_SECONDS);
            wp_send_json_success('Message sent successfully!');
        } else {
            wp_send_json_error('Failed to send message. Please try again later.');
        }
    }

    /**
     * Add images to the portfolio gallery.
     * Expects: post_id, image_ids (array of attachment IDs)
     */
    public function add_portfolio_images()
    {
        check_ajax_referer('memdir_nonce', 'nonce');

        $post_id = intval($_POST['post_id']);

        // Verify ownership
        if (!memdir_can_edit($post_id)) {
            wp_send_json_error('Permission denied.');
        }

        $new_ids = isset($_POST['image_ids']) ? array_map('intval', (array) $_POST['image_ids']) : array();
        if (empty($new_ids)) {
            wp_send_json_error('No images selected.');
        }

        // Validate that each ID is a valid image attachment
        $valid_ids = array();
        foreach ($new_ids as $id) {
            if ($id > 0 && wp_attachment_is_image($id)) {
                $valid_ids[] = $id;
            }
        }

        if (empty($valid_ids)) {
            wp_send_json_error('No valid images found.');
        }

        // Get existing portfolio and merge
        $existing = get_post_meta($post_id, memdir_field('portfolio_images'), true);
        if (!is_array($existing)) {
            $existing = array();
        }

        $merged = array_unique(array_merge($existing, $valid_ids));
        update_post_meta($post_id, memdir_field('portfolio_images'), $merged);

        wp_send_json_success(array(
            'message' => 'Images added successfully.',
            'count' => count($merged),
        ));
    }

    /**
     * Remove a single image from the portfolio gallery.
     * Expects: post_id, image_id
     */
    public function remove_portfolio_image()
    {
        check_ajax_referer('memdir_nonce', 'nonce');

        $post_id = intval($_POST['post_id']);
        $image_id = intval($_POST['image_id']);

        // Verify ownership
        if (!memdir_can_edit($post_id)) {
            wp_send_json_error('Permission denied.');
        }

        $existing = get_post_meta($post_id, memdir_field('portfolio_images'), true);
        if (!is_array($existing)) {
            wp_send_json_error('Portfolio is empty.');
        }

        // Remove the image ID
        $updated = array_values(array_diff($existing, array($image_id)));
        update_post_meta($post_id, memdir_field('portfolio_images'), $updated);

        wp_send_json_success('Image removed.');
    }

    /**
     * AJAX handler: Save all dirty sections at once.
     * Receives serialized form data from multiple ACF forms,
     * processes each through ACF's native save pipeline.
     */
    public function save_all_sections()
    {
        $post_id = intval($_POST['post_id']);
        $this->verify_request($post_id);

        $sections = isset($_POST['sections']) ? json_decode(stripslashes($_POST['sections']), true) : array();
        if (empty($sections) || !is_array($sections)) {
            wp_send_json_error('No sections to save');
        }

        // Let ACF process the form data.
        // acf_form_head() would normally handle this on POST,
        // but for AJAX we manually call acf_save_post().
        // ACF reads from $_POST['acf'] automatically.
        if (function_exists('acf_save_post')) {
            acf_save_post($post_id);
        }

        // Handle social links if profile section is included
        if (in_array('profile', $sections, true) && isset($_POST['social_links'])) {
            $user_id = get_post_field('post_author', $post_id);
            $allowed_platforms = array('website', 'instagram', 'facebook', 'youtube', 'linktree');

            foreach ($_POST['social_links'] as $key => $url) {
                // Strip the 'author_' prefix if present for matching
                $platform = str_replace('author_', '', sanitize_key($key));
                if (!in_array($platform, $allowed_platforms, true)) {
                    continue;
                }
                $url = esc_url_raw($url);
                if (!empty($url)) {
                    update_user_meta($user_id, "author_{$platform}", $url);
                } else {
                    delete_user_meta($user_id, "author_{$platform}");
                }
            }

            // Sync user meta → post meta
            if (function_exists('memdir_sync_user_to_post')) {
                memdir_sync_user_to_post($user_id);
            }
        }

        wp_send_json_success(array(
            'saved_sections' => $sections,
            'message' => 'All changes saved'
        ));
    }

    /**
     * Get map data — returns lightweight GeoJSON for all members with location
     *
     * Performance optimizations (designed for 5,000+ members):
     *  1. Transient cached for 6 hours (reliably invalidated on profile save)
     *  2. Batch meta prefetch: update_postmeta_cache() → 1 query vs N×10
     *  3. Batch taxonomy fetch: 3 queries total (not 3×N)
     *  4. Post cache priming: _prime_post_caches() for get_permalink/get_the_title
     *  5. Returns minimal fields: lat, lng, name, tagline, avatar, permalink, term IDs
     *  6. Two cache keys: 'public' and 'member' (different PMP visibility)
     */
    public function get_map_data()
    {
        check_ajax_referer('memdir_archive_nonce', 'nonce');

        $viewer_mode = is_user_logged_in() ? 'member' : 'public';
        $cache_key = 'memdir_map_data_' . MEMDIR_MAP_CACHE_VERSION . '_' . $viewer_mode;
        $cached = get_transient($cache_key);

        if ($cached !== false) {
            wp_send_json_success(array('members' => $cached));
        }

        // ─── OPTIMIZATION 1: Single query to get all member IDs ───
        $member_ids = get_posts(array(
            'post_type' => 'member-directory',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'fields' => 'ids',
        ));

        if (empty($member_ids)) {
            set_transient($cache_key, array(), 6 * HOUR_IN_SECONDS);
            wp_send_json_success(array('members' => array()));
        }

        // ─── OPTIMIZATION 2: Batch-prefetch ALL post meta in one query ───
        // This populates WP's object cache so subsequent get_post_meta()
        // and get_field() calls hit memory, not the database.
        // Without this: ~10 queries per member. With this: 1 query total.
        update_postmeta_cache($member_ids);

        // ─── OPTIMIZATION 3: Batch-fetch all taxonomy terms ───
        // Instead of 3 × wp_get_object_terms() per member (= 15,000 queries
        // at 5,000 members), do 3 queries total.
        $taxonomies = array('memdir_instruments', 'memdir_services', 'memdir_musical_contexts');
        $term_map = array();
        foreach ($taxonomies as $tax) {
            $terms = wp_get_object_terms($member_ids, $tax, array(
                'fields' => 'all_with_object_id',
            ));
            if (!is_wp_error($terms)) {
                foreach ($terms as $term) {
                    $term_map[$term->object_id][$tax][] = (int) $term->term_id;
                }
            }
        }

        // ─── OPTIMIZATION 4: Prime the post object cache ───
        // get_permalink() and get_the_title() need WP_Post objects.
        // This single query loads them all instead of one per member.
        _prime_post_caches($member_ids, false, false);

        $data = array();

        foreach ($member_ids as $post_id) {
            // Check PMP: is this member's location visible to this viewer?
            if (!Memdir_PMP_Visibility::can_view($post_id, 'business', memdir_field('location'), $viewer_mode)) {
                continue;
            }

            // Get location — ACF Google Map field returns array with lat/lng
            $location = get_field(memdir_field('location'), $post_id);
            if (empty($location) || !is_array($location)) {
                continue;
            }

            $lat = isset($location['lat']) ? floatval($location['lat']) : 0;
            $lng = isset($location['lng']) ? floatval($location['lng']) : 0;

            if ($lat === 0.0 && $lng === 0.0) {
                continue;
            }

            // Format display location based on specificity preference
            $specificity = get_field(memdir_field('location_specificity'), $post_id);
            if ($specificity === 'hide') {
                continue;
            }
            $display_location = memdir_format_location($location, $specificity ?: 'city_state');

            // Jitter coordinates slightly based on specificity (privacy)
            // For state/country level, offset by ~10-50km to avoid exact placement
            if ($specificity === 'state' || $specificity === 'country' || $specificity === 'region') {
                $lat += (mt_rand(-50, 50) / 1000);
                $lng += (mt_rand(-50, 50) / 1000);
            } elseif ($specificity === 'city_state' || $specificity === 'city') {
                $lat += (mt_rand(-10, 10) / 1000);
                $lng += (mt_rand(-10, 10) / 1000);
            }

            // Get minimal member info
            $name = get_field(memdir_field('full_name'), $post_id);
            if (empty($name)) {
                $name = get_the_title($post_id);
            }

            $tagline = '';
            if (Memdir_PMP_Visibility::can_view($post_id, 'profile', memdir_field('tagline'), $viewer_mode)) {
                $tagline = get_field(memdir_field('tagline'), $post_id) ?: '';
            }

            // Avatar — grab thumbnail size for minimal payload
            $avatar_url = '';
            $avatar = get_field(memdir_field('avatar'), $post_id);
            if ($avatar && isset($avatar['sizes']['thumbnail'])) {
                $avatar_url = $avatar['sizes']['thumbnail'];
            }

            $data[] = array(
                'id' => $post_id,
                'lat' => round($lat, 4),
                'lng' => round($lng, 4),
                'name' => $name,
                'tagline' => $tagline,
                'avatar' => $avatar_url,
                'location' => $display_location,
                'url' => get_permalink($post_id),
                'terms' => isset($term_map[$post_id]) ? $term_map[$post_id] : array(),
            );
        }

        // Cache for 6 hours — reliably invalidated on profile save
        set_transient($cache_key, $data, 6 * HOUR_IN_SECONDS);

        wp_send_json_success(array('members' => $data));
    }
}
