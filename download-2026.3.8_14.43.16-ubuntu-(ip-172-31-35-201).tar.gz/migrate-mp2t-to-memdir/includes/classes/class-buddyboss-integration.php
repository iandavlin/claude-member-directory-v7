<?php
/**
 * BuddyBoss Integration Class
 * Soft dependency — only loaded when BuddyBoss/BuddyPress is active
 * Registers a "Member Profile" tab on the BuddyBoss user profile
 */

if (!defined('ABSPATH'))
    exit;

class Memdir_BuddyBoss_Integration
{

    /**
     * Initialize BuddyBoss integration
     */
    public function __construct()
    {
        add_action('bp_setup_nav', array($this, 'register_profile_tab'), 100);
    }

    /**
     * Register the Member Profile tab in BuddyBoss navigation
     */
    public function register_profile_tab()
    {
        if (!function_exists('bp_core_new_nav_item')) {
            return;
        }

        bp_core_new_nav_item(array(
            'name' => 'Member Profile',
            'slug' => 'member-profile',
            'position' => 30,
            'show_for_displayed_user' => true,
            'screen_function' => array($this, 'screen_redirect'),
            'default_subnav_slug' => 'member-profile',
        ));
    }

    /**
     * Screen function — redirects to the member directory post
     */
    public function screen_redirect()
    {
        $displayed_user_id = bp_displayed_user_id();

        if (!$displayed_user_id) {
            return;
        }

        // Use memdir_get_profile_url() which handles both existing posts
        // and setup flow (with nonce) automatically
        $url = memdir_get_profile_url($displayed_user_id);

        wp_safe_redirect($url);
        exit;
    }
}
