<?php
/**
 * PMP Visibility Class
 * Handles Profile Member Privacy (PMP) checks using hierarchical system:
 * Field Override > Section Override > Global Default
 */

if (!defined('ABSPATH'))
    exit;

class Memdir_PMP_Visibility
{

    /**
     * Check if content can be viewed (4-gate check)
     * 
     * Gate 1: Is section enabled?
     * Gate 2: Does viewer have permission based on PMP?
     * Gate 3: What's the effective PMP value? (hierarchy check)
     * Gate 4: Does section have renderable content? (handled by template)
     * 
     * @param int $post_id The post ID
     * @param string $section The section key
     * @param string|null $field The field name (optional)
     * @param string|null $viewer_mode The viewer mode (edit/member/public)
     * @return bool True if content can be viewed
     */
    public static function can_view($post_id, $section, $field = null, $viewer_mode = null)
    {

        // Gate 1: Is section enabled?
        if (!memdir_is_section_enabled($post_id, $section)) {
            return false;
        }

        // Determine viewer mode if not provided
        if (!$viewer_mode) {
            $viewer_mode = memdir_get_viewer_mode($post_id);
        }

        // Edit mode sees everything
        if ($viewer_mode === 'edit') {
            return true;
        }

        // Gate 2 & 3: Check effective PMP value and viewer permission
        $pmp_value = self::get_effective_pmp($post_id, $section, $field);

        return self::viewer_can_see($viewer_mode, $pmp_value);
    }

    /**
     * Get the effective PMP value for a field or section
     * Follows hierarchy: Field Override > Section Override > Global Default
     * 
     * Field overrides always take highest priority when set, regardless
     * of whether the section is in 'global' or 'section' mode.
     * 
     * @param int $post_id The post ID
     * @param string $section The section key
     * @param string|null $field The field name (optional)
     * @return string The PMP value: 'public', 'members', or 'private'
     */
    public static function get_effective_pmp($post_id, $section, $field = null)
    {
        // HIGHEST PRIORITY: Field-level override (always checked first)
        if ($field) {
            $field_override_enabled = get_post_meta($post_id, "memdir_pmp_override_{$field}", true);

            if ($field_override_enabled) {
                $field_value = get_post_meta($post_id, "memdir_pmp_value_{$field}", true);
                $result = $field_value ? sanitize_key($field_value) : 'members';
                return $result;
            }
        }

        // Resolve correct ACF PMP field names for this section
        $pmp = memdir_get_section_pmp_fields($section);
        $section_mode = get_field($pmp['mode'], $post_id);

        // SECOND PRIORITY: Section override
        // Live ACF uses 'section' as the mode value; legacy code used 'override'
        if ($section_mode === 'section' || $section_mode === 'override') {
            $section_value = get_field($pmp['value'], $post_id);
            return $section_value ? sanitize_key($section_value) : 'members';
        }

        // LOWEST PRIORITY: Global default
        return self::get_global_pmp($post_id);
    }

    /**
     * Get the global default PMP value
     * 
     * @param int $post_id The post ID
     * @return string The global PMP value
     */
    private static $global_pmp_cache = array();

    public static function get_global_pmp($post_id)
    {
        if (isset(self::$global_pmp_cache[$post_id])) {
            return self::$global_pmp_cache[$post_id];
        }
        $global = get_field(memdir_field('member_pmp_default'), $post_id);
        $result = $global ? sanitize_key($global) : 'members';
        self::$global_pmp_cache[$post_id] = $result;
        return $result;
    }

    /**
     * Check if viewer mode has permission for PMP value
     * 
     * @param string $viewer_mode The viewer mode (edit/member/public)
     * @param string $pmp_value The PMP value (public/members/private)
     * @return bool True if viewer can see content
     */
    public static function viewer_can_see($viewer_mode, $pmp_value)
    {

        $viewer_mode = sanitize_key($viewer_mode);
        $pmp_value = sanitize_key($pmp_value);

        // Public content - everyone can see
        if ($pmp_value === 'public') {
            return true;
        }

        // Members content - members and editors can see
        if ($pmp_value === 'members') {
            return in_array($viewer_mode, array('member', 'edit'));
        }

        // Private content - only editors can see
        if ($pmp_value === 'private') {
            return ($viewer_mode === 'edit');
        }

        // Unknown PMP value - default to most restrictive
        return false;
    }

    /**
     * Check if a section has any renderable content
     * A section has content if at least one field is visible and not empty
     * 
     * @param int $post_id The post ID
     * @param string $section The section key
     * @param string $viewer_mode The viewer mode
     * @return bool True if section has visible content
     */
    private static $content_cache = array();

    public static function section_has_content($post_id, $section, $viewer_mode = null)
    {

        if (!$viewer_mode) {
            $viewer_mode = memdir_get_viewer_mode($post_id);
        }

        // Per-request cache — this method is called ~9 times per page
        // (business promotion check, nav pills, section rendering).
        $cache_key = "{$post_id}_{$section}_{$viewer_mode}";
        if (isset(self::$content_cache[$cache_key])) {
            return self::$content_cache[$cache_key];
        }

        // Edit mode always shows sections (even if empty, so user can fill them)
        if ($viewer_mode === 'edit') {
            self::$content_cache[$cache_key] = true;
            return true;
        }

        // Dynamic: read fields from ACF group instead of hardcoded list
        if (function_exists('memdir_get_section_content_fields')) {
            $fields = memdir_get_section_content_fields($section);

            foreach ($fields as $field) {
                if (!self::can_view($post_id, $section, $field['name'], $viewer_mode)) {
                    continue;
                }

                $value = get_field($field['name'], $post_id);
                if (!empty($value)) {
                    self::$content_cache[$cache_key] = true;
                    return true;
                }
            }
        }

        // Special: check social links in user meta (profile section)
        if ($section === 'profile' && function_exists('memdir_get_social_platforms')) {
            $post_author = get_post_field('post_author', $post_id);
            foreach (memdir_get_social_platforms() as $platform) {
                if (get_user_meta($post_author, $platform['meta_key'], true)) {
                    self::$content_cache[$cache_key] = true;
                    return true;
                }
            }
        }

        self::$content_cache[$cache_key] = false;
        return false;
    }
}
