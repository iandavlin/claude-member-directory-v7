<?php
/**
 * Endorsements & Vouch System
 *
 * Two community trust mechanisms:
 * 1. Skill Vouches    — members privately vouch for specific skills
 * 2. Trusted Network  — members designate trusted repair partners
 *
 * Design principles:
 * - No public counts (prevents popularity contests)
 * - Binary badge on skills (✓ vouched) after threshold of 2
 * - Named, public display for trusted network
 * - Private detail visible only to profile owner
 * - Members-only (must have published profile to vouch)
 *
 * @since 1.3.0
 */

if (!defined('ABSPATH'))
    exit;

class Memdir_Endorsements
{
    /* ── Constants ───────────────────────────────────────── */

    const TABLE_SUFFIX = 'memdir_endorsements';
    const TYPE_SKILL = 'skill_vouch';
    const TYPE_TRUSTED = 'trusted_repair';
    const VOUCH_THRESHOLD = 2;

    /* ── Internal Cache ──────────────────────────────────── */

    /** @var array Per-request vouch data: [cache_key => data] */
    private static $vouch_cache = array();

    /* ── Table Access ────────────────────────────────────── */

    /**
     * Get the full table name with prefix.
     *
     * @return string
     */
    private static function table()
    {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_SUFFIX;
    }

    /* ── Hook Registration ───────────────────────────────── */

    /**
     * Register AJAX hooks. Called on plugins_loaded.
     */
    public static function register()
    {
        add_action('wp_ajax_memdir_toggle_vouch', array(__CLASS__, 'ajax_toggle_vouch'));
        add_action('wp_ajax_memdir_get_vouch_summary', array(__CLASS__, 'ajax_get_vouch_summary'));
    }

    /* ── Database Setup ──────────────────────────────────── */

    /**
     * Create the endorsements table.
     * Called on plugin activation.
     *
     * Uses term_id = 0 (not NULL) for trusted_repair type,
     * ensuring the UNIQUE KEY enforces one-vouch-per-person.
     */
    public static function create_table()
    {
        global $wpdb;
        $table = self::table();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            endorser_id BIGINT(20) UNSIGNED NOT NULL,
            endorsed_post BIGINT(20) UNSIGNED NOT NULL,
            type VARCHAR(20) NOT NULL DEFAULT 'skill_vouch',
            term_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_vouch (endorser_id, endorsed_post, type, term_id),
            KEY idx_endorsed (endorsed_post, type),
            KEY idx_endorser (endorser_id, type)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /* ── CRUD ────────────────────────────────────────────── */

    /**
     * Toggle a vouch (insert if absent, delete if present).
     *
     * @param int    $endorser_user_id The user giving the vouch
     * @param int    $endorsed_post_id The member-directory post receiving it
     * @param string $type             'skill_vouch' or 'trusted_repair'
     * @param int    $term_id          Taxonomy term ID (0 for trusted_repair)
     * @return array|WP_Error { 'action' => 'added'|'removed', 'count' => int, 'meets_threshold' => bool }
     */
    public static function toggle($endorser_user_id, $endorsed_post_id, $type, $term_id = 0)
    {
        global $wpdb;

        $valid = self::validate($endorser_user_id, $endorsed_post_id, $type);
        if (is_wp_error($valid)) {
            return $valid;
        }

        $table = self::table();

        // Check if already exists (handle NULL term_id for legacy rows)
        if ((int) $term_id === 0) {
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table}
                 WHERE endorser_id = %d AND endorsed_post = %d AND type = %s
                 AND (term_id = 0 OR term_id IS NULL)",
                $endorser_user_id,
                $endorsed_post_id,
                $type
            ));
        } else {
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table}
                 WHERE endorser_id = %d AND endorsed_post = %d AND type = %s AND term_id = %d",
                $endorser_user_id,
                $endorsed_post_id,
                $type,
                $term_id
            ));
        }

        if ($existing) {
            $wpdb->delete($table, array('id' => $existing), array('%d'));
            $action = 'removed';
        } else {
            $wpdb->insert($table, array(
                'endorser_id' => $endorser_user_id,
                'endorsed_post' => $endorsed_post_id,
                'type' => $type,
                'term_id' => $term_id,
            ), array('%d', '%d', '%s', '%d'));
            $action = 'added';
        }

        // Invalidate caches
        self::invalidate_cache($endorsed_post_id);

        $count = self::get_count($endorsed_post_id, $type, $term_id);

        return array(
            'action' => $action,
            'count' => $count,
            'meets_threshold' => $count >= self::VOUCH_THRESHOLD,
        );
    }

    /**
     * Check if a user has vouched for a specific skill/trust.
     *
     * @param int    $endorser_user_id
     * @param int    $endorsed_post_id
     * @param string $type
     * @param int    $term_id
     * @return bool
     */
    public static function has_vouched($endorser_user_id, $endorsed_post_id, $type, $term_id = 0)
    {
        global $wpdb;
        $table = self::table();

        // For trusted_repair (term_id=0), also match NULL to cover legacy rows
        if ((int) $term_id === 0) {
            return (bool) $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table}
                 WHERE endorser_id = %d AND endorsed_post = %d AND type = %s
                 AND (term_id = 0 OR term_id IS NULL)",
                $endorser_user_id,
                $endorsed_post_id,
                $type
            ));
        }

        return (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table}
             WHERE endorser_id = %d AND endorsed_post = %d AND type = %s AND term_id = %d",
            $endorser_user_id,
            $endorsed_post_id,
            $type,
            $term_id
        ));
    }

    /**
     * Get vouch count for a specific item.
     *
     * @param int    $post_id
     * @param string $type
     * @param int    $term_id
     * @return int
     */
    public static function get_count($post_id, $type, $term_id = 0)
    {
        global $wpdb;
        $table = self::table();

        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table}
             WHERE endorsed_post = %d AND type = %s AND term_id = %d",
            $post_id,
            $type,
            $term_id
        ));
    }

    /* ── Batch Data Access ───────────────────────────────── */

    /**
     * Get all skill vouch data for a profile — used by the tag renderer.
     *
     * Fetches ALL term vouch counts + viewer-vouched flags in 1-2 queries,
     * then caches per-request so repeated calls are free.
     *
     * @param int      $post_id        The member-directory post ID
     * @param int|null $viewer_user_id The current viewer's user ID (null if logged out)
     * @return array [term_id => ['count' => int, 'viewer_vouched' => bool]]
     */
    public static function get_skill_vouch_data($post_id, $viewer_user_id = null)
    {
        $cache_key = $post_id . '_' . ($viewer_user_id ?: 0);
        if (isset(self::$vouch_cache[$cache_key])) {
            return self::$vouch_cache[$cache_key];
        }

        global $wpdb;
        $table = self::table();

        // Query 1: Get all skill vouch counts for this profile
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT term_id, COUNT(*) as cnt
             FROM {$table}
             WHERE endorsed_post = %d AND type = %s AND term_id > 0
             GROUP BY term_id",
            $post_id,
            self::TYPE_SKILL
        ));

        $data = array();
        foreach ($rows as $row) {
            $data[(int) $row->term_id] = array(
                'count' => (int) $row->cnt,
                'viewer_vouched' => false,
            );
        }

        // Query 2: If viewer is logged in, check which terms they've vouched
        if ($viewer_user_id) {
            $viewer_vouches = $wpdb->get_col($wpdb->prepare(
                "SELECT term_id FROM {$table}
                 WHERE endorser_id = %d AND endorsed_post = %d AND type = %s AND term_id > 0",
                $viewer_user_id,
                $post_id,
                self::TYPE_SKILL
            ));

            foreach ($viewer_vouches as $tid) {
                $tid = (int) $tid;
                if (isset($data[$tid])) {
                    $data[$tid]['viewer_vouched'] = true;
                } else {
                    // Viewer's vouch exists but count hasn't reached threshold yet
                    $data[$tid] = array(
                        'count' => 1,
                        'viewer_vouched' => true,
                    );
                }
            }
        }

        self::$vouch_cache[$cache_key] = $data;
        return $data;
    }

    /**
     * Get trusted-by endorsements for a profile.
     *
     * @param int $post_id The member-directory post
     * @return array List of [ 'user_id', 'post_id', 'name', 'url', 'location' ]
     */
    public static function get_trusted_by($post_id)
    {
        global $wpdb;
        $table = self::table();

        $endorser_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT endorser_id FROM {$table}
             WHERE endorsed_post = %d AND type = %s
             ORDER BY created_at ASC",
            $post_id,
            self::TYPE_TRUSTED
        ));

        if (empty($endorser_ids)) {
            return array();
        }

        return self::resolve_member_profiles_by_user($endorser_ids);
    }

    /**
     * Get the trust network for a member (who do they trust).
     *
     * @param int $user_id The member's user ID
     * @return array List of trusted luthier profiles
     */
    public static function get_trust_network($user_id)
    {
        global $wpdb;
        $table = self::table();

        $post_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT endorsed_post FROM {$table}
             WHERE endorser_id = %d AND type = %s
             ORDER BY created_at ASC",
            $user_id,
            self::TYPE_TRUSTED
        ));

        if (empty($post_ids)) {
            return array();
        }

        return self::resolve_member_profiles_by_post($post_ids);
    }

    /**
     * Get full vouch summary for edit mode — private to profile owner.
     *
     * @param int $post_id
     * @return array { 'skills' => [...], 'trusted_by' => [...] }
     */
    public static function get_edit_summary($post_id)
    {
        global $wpdb;
        $table = self::table();

        // Skill vouches with endorser names
        $skill_rows = $wpdb->get_results($wpdb->prepare(
            "SELECT e.term_id, e.endorser_id, u.display_name
             FROM {$table} e
             JOIN {$wpdb->users} u ON e.endorser_id = u.ID
             WHERE e.endorsed_post = %d AND e.type = %s AND e.term_id > 0
             ORDER BY e.term_id, e.created_at",
            $post_id,
            self::TYPE_SKILL
        ));

        $skills = array();

        // Batch-prime term cache: avoids N individual get_term() calls below
        if (!empty($skill_rows)) {
            $term_ids = array_unique(array_map(function ($r) {
                return (int) $r->term_id;
            }, $skill_rows));
            // Single query loads all terms into WP's term cache
            get_terms(array('include' => $term_ids, 'hide_empty' => false));
        }

        foreach ($skill_rows as $row) {
            $tid = (int) $row->term_id;
            if (!isset($skills[$tid])) {
                $term = get_term($tid);
                $skills[$tid] = array(
                    'term_name' => ($term && !is_wp_error($term)) ? $term->name : "Term #{$tid}",
                    'count' => 0,
                    'meets_threshold' => false,
                    'endorsers' => array(),
                );
            }
            $skills[$tid]['count']++;
            $skills[$tid]['meets_threshold'] = $skills[$tid]['count'] >= self::VOUCH_THRESHOLD;
            $skills[$tid]['endorsers'][] = $row->display_name;
        }

        // Trusted by
        $trusted_by = self::get_trusted_by($post_id);

        return array(
            'skills' => $skills,
            'trusted_by' => $trusted_by,
        );
    }

    /* ── Profile Resolution Helpers ──────────────────────── */

    /**
     * Resolve user IDs to member profile data.
     * Used to display who trusts a profile.
     *
     * Optimized: single get_posts(author__in) + batch meta prefetch
     * instead of N individual queries per user.
     *
     * @param array $user_ids
     * @return array
     */
    private static function resolve_member_profiles_by_user($user_ids)
    {
        if (empty($user_ids)) {
            return array();
        }

        // Single query: get all member posts authored by these users
        $posts = get_posts(array(
            'post_type' => 'member-directory',
            'author__in' => array_map('intval', $user_ids),
            'posts_per_page' => count($user_ids),
            'post_status' => 'publish',
            'no_found_rows' => true,
        ));

        if (empty($posts)) {
            return array();
        }

        // Batch prefetch all meta in one query
        $post_ids = wp_list_pluck($posts, 'ID');
        update_postmeta_cache($post_ids);

        // Build author → post map
        $by_author = array();
        foreach ($posts as $p) {
            $by_author[(int) $p->post_author] = $p;
        }

        $results = array();
        foreach ($user_ids as $uid) {
            $uid = (int) $uid;
            if (!isset($by_author[$uid])) {
                continue;
            }

            $post = $by_author[$uid];
            $mid = $post->ID;

            $name = get_field(memdir_field('full_name'), $mid);
            if (empty($name)) {
                $name = $post->post_title;
            }

            $location = '';
            $loc = get_field(memdir_field('location'), $mid);
            if ($loc && is_array($loc)) {
                $specificity = get_field(memdir_field('location_specificity'), $mid) ?: 'city_state';
                if (function_exists('memdir_format_location')) {
                    $location = memdir_format_location($loc, $specificity);
                }
            }

            $results[] = array(
                'user_id' => $uid,
                'post_id' => $mid,
                'name' => $name,
                'url' => get_permalink($mid),
                'location' => $location,
                'avatar' => get_avatar_url($uid, array('size' => 48)),
            );
        }

        return $results;
    }

    /**
     * Resolve post IDs to member profile data.
     * Used to display a builder's trust network.
     *
     * Optimized: batch prime post + meta caches first,
     * then loop hits only in-memory caches.
     *
     * @param array $post_ids
     * @return array
     */
    private static function resolve_member_profiles_by_post($post_ids)
    {
        if (empty($post_ids)) {
            return array();
        }

        $post_ids = array_map('intval', $post_ids);

        // Batch prime: post objects + all their meta in 2 queries
        _prime_post_caches($post_ids, true, false);
        update_postmeta_cache($post_ids);

        $results = array();
        foreach ($post_ids as $pid) {
            if (get_post_status($pid) !== 'publish') {
                continue;
            }

            $name = get_field(memdir_field('full_name'), $pid);
            if (empty($name)) {
                $name = get_the_title($pid);
            }

            $location = '';
            $loc = get_field(memdir_field('location'), $pid);
            if ($loc && is_array($loc)) {
                $specificity = get_field(memdir_field('location_specificity'), $pid) ?: 'city_state';
                if (function_exists('memdir_format_location')) {
                    $location = memdir_format_location($loc, $specificity);
                }
            }

            $results[] = array(
                'post_id' => $pid,
                'name' => $name,
                'url' => get_permalink($pid),
                'location' => $location,
                'avatar' => get_avatar_url((int) get_post_field('post_author', $pid), array('size' => 48)),
            );
        }

        return $results;
    }

    /* ── Validation ──────────────────────────────────────── */

    /**
     * Validate a vouch action.
     *
     * @param int    $endorser_user_id
     * @param int    $endorsed_post_id
     * @param string $type
     * @return true|WP_Error
     */
    private static function validate($endorser_user_id, $endorsed_post_id, $type)
    {
        if (!$endorser_user_id) {
            return new WP_Error('not_logged_in', 'You must be logged in to vouch.');
        }

        if (
            get_post_type($endorsed_post_id) !== 'member-directory' ||
            get_post_status($endorsed_post_id) !== 'publish'
        ) {
            return new WP_Error('invalid_post', 'Invalid member profile.');
        }

        // Can't vouch for yourself
        $post_author = (int) get_post_field('post_author', $endorsed_post_id);
        if ($post_author === $endorser_user_id) {
            return new WP_Error('self_vouch', 'You cannot vouch for yourself.');
        }

        // Endorser must have their own published profile
        $endorser_profile = get_posts(array(
            'post_type' => 'member-directory',
            'author' => $endorser_user_id,
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'fields' => 'ids',
        ));
        if (empty($endorser_profile)) {
            return new WP_Error('no_profile', 'You need a published profile to vouch.');
        }

        if (!in_array($type, array(self::TYPE_SKILL, self::TYPE_TRUSTED), true)) {
            return new WP_Error('invalid_type', 'Invalid endorsement type.');
        }

        return true;
    }

    /* ── Cache Management ────────────────────────────────── */

    /**
     * Invalidate all caches related to a profile.
     *
     * @param int $post_id
     */
    private static function invalidate_cache($post_id)
    {
        $prefix = (int) $post_id . '_';
        $prefix_len = strlen($prefix);
        foreach (array_keys(self::$vouch_cache) as $key) {
            if (substr($key, 0, $prefix_len) === $prefix) {
                unset(self::$vouch_cache[$key]);
            }
        }

        delete_transient('memdir_vouches_' . $post_id);
    }

    /* ── AJAX Handlers ───────────────────────────────────── */

    /**
     * Toggle a vouch via AJAX.
     *
     * POST params: post_id, type, term_id, nonce
     */
    public static function ajax_toggle_vouch()
    {
        check_ajax_referer('memdir_vouch_nonce', 'nonce');

        $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
        $type = isset($_POST['type']) ? sanitize_key($_POST['type']) : '';
        $term_id = isset($_POST['term_id']) ? absint($_POST['term_id']) : 0;

        $result = self::toggle(get_current_user_id(), $post_id, $type, $term_id);

        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }

        wp_send_json_success($result);
    }

    /**
     * Get vouch summary for edit mode via AJAX.
     *
     * Only the profile owner (or admin) can access this.
     */
    public static function ajax_get_vouch_summary()
    {
        check_ajax_referer('memdir_vouch_nonce', 'nonce');

        $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;

        $post_author = (int) get_post_field('post_author', $post_id);
        if ($post_author !== get_current_user_id() && !current_user_can('manage_options')) {
            wp_send_json_error('Not authorized.');
        }

        wp_send_json_success(self::get_edit_summary($post_id));
    }
}
