<?php
/**
 * Schema.org JSON-LD Output
 * Outputs Person and LocalBusiness structured data on single member pages.
 * Respects PMP visibility — only includes publicly visible fields.
 */

if (!defined('ABSPATH'))
    exit;

class Memdir_Schema_Output
{

    public function __construct()
    {
        add_action('wp_head', array($this, 'output_schema'), 99);
        add_action('wp_head', array($this, 'output_og_meta'), 5);
    }

    /**
     * Output Open Graph meta tags optimized for Instagram on single member pages.
     * Instagram reads OG tags natively for link previews in bios, stories, and DMs.
     */
    public function output_og_meta()
    {
        if (!is_singular('member-directory')) {
            return;
        }

        $post_id = get_the_ID();

        // Name
        $name = get_field(memdir_field('full_name'), $post_id);
        if (empty($name)) {
            $name = get_the_title($post_id);
        }
        if (empty($name)) {
            return;
        }

        $url = get_permalink($post_id);

        // Description — use bio if publicly visible, else a generic fallback
        $description = '';
        if (Memdir_PMP_Visibility::can_view($post_id, 'profile', memdir_field('bio'), 'public')) {
            $bio = get_field(memdir_field('bio'), $post_id);
            if ($bio) {
                $description = wp_trim_words(wp_strip_all_tags($bio), 30, '…');
            }
        }
        if (empty($description)) {
            $description = $name . ' — Member Profile';
        }

        // Image — avatar if publicly visible
        $image_url = '';
        $avatar = null;
        if (Memdir_PMP_Visibility::can_view($post_id, 'profile', memdir_field('avatar'), 'public')) {
            $avatar = get_field(memdir_field('avatar'), $post_id);
            if ($avatar && isset($avatar['url'])) {
                $image_url = $avatar['url'];
            }
        }

        // Site name
        $site_name = get_bloginfo('name');

        // Output OG tags
        echo "\n<!-- Member Directory Open Graph -->\n";
        echo '<meta property="og:type" content="profile" />' . "\n";
        echo '<meta property="og:title" content="' . esc_attr($name) . '" />' . "\n";
        echo '<meta property="og:description" content="' . esc_attr($description) . '" />' . "\n";
        echo '<meta property="og:url" content="' . esc_url($url) . '" />' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr($site_name) . '" />' . "\n";
        // Instagram-optimized OG image tags (Instagram reads OG natively)
        if ($image_url) {
            echo '<meta property="og:image" content="' . esc_url($image_url) . '" />' . "\n";

            // Instagram favors square images for link previews in bios/stories/DMs
            $image_id = ($avatar && isset($avatar['ID'])) ? $avatar['ID'] : 0;
            if ($image_id) {
                $image_meta = wp_get_attachment_image_src($image_id, 'large');
                if ($image_meta) {
                    echo '<meta property="og:image:width" content="' . esc_attr($image_meta[1]) . '" />' . "\n";
                    echo '<meta property="og:image:height" content="' . esc_attr($image_meta[2]) . '" />' . "\n";
                }
            }

            echo '<meta property="og:image:alt" content="' . esc_attr($name) . ' — Member Profile Photo" />' . "\n";
        }
    }

    /**
     * Output JSON-LD on single member directory pages.
     */
    public function output_schema()
    {
        if (!is_singular('member-directory')) {
            return;
        }

        $post_id = get_the_ID();

        // Use 'public' viewer to only expose publicly-safe data
        $viewer_mode = 'public';

        $schemas = array();

        // Person schema
        $person = $this->build_person_schema($post_id, $viewer_mode);
        if ($person) {
            $schemas[] = $person;
        }

        // LocalBusiness schema (if business section is public)
        $business = $this->build_business_schema($post_id, $viewer_mode);
        if ($business) {
            $schemas[] = $business;
        }

        if (empty($schemas)) {
            return;
        }

        foreach ($schemas as $schema) {
            echo "\n" . '<script type="application/ld+json">' . "\n";
            echo wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            echo "\n" . '</script>' . "\n";
        }
    }

    /**
     * Build Person schema.
     */
    private function build_person_schema($post_id, $viewer_mode)
    {
        $name = get_field(memdir_field('full_name'), $post_id);
        if (empty($name)) {
            $name = get_the_title($post_id);
        }

        if (empty($name)) {
            return null;
        }

        $person = array(
            '@context' => 'https://schema.org',
            '@type' => 'Person',
            'name' => $name,
            'url' => get_permalink($post_id),
        );

        // Avatar as image
        if (Memdir_PMP_Visibility::can_view($post_id, 'profile', memdir_field('avatar'), $viewer_mode)) {
            $avatar = get_field(memdir_field('avatar'), $post_id);
            if ($avatar && isset($avatar['url'])) {
                $person['image'] = $avatar['url'];
            }
        }

        // Bio as description
        if (Memdir_PMP_Visibility::can_view($post_id, 'profile', memdir_field('bio'), $viewer_mode)) {
            $bio = get_field(memdir_field('bio'), $post_id);
            if ($bio) {
                $person['description'] = wp_strip_all_tags($bio);
            }
        }

        // Location
        if (Memdir_PMP_Visibility::can_view($post_id, 'business', memdir_field('location'), $viewer_mode)) {
            $location = get_field(memdir_field('location'), $post_id);
            $specificity = get_field(memdir_field('location_specificity'), $post_id);

            if ($location && $specificity !== 'hide') {
                $person['address'] = array(
                    '@type' => 'PostalAddress',
                    'addressLocality' => $location,
                );
            }
        }

        // Social links as sameAs — only if PMP allows public visibility
        if (Memdir_PMP_Visibility::can_view($post_id, 'profile', 'social_links', $viewer_mode)) {
            $social_links = $this->get_public_social_links($post_id);
            if (!empty($social_links)) {
                $person['sameAs'] = $social_links;
            }
        }

        // Instruments as knowsAbout
        if (
            memdir_is_section_enabled($post_id, 'craft') &&
            Memdir_PMP_Visibility::can_view($post_id, 'craft', memdir_field('craft_instruments'), $viewer_mode)
        ) {
            $instruments = get_the_terms($post_id, 'memdir_instruments');
            if ($instruments && !is_wp_error($instruments)) {
                $person['knowsAbout'] = wp_list_pluck($instruments, 'name');
            }
        }

        return $person;
    }

    /**
     * Build LocalBusiness schema.
     */
    private function build_business_schema($post_id, $viewer_mode)
    {
        // Only output if business section is enabled and visible
        if (!memdir_is_section_enabled($post_id, 'business')) {
            return null;
        }

        if (!Memdir_PMP_Visibility::can_view($post_id, 'business', null, $viewer_mode)) {
            return null;
        }

        $biz_name = '';
        if (Memdir_PMP_Visibility::can_view($post_id, 'business', memdir_field('business_name'), $viewer_mode)) {
            $biz_name = get_field(memdir_field('business_name'), $post_id);
        }

        if (empty($biz_name)) {
            return null;
        }

        $business = array(
            '@context' => 'https://schema.org',
            '@type' => 'LocalBusiness',
            'name' => $biz_name,
            'url' => get_permalink($post_id),
        );

        // Logo — check field-level PMP
        if (Memdir_PMP_Visibility::can_view($post_id, 'business', memdir_field('business_logo'), $viewer_mode)) {
            $logo = get_field(memdir_field('business_logo'), $post_id);
            if ($logo && isset($logo['url'])) {
                $business['logo'] = $logo['url'];
            }
        }

        // Address — derived from the google_map field which stores structured location data
        if (Memdir_PMP_Visibility::can_view($post_id, 'business', memdir_field('business_location'), $viewer_mode)) {
            $location = get_field(memdir_field('business_location'), $post_id);
            if ($location && !empty($location['address'])) {
                $address = array('@type' => 'PostalAddress');
                if (!empty($location['street_number']) || !empty($location['street_name'])) {
                    $address['streetAddress'] = trim(
                        ($location['street_number'] ?? '') . ' ' . ($location['street_name'] ?? '')
                    );
                }
                if (!empty($location['city'])) {
                    $address['addressLocality'] = $location['city'];
                }
                if (!empty($location['state_short'])) {
                    $address['addressRegion'] = $location['state_short'];
                }
                if (!empty($location['post_code'])) {
                    $address['postalCode'] = $location['post_code'];
                }
                if (!empty($location['country_short'])) {
                    $address['addressCountry'] = $location['country_short'];
                }
                $business['address'] = $address;
            }
        }

        // Hours — check field-level PMP
        if (Memdir_PMP_Visibility::can_view($post_id, 'business', memdir_field('business_hours'), $viewer_mode)) {
            $hours = get_field(memdir_field('business_hours'), $post_id);
            if ($hours) {
                $business['openingHours'] = $hours;
            }
        }

        // Services as description — check field-level PMP before exposing in schema.
        // Services taxonomy belongs to the business section.
        if (
            memdir_is_section_enabled($post_id, 'business') &&
            Memdir_PMP_Visibility::can_view($post_id, 'business', memdir_field('business_services'), $viewer_mode)
        ) {
            $services = get_the_terms($post_id, 'memdir_services');
            if ($services && !is_wp_error($services)) {
                $service_names = wp_list_pluck($services, 'name');
                $business['description'] = 'Services: ' . implode(', ', $service_names);
            }
        }

        return $business;
    }

    /**
     * Get publicly visible social links as URLs.
     */
    private function get_public_social_links($post_id)
    {
        $author_id = get_post_field('post_author', $post_id);
        $links = array();

        // Prime user meta cache if not already loaded — avoids 5 individual
        // get_user_meta queries (one per social platform).
        if (false === wp_cache_get($author_id, 'user_meta')) {
            update_meta_cache('user', array($author_id));
        }

        // Use canonical platform list — automatically includes new platforms.
        $platforms = function_exists('memdir_get_social_platforms')
            ? memdir_get_social_platforms()
            : array();

        foreach ($platforms as $platform) {
            $value = get_user_meta($author_id, $platform['meta_key'], true);
            if ($value && filter_var($value, FILTER_VALIDATE_URL)) {
                $links[] = $value;
            }
        }

        return $links;
    }
}
