<?php
/**
 * Helper Functions
 * Core utility functions for the Member Directory plugin
 */

if (!defined('ABSPATH'))
    exit;

/**
 * Get the current viewer mode (edit/member/public)
 * 
 * @param int|null $post_id The post ID to check (defaults to current post)
 * @return string The viewer mode: 'edit', 'member', or 'public'
 */
function memdir_get_viewer_mode($post_id = null)
{
    static $cache = array();

    if (!$post_id) {
        $post_id = get_the_ID();
    }

    $key = (int) $post_id;
    if (isset($cache[$key])) {
        return $cache[$key];
    }

    // Not logged in = public
    if (!is_user_logged_in()) {
        $cache[$key] = 'public';
        return 'public';
    }

    // Check if user can edit this profile
    if (memdir_can_edit($post_id)) {
        // Owner/admin can override mode via URL parameter for preview
        if (isset($_GET['mode']) && in_array($_GET['mode'], array('member', 'public'))) {
            $mode = sanitize_key($_GET['mode']);
            $cache[$key] = $mode;
            return $mode;
        }
        $cache[$key] = 'edit';
        return 'edit';
    }

    // Logged in but not owner/admin = member
    $cache[$key] = 'member';
    return 'member';
}

/**
 * Check if current user can edit the profile
 * 
 * @param int|null $post_id The post ID to check
 * @return bool True if user can edit
 */
function memdir_can_edit($post_id = null)
{

    if (!$post_id) {
        $post_id = get_the_ID();
    }

    if (!$post_id) {
        return false;
    }

    // Admins can edit any profile
    if (current_user_can('administrator')) {
        return true;
    }

    // Finding #20: Editors with edit_others_posts can also edit any profile (DOCs requirement)
    if (current_user_can('edit_others_posts')) {
        return true;
    }

    // Check if current user is the post author
    $current_user_id = get_current_user_id();
    $post_author_id = intval(get_post_field('post_author', $post_id));

    return ($current_user_id === $post_author_id);
}

/**
 * Get the member directory post for a user
 * 
 * @param int|null $user_id The user ID (defaults to current user)
 * @return WP_Post|false The post object or false if not found
 */
function memdir_get_user_post($user_id = null)
{
    static $cache = array();

    if (!$user_id) {
        $user_id = get_current_user_id();
    }

    if (!$user_id) {
        return false;
    }

    $key = (int) $user_id;
    if (isset($cache[$key])) {
        return $cache[$key];
    }

    $args = array(
        'post_type' => 'member-directory',
        'author' => $user_id,
        'posts_per_page' => 1,
        'post_status' => 'any'
    );

    $posts = get_posts($args);

    $result = !empty($posts) ? $posts[0] : false;
    $cache[$key] = $result;
    return $result;
}

/**
 * Check if a section is enabled for a post
 * 
 * @param int $post_id The post ID
 * @param string $section The section key (profile, craft, network, etc.)
 * @return bool True if section is enabled
 */
function memdir_is_section_enabled($post_id, $section)
{
    // Per-request static cache — avoids repeated get_field() calls
    // for the same section on the same post (called 15–20× per page).
    static $cache = array();

    $key = "{$post_id}_{$section}";
    if (isset($cache[$key])) {
        return $cache[$key];
    }

    // Profile section is always enabled
    if ($section === 'profile') {
        $cache[$key] = true;
        return true;
    }

    // Check ACF field for section enable toggle
    // Uses memdir_field() to resolve through the alias map, since the new
    // section keys (craft, network, workshop) map to old ACF field names
    // (member_directory_enable_craft, member_directory_enable_network, etc.)
    $field_name = memdir_field("enable_{$section}");
    $enabled = get_field($field_name, $post_id);

    $result = (bool) $enabled;
    $cache[$key] = $result;
    return $result;
}

/**
 * Get all section definitions
 * 
 * @return array Array of section definitions
 */
function memdir_get_sections()
{
    return array(
        'profile' => array(
            'label' => 'Profile',
            'template' => 'section-profile.php'
        ),
        'craft' => array(
            'label' => 'Craft & Skills',
            'template' => 'section-craft.php'
        ),
        'business' => array(
            'label' => 'Business',
            'template' => 'section-business.php'
        ),
        'network' => array(
            'label' => 'Network',
            'template' => 'section-network.php'
        ),
        'workshop' => array(
            'label' => 'Workshop',
            'template' => 'section-workshop.php'
        ),
        'experience' => array(
            'label' => 'Experience',
            'template' => 'section-experience.php'
        ),
        'vibe' => array(
            'label' => 'Vibe',
            'template' => 'section-vibe.php'
        )
    );
}

/**
 * Get URL for a user's profile
 * Returns the profile URL if a post exists, or the setup URL to create one
 * 
 * @param int|null $user_id The user ID
 * @return string The profile URL or setup URL
 */
function memdir_get_profile_url($user_id = null)
{

    $post = memdir_get_user_post($user_id);

    if ($post) {
        return get_permalink($post->ID);
    }

    // No post exists - return setup URL with nonce
    return wp_nonce_url(
        add_query_arg('memdir_setup', '1', home_url('/member-dir/')),
        'memdir_setup_profile'
    );
}

/**
 * Get sections in display order, with optional business-first promotion
 * 
 * For public/member viewers: if Business section is enabled and has content,
 * it is promoted to the first position in the section list.
 * For edit mode: default order is preserved.
 * 
 * @param int $post_id The post ID
 * @param string $viewer_mode The viewer mode (edit/member/public)
 * @return array Ordered section definitions
 */
function memdir_get_ordered_sections($post_id, $viewer_mode)
{

    $sections = memdir_get_sections();

    // Business promotion only applies to non-edit modes
    if ($viewer_mode === 'edit') {
        return $sections;
    }

    // Check if business section qualifies for promotion
    if (
        memdir_is_section_enabled($post_id, 'business') &&
        Memdir_PMP_Visibility::section_has_content($post_id, 'business', $viewer_mode)
    ) {
        // Extract business and reinsert at position 1 (after profile)
        $business = $sections['business'];
        unset($sections['business']);

        // Rebuild: profile first, then business, then the rest
        $ordered = array();
        foreach ($sections as $key => $section) {
            $ordered[$key] = $section;
            // Insert business right after profile
            if ($key === 'profile') {
                $ordered['business'] = $business;
            }
        }

        return $ordered;
    }

    return $sections;
}

/**
 * Debug logging — only active when MEMDIR_DEBUG is defined and truthy.
 * Writes to the WP debug log (wp-content/debug.log when WP_DEBUG_LOG is on).
 *
 * @param string $message   Log message
 * @param mixed  $data      Optional data to dump (arrays/objects get print_r'd)
 */
function memdir_log($message, $data = null)
{
    if (!defined('MEMDIR_DEBUG') || !MEMDIR_DEBUG) {
        return;
    }

    $entry = '[MEMDIR] ' . $message;

    if ($data !== null) {
        $entry .= ' | ' . (is_scalar($data) ? $data : print_r($data, true));
    }

    if (function_exists('error_log')) {
        error_log($entry);
    }
}

/**
 * Check if this plugin is network-activated in a WordPress Multisite install.
 *
 * @return bool True if network-activated, false otherwise.
 */
function memdir_is_network_active()
{
    if (!is_multisite()) {
        return false;
    }

    $plugins = get_site_option('active_sitewide_plugins', array());
    return isset($plugins[plugin_basename(MEMDIR_PLUGIN_DIR . 'memdir-member-directory.php')]);
}

/**
 * Format a location string based on the user's chosen specificity/precision.
 *
 * This is the single source of truth for location formatting logic.
 * Used by header-profile.php (single page) and member-card.php (archive card).
 *
 * @param mixed  $location    The raw location value (string or ACF Google Map array).
 * @param string $specificity The precision setting from ACF field 'memdir_location_specificity'.
 *                            Values: 'exact', 'neighborhood', 'city_state', 'state', 'country', 'hide'.
 * @return string Formatted location text, or empty string if hidden.
 */
function memdir_format_location($location, $specificity)
{
    if (empty($location)) {
        return '';
    }

    // Handle ACF Google Map array or plain string
    $address = is_array($location) && isset($location['address']) ? $location['address'] : $location;

    if (empty($address) || !is_string($address)) {
        return '';
    }

    switch ($specificity) {
        case 'exact':
            return $address;

        case 'neighborhood':
            $parts = array_map('trim', explode(',', $address));
            return isset($parts[1]) ? $parts[1] : $address;

        case 'city_state':
        case 'city': // Legacy alias
            $parts = array_map('trim', explode(',', $address));
            $count = count($parts);
            if ($count >= 2) {
                return $parts[$count - 2] . ', ' . $parts[$count - 1];
            }
            return $address;

        case 'state':
            $parts = array_map('trim', explode(',', $address));
            $count = count($parts);
            return isset($parts[$count - 2]) ? $parts[$count - 2] : $address;

        case 'country':
        case 'region': // Legacy alias
            $parts = array_map('trim', explode(',', $address));
            return end($parts);

        case 'hide':
        default:
            return '';
    }
}

/**
 * Get the list of supported social platforms with their meta keys and icons.
 *
 * Single source of truth used by header-profile, header-business,
 * social-links component, and schema output.
 *
 * @return array Associative array: platform_key => array('meta_key' => ..., 'icon' => ..., 'label' => ...)
 */
function memdir_get_social_platforms()
{
    return array(
        'website' => array(
            'meta_key' => 'author_website',
            'icon' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>',
            'label' => 'Website'
        ),
        'instagram' => array(
            'meta_key' => 'author_instagram',
            'icon' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2zm-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6zm9.65 1.5a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5zM12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6z"/></svg>',
            'label' => 'Instagram'
        ),
        'facebook' => array(
            'meta_key' => 'author_facebook',
            'icon' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c5.05-.5 9-4.76 9-9.95z"/></svg>',
            'label' => 'Facebook'
        ),
        'youtube' => array(
            'meta_key' => 'author_youtube',
            'icon' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M21.54 7.2s-.2-1.4-.81-2.02c-.78-.81-1.65-.82-2.05-.86C15.83 4.1 12 4.1 12 4.1h-.01s-3.83 0-6.68.22c-.4.05-1.27.05-2.05.86-.61.62-.8 2.02-.8 2.02S2.24 8.82 2.24 10.44v1.52c0 1.62.22 3.24.22 3.24s.2 1.4.8 2.02c.78.81 1.81.79 2.27.87 1.65.16 6.47.21 6.47.21s3.84-.01 6.69-.23c.4-.05 1.27-.05 2.05-.86.61-.62.8-2.02.8-2.02s.22-1.62.22-3.24v-1.52c0-1.62-.22-3.24-.22-3.24zM9.75 15.02V8.98L15.5 12l-5.75 3.02z"/></svg>',
            'label' => 'YouTube'
        ),
        'linktree' => array(
            'meta_key' => 'author_linktree',
            'icon' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M7.95 13.23l-3.07 3.07 1.77 1.77L9.72 15l2.28 2.28 2.28-2.28 3.07 3.07 1.77-1.77-3.07-3.07H19.5v-2.5h-3.45L19.12 7.66l-1.77-1.77L12 11.21 6.65 5.89 4.88 7.66l3.07 3.07H4.5v2.5h3.45zM11 17.5h2V22h-2z"/></svg>',
            'label' => 'Linktree'
        ),
    );
}

/**
 * Build the privacy meta_query for filtering member directory listings.
 *
 * Hides fully-private profiles from non-logged-in visitors.
 * Used by both the initial archive query (functions-setup.php pre_get_posts)
 * and the AJAX search handler (class-ajax-handler.php search_members).
 *
 * @return array|null WP_Query-compatible meta_query array, or null if no filtering needed.
 */
function memdir_get_privacy_meta_query()
{
    if (is_user_logged_in()) {
        return null;
    }

    return array(
        'relation' => 'OR',
        array(
            'key' => memdir_field('member_pmp_default'),
            'value' => 'public',
            'compare' => '=',
        ),
        // Members-only profiles are visible in listing but restricted on detail
        array(
            'key' => memdir_field('member_pmp_default'),
            'value' => 'members',
            'compare' => '=',
        ),
        // Include profiles where no PMP meta exists yet (new profiles default to 'members')
        array(
            'key' => memdir_field('member_pmp_default'),
            'compare' => 'NOT EXISTS',
        ),
    );
}

/**
 * Get the ACF PMP field names for a given section.
 *
 * Delegates to the centralized field map in functions-field-map.php.
 * See memdir_get_section_pmp_map() for the actual field name resolution.
 *
 * @param string $section The section key (profile, craft, network, business, workshop, experience, vibe).
 * @return array Associative array with keys 'mode' and 'value'.
 */
function memdir_get_section_pmp_fields($section)
{
    return memdir_get_section_pmp_map($section);
}
