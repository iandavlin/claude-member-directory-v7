<?php
/**
 * Social Link Sync Functions
 * Bi-directional sync between user meta (author_*) and post meta (memdir_social_*)
 * 
 * Canonical source: User Meta (author_website, author_instagram, etc.)
 * Convenience copy: Post Meta (memdir_social_website, memdir_social_instagram, etc.)
 */

if (!defined('ABSPATH'))
    exit;

// Use the canonical definition from helpers.php


/**
 * Sync social links from Post Meta → User Meta
 * Triggered when a member-directory post is saved via ACF
 *
 * @param int $post_id The post ID being saved
 */
function memdir_sync_post_to_user($post_id)
{
    // Only run on member-directory posts
    if (get_post_type($post_id) !== 'member-directory') {
        return;
    }

    // Prevent infinite loop
    remove_action('profile_update', 'memdir_sync_user_to_post', 10);

    $user_id = get_post_field('post_author', $post_id);

    // Guard: Only sync if at least one memdir_social_* field exists on post meta.
    // This prevents saving a non-social section (e.g. Business) from wiping social links
    // because those fields would all be empty/unset on the post.
    $has_any_social = false;
    foreach (array_keys(memdir_get_social_platforms()) as $platform) {
        if (get_field("memdir_social_{$platform}", $post_id)) {
            $has_any_social = true;
            break;
        }
    }

    if (!$has_any_social) {
        // No social fields on this post — skip sync to avoid wiping user meta
        add_action('profile_update', 'memdir_sync_user_to_post', 10, 1);
        return;
    }

    foreach (array_keys(memdir_get_social_platforms()) as $platform) {
        $post_meta_key = "memdir_social_{$platform}";
        $user_meta_key = "author_{$platform}";

        $value = get_field($post_meta_key, $post_id);

        if (!empty($value)) {
            update_user_meta($user_id, $user_meta_key, esc_url_raw($value));
        } else {
            delete_user_meta($user_id, $user_meta_key);
        }
    }

    add_action('profile_update', 'memdir_sync_user_to_post', 10, 1);
}
add_action('acf/save_post', 'memdir_sync_post_to_user', 20);

/**
 * Sync social links from User Meta → Post Meta
 * Triggered when a WordPress user profile is updated, or called directly
 * after AJAX social link saves.
 *
 * Finding #15 — Sync trigger edge case:
 * AJAX social link saves in class-ajax-handler.php use update_user_meta(),
 * which does NOT fire the 'profile_update' hook. The AJAX handler compensates
 * by manually calling memdir_sync_user_to_post($user_id) after saving. This is
 * correct behavior but should be preserved if the AJAX handler is refactored.
 *
 * @param int $user_id The user ID being updated
 */
function memdir_sync_user_to_post($user_id)
{
    $post = memdir_get_user_post($user_id);

    if (!$post) {
        return;
    }

    // Prevent infinite loop
    remove_action('acf/save_post', 'memdir_sync_post_to_user', 20);

    foreach (array_keys(memdir_get_social_platforms()) as $platform) {
        $user_meta_key = "author_{$platform}";
        $post_meta_key = "memdir_social_{$platform}";

        $value = get_user_meta($user_id, $user_meta_key, true);

        if (!empty($value)) {
            update_field($post_meta_key, esc_url_raw($value), $post->ID);
        } else {
            delete_field($post_meta_key, $post->ID);
        }
    }

    add_action('acf/save_post', 'memdir_sync_post_to_user', 20);
}
add_action('profile_update', 'memdir_sync_user_to_post', 10, 1);
