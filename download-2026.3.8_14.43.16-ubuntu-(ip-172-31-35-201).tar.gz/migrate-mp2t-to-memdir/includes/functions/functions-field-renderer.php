<?php
/**
 * Dynamic Field Renderer
 *
 * Reads ACF field groups at runtime and renders fields based on their type.
 * This eliminates hardcoded field references in display templates — adding
 * a field in ACF automatically makes it appear on the public profile.
 *
 * @since 3.1.0
 */

if (!defined('ABSPATH'))
    exit;

/**
 * Map section keys to their ACF field group keys.
 *
 * When a new section is created with its own ACF group,
 * add the mapping here.
 *
 * @return array Section key => ACF group key
 */
function memdir_get_section_group_map()
{
    return array(
        'profile' => 'group_md_02_profile',
        'craft' => 'group_md_03_craft',
        'business' => 'group_md_05_business',
        'network' => 'group_md_04_connect',
        'workshop' => 'group_md_06_workspace',
        'experience' => 'group_md_07_experience',
        'vibe' => 'group_md_08_vibe',
    );
}

/**
 * Get the ACF group key for a section.
 *
 * @param string $section Section key (e.g. 'profile', 'business')
 * @return string|null ACF group key, or null if not mapped
 */
function memdir_get_section_acf_group($section)
{
    $map = memdir_get_section_group_map();
    return $map[$section] ?? null;
}

/**
 * Get content fields for a section (excluding PMP control fields).
 *
 * Reads the ACF field group at runtime and filters out:
 *  - PMP mode/value fields (contain '_pmp_')
 *  - Any fields in the $exclude array
 *
 * @param string $section  Section key
 * @param array  $exclude  Optional. Field names to exclude from rendering
 *                         (e.g. fields handled by header components)
 * @return array ACF field definitions
 */
function memdir_get_section_content_fields($section, $exclude = array())
{
    // Per-request static cache — avoids repeated acf_get_fields() + filtering.
    // Called ~14× per page (once per section for rendering + section_has_content).
    static $cache = array();

    $key = $section . '_' . implode(',', $exclude);
    if (isset($cache[$key])) {
        return $cache[$key];
    }

    if (!function_exists('acf_get_fields')) {
        return array();
    }

    $group_key = memdir_get_section_acf_group($section);
    if (!$group_key) {
        return array();
    }

    $all_fields = acf_get_fields($group_key);
    if (!$all_fields) {
        return array();
    }

    $result = array_filter($all_fields, function ($field) use ($exclude) {
        // Skip PMP/privacy control fields (infix _privacy_ or suffix _privacy)
        if (strpos($field['name'], '_pmp_') !== false || strpos($field['name'], '_privacy_') !== false) {
            return false;
        }
        if (substr($field['name'], -8) === '_privacy') {
            return false;
        }
        // Skip admin-only control fields (precision selectors, header preference, etc.)
        if (substr($field['name'], -10) === '_precision') {
            return false;
        }
        if (strpos($field['name'], '_default_header') !== false) {
            return false;
        }
        // Skip section enable toggles (e.g. memdir_enable_craft)
        if (strpos($field['name'], '_enable_') !== false) {
            return false;
        }
        // Skip block-level enable toggles (e.g. memdir_employment_enabled)
        // These render as bare "Yes" labels in display mode — meaningless to viewers
        if (substr($field['name'], -8) === '_enabled') {
            return false;
        }
        // Skip ACF 'message' type fields (admin UI hints, no stored data)
        if ($field['type'] === 'message') {
            return false;
        }
        // Skip 'button_group' type fields — these are always admin PMP controls
        if ($field['type'] === 'button_group') {
            return false;
        }
        // Skip ACF 'tab' type fields — these are UI groupings, not data
        if ($field['type'] === 'tab') {
            return false;
        }
        // Skip explicitly excluded fields
        if (in_array($field['name'], $exclude, true)) {
            return false;
        }
        return true;
    });

    $cache[$key] = $result;
    return $result;
}

/**
 * Render all content fields for a section's display mode.
 *
 * Loops through the section's ACF fields, checks PMP visibility,
 * and renders each field based on its ACF type.
 *
 * @param int    $post_id      The member directory post ID
 * @param string $section      Section key (e.g. 'workshop')
 * @param string $viewer_mode  Current viewer mode ('public', 'member', 'edit')
 * @param array  $exclude      Optional. Field names to exclude from rendering
 */
function memdir_render_section_content($post_id, $section, $viewer_mode, $exclude = array())
{
    $fields = memdir_get_section_content_fields($section, $exclude);

    if (empty($fields)) {
        return;
    }

    $has_output = false;

    foreach ($fields as $field) {
        // Check PMP visibility
        if (!Memdir_PMP_Visibility::can_view($post_id, $section, $field['name'], $viewer_mode)) {
            continue;
        }

        // Get the value
        $value = get_field($field['name'], $post_id);

        // Skip empty values
        if (memdir_is_field_empty($value, $field['type'])) {
            continue;
        }

        memdir_render_field($field, $value, $post_id, $section, $viewer_mode);
        $has_output = true;
    }

    if (!$has_output) {
        echo '<p class="memdir-empty-section">No information added yet.</p>';
    }
}

/**
 * Check if a field value is effectively empty.
 *
 * @param mixed  $value  The field value
 * @param string $type   The ACF field type
 * @return bool True if the value should be considered empty
 */
function memdir_is_field_empty($value, $type)
{
    if ($value === null || $value === '' || $value === false) {
        return true;
    }

    // Arrays (images, files, links, galleries, taxonomies, checkboxes, etc.)
    if (is_array($value)) {
        // Object-like fields with a 'url' key
        if (in_array($type, array('image', 'file', 'link'), true)) {
            return empty($value['url']);
        }
        // Google Map checks 'address'
        if ($type === 'google_map') {
            return empty($value['address']);
        }
        return empty($value);
    }

    // Password fields are never rendered — treat as empty
    if ($type === 'password') {
        return true;
    }

    return false;
}

/**
 * Get the current privacy state for a specific field.
 *
 * Returns whether the field has a per-field override active and what
 * the effective privacy value is (inherited or overridden).
 *
 * @param string $field_name The ACF field name
 * @param int    $post_id    The post ID
 * @param string $section    The section key
 * @return array ['has_override' => bool, 'value' => string, 'inherited_from' => string]
 */
function memdir_get_field_privacy_state($field_name, $post_id, $section)
{
    $override_enabled = get_post_meta($post_id, "memdir_pmp_override_{$field_name}", true);
    $override_value = get_post_meta($post_id, "memdir_pmp_value_{$field_name}", true);

    if ($override_enabled && $override_value) {
        return array(
            'has_override' => true,
            'value' => sanitize_key($override_value),
            'inherited_from' => 'field',
        );
    }

    // Fall back to section / global
    $effective = Memdir_PMP_Visibility::get_effective_pmp($post_id, $section);
    $pmp = memdir_get_section_pmp_fields($section);
    $section_mode = get_field($pmp['mode'], $post_id);

    return array(
        'has_override' => false,
        'value' => $effective,
        'inherited_from' => ($section_mode === 'override') ? 'section' : 'global',
    );
}

/**
 * Render an inline privacy badge for a field (edit mode only).
 *
 * Outputs a small clickable badge showing the current privacy level.
 * The badge opens a popover with options to override or inherit.
 *
 * @param string $field_name  The ACF field name
 * @param int    $post_id     The post ID
 * @param string $section     The section key
 */
function memdir_render_field_privacy_badge($field_name, $post_id, $section)
{
    $state = memdir_get_field_privacy_state($field_name, $post_id, $section);

    $icons = array(
        'public' => '🌍',
        'members' => '👥',
        'private' => '🔒',
    );

    $labels = array(
        'public' => 'Public',
        'members' => 'Members',
        'private' => 'Private',
    );

    $icon = $icons[$state['value']] ?? '👓';
    $label = $labels[$state['value']] ?? 'Members';
    $source_label = $state['has_override'] ? 'Field override' : ucfirst($state['inherited_from']) . ' default';

    $badge_class = 'memdir-field-privacy-badge';
    if ($state['has_override']) {
        $badge_class .= ' memdir-field-privacy-badge--override';
    }

    echo '<button type="button" class="' . esc_attr($badge_class) . '"'
        . ' data-field="' . esc_attr($field_name) . '"'
        . ' data-section="' . esc_attr($section) . '"'
        . ' data-privacy-state="' . esc_attr($state['value']) . '"'
        . ' data-has-override="' . ($state['has_override'] ? '1' : '0') . '"'
        . ' title="' . esc_attr($label . ' — ' . $source_label) . '">'
        . '<span class="memdir-field-privacy-badge__icon">' . $icon . '</span>'
        . '</button>';
}

/**
 * Render a taxonomy tag wrapped with vouch affordances.
 *
 * Adds a vouch badge (✓) when the term meets the threshold,
 * and a vouch button for logged-in members viewing other profiles.
 * Called by the field renderer taxonomy case and business section template.
 *
 * @param string      $tag_html    The inner tag HTML (already escaped)
 * @param int         $term_id     The taxonomy term ID
 * @param int|null    $post_id     The member-directory post ID
 * @param string|null $viewer_mode Current viewer mode
 */
function memdir_render_vouch_tag($tag_html, $term_id, $post_id = null, $viewer_mode = null)
{
    // If endorsements system isn't available, just output the tag
    if (!class_exists('Memdir_Endorsements') || !$post_id || !$term_id) {
        echo $tag_html;
        return;
    }

    $current_user = get_current_user_id();
    $post_author = (int) get_post_field('post_author', $post_id);
    $is_own = ($current_user === $post_author);
    $can_vouch = (is_user_logged_in() && !$is_own && $viewer_mode !== 'edit');

    // Batch-fetch vouch data (cached per-request after first call)
    $vouch_data = Memdir_Endorsements::get_skill_vouch_data($post_id, $current_user ?: null);
    $term_info = isset($vouch_data[$term_id]) ? $vouch_data[$term_id] : null;
    $count = $term_info ? $term_info['count'] : 0;
    $viewer_vouched = $term_info ? $term_info['viewer_vouched'] : false;
    $meets_threshold = $count >= Memdir_Endorsements::VOUCH_THRESHOLD;

    // Wrap tag with vouch container
    echo '<span class="memdir-tag-vouch-wrap" data-term-id="' . esc_attr($term_id) . '" data-post-id="' . esc_attr($post_id) . '">';
    echo $tag_html;

    // Vouch badge — only shows when threshold met
    if ($meets_threshold) {
        echo '<span class="memdir-vouch-badge" title="Vouched by community members">✓</span>';
    }

    // Vouch button — only for logged-in members on other profiles
    if ($can_vouch) {
        $btn_class = 'memdir-vouch-btn' . ($viewer_vouched ? ' memdir-vouch-btn--active' : '');
        $btn_text = $viewer_vouched ? '✓ vouched' : 'vouch';
        $btn_title = $viewer_vouched ? 'Remove your vouch' : 'Vouch for this skill';
        echo '<button type="button" class="' . esc_attr($btn_class) . '" title="' . esc_attr($btn_title) . '">' . $btn_text . '</button>';
    }

    echo '</span>';
}

/**
 * Render a single ACF field in display mode.
 *
 * Modern display-mode renderer: value-first design with subtle captions,
 * semantic HTML classes for each field type, and data-attributes for
 * field-specific styling.
 *
 * @param array       $field        ACF field definition (from acf_get_fields)
 * @param mixed       $value        The field's current value
 * @param int|null    $post_id      Optional. Post ID for privacy badge rendering
 * @param string|null $section      Optional. Section key for privacy badge rendering
 * @param string|null $viewer_mode  Optional. Viewer mode ('public', 'member', 'edit')
 */
function memdir_render_field($field, $value, $post_id = null, $section = null, $viewer_mode = null)
{
    $type = $field['type'];
    $label = $field['label'];
    $field_name = esc_attr($field['name']);
    $is_edit = ($viewer_mode === 'edit' && $post_id && $section);

    // In edit mode, wrap the field in a container with a privacy badge
    if ($is_edit) {
        echo '<div class="memdir-field-privacy-wrap">';
        memdir_render_field_privacy_badge($field['name'], $post_id, $section);
    }

    switch ($type) {

        case 'text':
        case 'email':
            echo '<div class="memdir-field memdir-field--text" data-field-name="' . $field_name . '">';
            echo '<div class="memdir-field-value">' . esc_html($value) . '</div>';
            echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
            echo '</div>';
            break;

        case 'textarea':
            echo '<div class="memdir-field memdir-field--prose" data-field-name="' . $field_name . '">';
            echo '<h3 class="memdir-field-heading">' . esc_html($label) . '</h3>';
            echo '<div class="memdir-prose">' . nl2br(esc_html($value)) . '</div>';
            echo '</div>';
            break;

        case 'image':
            if (is_array($value) && !empty($value['url'])) {
                $src = esc_url($value['sizes']['medium_large'] ?? $value['sizes']['medium'] ?? $value['url']);
                $alt = esc_attr($value['alt'] ?? $label);
                echo '<div class="memdir-field memdir-field--image" data-field-name="' . $field_name . '">';
                echo '<img src="' . $src . '" alt="' . $alt . '" class="memdir-field-image" loading="lazy">';
                echo '</div>';
            }
            break;

        case 'gallery':
            if (is_array($value) && !empty($value)) {
                echo '<div class="memdir-field memdir-field--gallery" data-field-name="' . $field_name . '">';
                echo '<h3 class="memdir-field-heading">' . esc_html($label) . '</h3>';
                echo '<div class="memdir-gallery-grid">';
                foreach ($value as $image) {
                    if (!is_array($image) || empty($image['url'])) {
                        continue;
                    }
                    $thumb = esc_url($image['sizes']['medium_large'] ?? $image['sizes']['medium'] ?? $image['url']);
                    $full = esc_url($image['url']);
                    $alt = esc_attr($image['alt'] ?? $image['title'] ?? '');
                    echo '<a href="' . $full . '" class="memdir-gallery-item" data-lightbox="gallery-' . $field_name . '">';
                    echo '<img src="' . $thumb . '" alt="' . $alt . '" loading="lazy">';
                    echo '</a>';
                }
                echo '</div>';
                echo '</div>';
            }
            break;

        case 'url':
            // Check if this is a video URL (YouTube/Vimeo) — auto-embed
            if (memdir_is_video_url($value)) {
                $embed = wp_oembed_get($value, array('width' => 720));
                if ($embed) {
                    echo '<div class="memdir-field memdir-field--video" data-field-name="' . $field_name . '">';
                    echo '<div class="memdir-video-embed">' . $embed . '</div>';
                    echo '</div>';
                    break;
                }
            }
            // Standard URL (not video)
            echo '<div class="memdir-field memdir-field--link" data-field-name="' . $field_name . '">';
            echo '<a href="' . esc_url($value) . '" target="_blank" rel="noopener noreferrer" class="memdir-link">';
            echo '<span class="memdir-link-icon">🔗</span> ';
            echo '<span class="memdir-link-text">' . esc_html($value) . '</span>';
            echo '</a>';
            echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
            echo '</div>';
            break;

        case 'number':
            $append = !empty($field['append']) ? ' ' . esc_html($field['append']) : '';
            $prepend = !empty($field['prepend']) ? esc_html($field['prepend']) . ' ' : '';
            echo '<div class="memdir-field memdir-stat-card" data-field-name="' . $field_name . '">';
            echo '<span class="memdir-stat-number">' . esc_html($prepend . $value) . '</span>';
            echo '<span class="memdir-stat-unit">' . esc_html(trim($append)) . '</span>';
            echo '<span class="memdir-stat-caption">' . esc_html($label) . '</span>';
            echo '</div>';
            break;

        case 'select':
        case 'radio':
            if (is_array($value)) {
                echo '<div class="memdir-field memdir-field--tags" data-field-name="' . $field_name . '">';
                echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                echo '<div class="memdir-tags">';
                foreach ($value as $item) {
                    $display = isset($field['choices'][$item]) ? $field['choices'][$item] : $item;
                    echo '<span class="memdir-tag memdir-tag-neutral">' . esc_html($display) . '</span>';
                }
                echo '</div>';
                echo '</div>';
            } else {
                $display_value = isset($field['choices'][$value]) ? $field['choices'][$value] : $value;
                echo '<div class="memdir-field memdir-field--badge" data-field-name="' . $field_name . '">';
                echo '<span class="memdir-chip">' . esc_html($display_value) . '</span>';
                echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                echo '</div>';
            }
            break;

        case 'checkbox':
            if (is_array($value) && !empty($value)) {
                echo '<div class="memdir-field memdir-field--tags" data-field-name="' . $field_name . '">';
                echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                echo '<div class="memdir-tags">';
                foreach ($value as $item) {
                    $display = isset($field['choices'][$item]) ? $field['choices'][$item] : $item;
                    echo '<span class="memdir-tag memdir-tag-neutral">' . esc_html($display) . '</span>';
                }
                echo '</div>';
                echo '</div>';
            }
            break;

        case 'taxonomy':
            if (!empty($value)) {
                $terms = is_array($value) ? $value : array($value);
                $taxonomy_slug = isset($field['taxonomy']) ? $field['taxonomy'] : '';
                $tax_class = $taxonomy_slug ? 'memdir-tag-' . str_replace('memdir_', '', $taxonomy_slug) : '';
                $archive_url = get_post_type_archive_link('member-directory');
                echo '<div class="memdir-field memdir-field--taxonomy" data-field-name="' . $field_name . '">';
                echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                echo '<div class="memdir-tags">';
                foreach ($terms as $term) {
                    $term_name = '';
                    $term_id = 0;
                    if (is_object($term)) {
                        $term_name = $term->name;
                        $term_id = $term->term_id;
                    } elseif (is_numeric($term)) {
                        $t = get_term($term);
                        if ($t && !is_wp_error($t)) {
                            $term_name = $t->name;
                            $term_id = $t->term_id;
                        }
                    } else {
                        $term_name = $term;
                    }
                    if ($term_name) {
                        if ($taxonomy_slug && $term_id && $archive_url) {
                            $filter_url = add_query_arg($taxonomy_slug . '[]', $term_id, $archive_url);
                            $tag_html = '<a href="' . esc_url($filter_url) . '" class="memdir-tag memdir-tag--link ' . esc_attr($tax_class) . '">' . esc_html($term_name) . '</a>';
                        } else {
                            $tag_html = '<span class="memdir-tag ' . esc_attr($tax_class) . '">' . esc_html($term_name) . '</span>';
                        }
                        // Vouch affordances — only for Services Offered
                        if ($taxonomy_slug === 'memdir_services') {
                            memdir_render_vouch_tag($tag_html, $term_id, $post_id, $viewer_mode);
                        } else {
                            echo $tag_html;
                        }
                    }
                }
                echo '</div>';
                echo '</div>';
            }
            break;

        case 'google_map':
            if (is_array($value) && !empty($value['address'])) {
                echo '<div class="memdir-field memdir-field--location" data-field-name="' . $field_name . '">';
                echo '<span class="memdir-location-icon">📍</span>';
                echo '<span class="memdir-field-value">' . esc_html($value['address']) . '</span>';
                echo '</div>';
            }
            break;

        case 'true_false':
            if ($value) {
                echo '<div class="memdir-field memdir-field--check" data-field-name="' . $field_name . '">';
                echo '<span class="memdir-badge">✓ ' . esc_html($label) . '</span>';
                echo '</div>';
            }
            break;

        case 'wysiwyg':
            echo '<div class="memdir-field memdir-field--prose" data-field-name="' . $field_name . '">';
            echo '<h3 class="memdir-field-heading">' . esc_html($label) . '</h3>';
            echo '<div class="memdir-prose memdir-rich-text">' . wp_kses_post($value) . '</div>';
            echo '</div>';
            break;

        // ── File Upload ──────────────────────────────────────────
        case 'file':
            if (is_array($value) && !empty($value['url'])) {
                $filename = esc_html($value['filename'] ?? basename($value['url']));
                $filesize = '';
                if (!empty($value['filesize'])) {
                    $filesize = size_format($value['filesize']);
                }
                $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                $icon_map = array(
                    'pdf' => '📄',
                    'doc' => '📝',
                    'docx' => '📝',
                    'mp3' => '🎵',
                    'wav' => '🎵',
                    'ogg' => '🎵',
                    'flac' => '🎵',
                    'aac' => '🎵',
                    'm4a' => '🎵',
                    'mp4' => '🎬',
                    'mov' => '🎬',
                    'avi' => '🎬',
                    'webm' => '🎬',
                    'zip' => '📦',
                    'rar' => '📦',
                    'gz' => '📦',
                );
                $icon = isset($icon_map[$ext]) ? $icon_map[$ext] : '📎';

                // Audio files get an inline player
                $audio_exts = array('mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a');
                if (in_array($ext, $audio_exts, true)) {
                    echo '<div class="memdir-field memdir-field--audio" data-field-name="' . $field_name . '">';
                    echo '<h3 class="memdir-field-heading">' . esc_html($label) . '</h3>';
                    echo '<audio controls preload="metadata" class="memdir-audio-player">';
                    echo '<source src="' . esc_url($value['url']) . '" type="' . esc_attr($value['mime_type'] ?? 'audio/mpeg') . '">';
                    echo '</audio>';
                    echo '</div>';
                } else {
                    echo '<div class="memdir-field memdir-field--file" data-field-name="' . $field_name . '">';
                    echo '<a href="' . esc_url($value['url']) . '" class="memdir-file-card" target="_blank" rel="noopener noreferrer">';
                    echo '<span class="memdir-file-icon">' . $icon . '</span>';
                    echo '<span class="memdir-file-info">';
                    echo '<span class="memdir-file-name">' . $filename . '</span>';
                    if ($filesize) {
                        echo '<span class="memdir-file-size">' . esc_html($filesize) . '</span>';
                    }
                    echo '</span>';
                    echo '<span class="memdir-file-download">↓</span>';
                    echo '</a>';
                    echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                    echo '</div>';
                }
            }
            break;

        // ── oEmbed ───────────────────────────────────────────────
        case 'oembed':
            if (!empty($value)) {
                // $value is the raw URL string from ACF
                $embed_html = wp_oembed_get($value, array('width' => 720));
                if ($embed_html) {
                    echo '<div class="memdir-field memdir-field--embed" data-field-name="' . $field_name . '">';
                    echo '<div class="memdir-embed-wrapper">' . $embed_html . '</div>';
                    echo '</div>';
                } else {
                    // Fallback: render as external link
                    echo '<div class="memdir-field memdir-field--link" data-field-name="' . $field_name . '">';
                    echo '<a href="' . esc_url($value) . '" target="_blank" rel="noopener noreferrer" class="memdir-link">';
                    echo '<span class="memdir-link-icon">🔗</span> ';
                    echo '<span class="memdir-link-text">' . esc_html($value) . '</span>';
                    echo '</a>';
                    echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                    echo '</div>';
                }
            }
            break;

        // ── Link (ACF Link field — returns array with url, title, target) ──
        case 'link':
            if (is_array($value) && !empty($value['url'])) {
                $link_title = !empty($value['title']) ? $value['title'] : $value['url'];
                $link_target = !empty($value['target']) ? $value['target'] : '_self';
                $rel = ($link_target === '_blank') ? ' rel="noopener noreferrer"' : '';
                echo '<div class="memdir-field memdir-field--link" data-field-name="' . $field_name . '">';
                echo '<a href="' . esc_url($value['url']) . '" target="' . esc_attr($link_target) . '"' . $rel . ' class="memdir-link">';
                echo '<span class="memdir-link-icon">🔗</span> ';
                echo '<span class="memdir-link-text">' . esc_html($link_title) . '</span>';
                echo '</a>';
                echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                echo '</div>';
            }
            break;

        // ── Post Object (single or multi) ────────────────────────
        case 'post_object':
            if (!empty($value)) {
                $posts = is_array($value) && !isset($value['ID']) ? $value : array($value);
                echo '<div class="memdir-field memdir-field--related" data-field-name="' . $field_name . '">';
                echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                echo '<ul class="memdir-related-list">';
                foreach ($posts as $post_item) {
                    if (is_object($post_item) && !empty($post_item->ID)) {
                        $permalink = get_permalink($post_item->ID);
                        echo '<li><a href="' . esc_url($permalink) . '" class="memdir-related-link">';
                        echo esc_html(get_the_title($post_item->ID));
                        echo '</a></li>';
                    } elseif (is_numeric($post_item)) {
                        $permalink = get_permalink($post_item);
                        echo '<li><a href="' . esc_url($permalink) . '" class="memdir-related-link">';
                        echo esc_html(get_the_title($post_item));
                        echo '</a></li>';
                    }
                }
                echo '</ul>';
                echo '</div>';
            }
            break;

        // ── Relationship (always multi) ──────────────────────────
        case 'relationship':
            if (is_array($value) && !empty($value)) {
                echo '<div class="memdir-field memdir-field--related" data-field-name="' . $field_name . '">';
                echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                echo '<ul class="memdir-related-list">';
                foreach ($value as $post_item) {
                    $pid = is_object($post_item) ? $post_item->ID : intval($post_item);
                    if ($pid) {
                        $permalink = get_permalink($pid);
                        echo '<li><a href="' . esc_url($permalink) . '" class="memdir-related-link">';
                        echo esc_html(get_the_title($pid));
                        echo '</a></li>';
                    }
                }
                echo '</ul>';
                echo '</div>';
            }
            break;

        // ── User (links to their member-directory profile) ───────
        case 'user':
            if (!empty($value)) {
                $users = is_array($value) && !isset($value['ID']) ? $value : array($value);
                echo '<div class="memdir-field memdir-field--users" data-field-name="' . $field_name . '">';
                echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                echo '<div class="memdir-user-list">';
                foreach ($users as $user_item) {
                    $user_id = 0;
                    if (is_object($user_item) && !empty($user_item->ID)) {
                        $user_id = $user_item->ID;
                    } elseif (is_array($user_item) && !empty($user_item['ID'])) {
                        $user_id = $user_item['ID'];
                    } elseif (is_numeric($user_item)) {
                        $user_id = intval($user_item);
                    }
                    if (!$user_id)
                        continue;

                    $display_name = get_the_author_meta('display_name', $user_id);
                    $avatar = get_avatar_url($user_id, array('size' => 48));

                    // Try to find their member-directory post (uses static cache)
                    $member_post = memdir_get_user_post($user_id);
                    $profile_url = $member_post ? get_permalink($member_post->ID) : '';

                    echo '<div class="memdir-user-card">';
                    if ($avatar) {
                        echo '<img src="' . esc_url($avatar) . '" alt="" class="memdir-user-avatar" loading="lazy">';
                    }
                    if ($profile_url) {
                        echo '<a href="' . esc_url($profile_url) . '" class="memdir-user-name">' . esc_html($display_name) . '</a>';
                    } else {
                        echo '<span class="memdir-user-name">' . esc_html($display_name) . '</span>';
                    }
                    echo '</div>';
                }
                echo '</div>';
                echo '</div>';
            }
            break;

        // ── Date Pickers ─────────────────────────────────────────
        case 'date_picker':
            if (!empty($value)) {
                // ACF stores as Ymd (e.g. 20260208), format nicely
                $timestamp = strtotime($value);
                $formatted = $timestamp ? date_i18n(get_option('date_format', 'F j, Y'), $timestamp) : esc_html($value);
                echo '<div class="memdir-field memdir-field--date" data-field-name="' . $field_name . '">';
                echo '<span class="memdir-date-icon">📅</span>';
                echo '<span class="memdir-field-value">' . esc_html($formatted) . '</span>';
                echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                echo '</div>';
            }
            break;

        case 'date_time_picker':
            if (!empty($value)) {
                $timestamp = strtotime($value);
                $date_fmt = get_option('date_format', 'F j, Y');
                $time_fmt = get_option('time_format', 'g:i a');
                $formatted = $timestamp ? date_i18n($date_fmt . ' ' . $time_fmt, $timestamp) : esc_html($value);
                echo '<div class="memdir-field memdir-field--date" data-field-name="' . $field_name . '">';
                echo '<span class="memdir-date-icon">📅</span>';
                echo '<span class="memdir-field-value">' . esc_html($formatted) . '</span>';
                echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                echo '</div>';
            }
            break;

        case 'time_picker':
            if (!empty($value)) {
                $timestamp = strtotime($value);
                $time_fmt = get_option('time_format', 'g:i a');
                $formatted = $timestamp ? date_i18n($time_fmt, $timestamp) : esc_html($value);
                echo '<div class="memdir-field memdir-field--date" data-field-name="' . $field_name . '">';
                echo '<span class="memdir-date-icon">🕐</span>';
                echo '<span class="memdir-field-value">' . esc_html($formatted) . '</span>';
                echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                echo '</div>';
            }
            break;

        // ── Color Picker ─────────────────────────────────────────
        case 'color_picker':
            if (!empty($value)) {
                echo '<div class="memdir-field memdir-field--color" data-field-name="' . $field_name . '">';
                echo '<span class="memdir-color-swatch" style="background-color:' . esc_attr($value) . '"></span>';
                echo '<span class="memdir-field-value">' . esc_html($value) . '</span>';
                echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
                echo '</div>';
            }
            break;

        // ── Range (slider) ───────────────────────────────────────
        case 'range':
            $min = isset($field['min']) ? floatval($field['min']) : 0;
            $max = isset($field['max']) ? floatval($field['max']) : 100;
            $pct = ($max > $min) ? (($value - $min) / ($max - $min)) * 100 : 0;
            $append = !empty($field['append']) ? ' ' . esc_html($field['append']) : '';
            $prepend = !empty($field['prepend']) ? esc_html($field['prepend']) : '';
            echo '<div class="memdir-field memdir-field--range" data-field-name="' . $field_name . '">';
            echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
            echo '<div class="memdir-range-bar">';
            echo '<div class="memdir-range-fill" style="width:' . esc_attr(round($pct, 1)) . '%"></div>';
            echo '</div>';
            echo '<div class="memdir-range-value">' . esc_html($prepend . $value . $append) . '</div>';
            echo '</div>';
            break;

        // ── Button Group (same as single select) ─────────────────
        case 'button_group':
            $display_value = isset($field['choices'][$value]) ? $field['choices'][$value] : $value;
            echo '<div class="memdir-field memdir-field--badge" data-field-name="' . $field_name . '">';
            echo '<span class="memdir-chip">' . esc_html($display_value) . '</span>';
            echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
            echo '</div>';
            break;

        // ── Repeater ─────────────────────────────────────────────
        case 'repeater':
            if (is_array($value) && !empty($value)) {
                $sub_fields = isset($field['sub_fields']) ? $field['sub_fields'] : array();
                echo '<div class="memdir-field memdir-field--repeater" data-field-name="' . $field_name . '">';
                echo '<h3 class="memdir-field-heading">' . esc_html($label) . '</h3>';
                foreach ($value as $row_index => $row) {
                    echo '<div class="memdir-repeater-row">';
                    if (is_array($row)) {
                        foreach ($row as $sub_key => $sub_value) {
                            // Find the sub-field definition
                            $sub_field = null;
                            foreach ($sub_fields as $sf) {
                                if ($sf['name'] === $sub_key || $sf['key'] === $sub_key) {
                                    $sub_field = $sf;
                                    break;
                                }
                            }
                            if ($sub_field && !memdir_is_field_empty($sub_value, $sub_field['type'])) {
                                memdir_render_field($sub_field, $sub_value);
                            }
                        }
                    }
                    echo '</div>';
                }
                echo '</div>';
            }
            break;

        // ── Group ────────────────────────────────────────────────
        case 'group':
            if (is_array($value) && !empty($value)) {
                $sub_fields = isset($field['sub_fields']) ? $field['sub_fields'] : array();
                echo '<div class="memdir-field memdir-field--group" data-field-name="' . $field_name . '">';
                echo '<h3 class="memdir-field-heading">' . esc_html($label) . '</h3>';
                foreach ($sub_fields as $sub_field) {
                    $sub_key = $sub_field['name'];
                    $sub_value = isset($value[$sub_key]) ? $value[$sub_key] : null;
                    if ($sub_value !== null && !memdir_is_field_empty($sub_value, $sub_field['type'])) {
                        memdir_render_field($sub_field, $sub_value);
                    }
                }
                echo '</div>';
            }
            break;

        // ── Password (never display) ─────────────────────────────
        case 'password':
            break;

        // ── Fallback ─────────────────────────────────────────────
        default:
            $display = $value;
            if (is_array($value)) {
                // Only display flat arrays of scalars — skip nested objects/arrays
                $flat = array_filter($value, 'is_scalar');
                if (empty($flat)) {
                    break;
                }
                $display = implode(', ', $flat);
            }
            echo '<div class="memdir-field memdir-field--default" data-field-name="' . $field_name . '">';
            echo '<div class="memdir-field-value">' . esc_html($display) . '</div>';
            echo '<div class="memdir-field-caption">' . esc_html($label) . '</div>';
            echo '</div>';
            break;
    }

    // Close the privacy wrapper
    if ($is_edit) {
        echo '</div>'; // .memdir-field-privacy-wrap
    }
}

/**
 * Check if a URL is a video embed URL (YouTube or Vimeo).
 *
 * @param string $url The URL to check
 * @return bool True if this is a recognized video URL
 */
function memdir_is_video_url($url)
{
    $video_hosts = array(
        'youtube.com',
        'youtu.be',
        'www.youtube.com',
        'vimeo.com',
        'www.vimeo.com',
    );
    $host = wp_parse_url($url, PHP_URL_HOST);
    return $host && in_array(strtolower($host), $video_hosts, true);
}

/**
 * Render availability badge HTML.
 *
 * Used by both header-profile.php and member-card.php.
 *
 * @param int    $post_id  The member post ID
 * @param string $context  'header' for full badge, 'card' for compact
 * @return string HTML or empty string if not set
 */
function memdir_render_availability_badge($post_id, $context = 'header')
{
    $availability = get_field(memdir_field('member_availability'), $post_id);
    if (empty($availability)) {
        return '';
    }

    $labels = array(
        'available' => 'Taking New Clients',
        'waitlist' => 'Waitlist Open',
        'booked' => 'Currently Booked',
        'referral' => 'By Referral Only',
        'unavailable' => 'Not Currently Available',
    );

    $label = isset($labels[$availability]) ? $labels[$availability] : '';
    if (empty($label)) {
        return '';
    }

    $class = 'memdir-availability memdir-availability--' . esc_attr($availability);
    if ($context === 'card') {
        $class .= ' memdir-availability--compact';
    }

    return '<span class="' . $class . '">' . esc_html($label) . '</span>';
}
