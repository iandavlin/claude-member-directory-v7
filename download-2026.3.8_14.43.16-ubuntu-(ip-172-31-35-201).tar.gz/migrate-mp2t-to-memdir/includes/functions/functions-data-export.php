<?php
/**
 * Data Export Functions
 *
 * Exports all member directory data as clean JSON for portability.
 * Reads ACF field groups dynamically — any field added in ACF
 * is automatically included in exports.
 *
 * Usage:
 *  - Admin page: Tools → Member Export
 *  - WP-CLI:    wp memdir export > members.json (future)
 *  - REST API:  GET /wp-json/memdir/v1/export (admin auth required)
 *
 * @since 3.1.0
 */

if (!defined('ABSPATH'))
    exit;

/**
 * Register the REST API export endpoint.
 */
function memdir_register_export_endpoint()
{
    register_rest_route('memdir/v1', '/export', array(
        'methods' => 'GET',
        'callback' => 'memdir_rest_export_members',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
    ));
}
add_action('rest_api_init', 'memdir_register_export_endpoint');

/**
 * REST API callback: export all members as JSON.
 *
 * @return WP_REST_Response
 */
function memdir_rest_export_members()
{
    $data = memdir_export_all_members();

    return new WP_REST_Response(array(
        'exported_at' => current_time('c'),
        'member_count' => count($data),
        'members' => $data,
    ), 200);
}

/**
 * Export all member directory data.
 *
 * @return array Array of member data objects
 */
function memdir_export_all_members()
{
    $posts = get_posts(array(
        'post_type' => 'member-directory',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
    ));

    $members = array();

    if (!empty($posts)) {
        // Batch prefetch all post meta + user meta before the per-member loop.
        // Without this, each export_single_member() triggers ~30 get_field + ~5
        // get_user_meta calls, all hitting the DB individually.
        $post_ids = wp_list_pluck($posts, 'ID');
        update_postmeta_cache($post_ids);

        $author_ids = array_unique(wp_list_pluck($posts, 'post_author'));
        update_meta_cache('user', $author_ids);
    }

    foreach ($posts as $post) {
        $members[] = memdir_export_single_member($post->ID);
    }

    return $members;
}

/**
 * Export a single member's data.
 *
 * Reads all ACF field groups dynamically, plus user meta
 * and taxonomy terms.
 *
 * @param int $post_id The member directory post ID
 * @return array Member data
 */
function memdir_export_single_member($post_id)
{
    $post = get_post($post_id);
    $user_id = $post->post_author;
    $user = get_user_by('id', $user_id);

    $member = array(
        'meta' => array(
            'post_id' => $post_id,
            'user_id' => $user_id,
            'username' => $user ? $user->user_login : '',
            'email' => $user ? $user->user_email : '',
            'post_slug' => $post->post_name,
            'status' => $post->post_status,
            'created' => $post->post_date,
            'modified' => $post->post_modified,
        ),
    );

    // Export each section's ACF fields dynamically
    $section_map = memdir_get_section_group_map();

    foreach ($section_map as $section_key => $group_key) {
        $member[$section_key] = memdir_export_section_fields($post_id, $group_key);
    }

    // Export system fields (group_01) dynamically
    $member['system'] = memdir_export_section_fields($post_id, 'group_01_system');

    // Export social links (user meta)
    $social = array();
    foreach (memdir_get_social_platforms() as $key => $platform) {
        $val = get_user_meta($user_id, $platform['meta_key'], true);
        if (!empty($val)) {
            $social[$key] = $val;
        }
    }
    $member['social_links'] = $social;

    // Export portfolio images
    $portfolio_ids = get_post_meta($post_id, memdir_field('portfolio_images'), true);
    if (!empty($portfolio_ids) && is_array($portfolio_ids)) {
        $member['portfolio_images'] = array_map(function ($id) {
            return wp_get_attachment_url($id) ?: null;
        }, $portfolio_ids);
        $member['portfolio_images'] = array_filter($member['portfolio_images']);
    }

    // Export profile views count
    $member['profile_views'] = intval(get_post_meta($post_id, memdir_field('profile_views'), true));

    return $member;
}

/**
 * Export all fields in an ACF group for a post.
 *
 * @param int    $post_id    The post ID
 * @param string $group_key  The ACF group key
 * @return array Field name => value pairs
 */
function memdir_export_section_fields($post_id, $group_key)
{
    if (!function_exists('acf_get_fields')) {
        return array();
    }

    $fields = acf_get_fields($group_key);
    if (!$fields) {
        return array();
    }

    $data = array();

    foreach ($fields as $field) {
        // Skip PMP control fields
        if (strpos($field['name'], '_pmp_') !== false) {
            continue;
        }

        $value = get_field($field['name'], $post_id);

        // Normalize values for clean export
        $data[$field['name']] = memdir_normalize_export_value($value, $field);
    }

    return $data;
}

/**
 * Normalize a field value for JSON export.
 *
 * Converts ACF objects (images, terms) into portable data.
 *
 * @param mixed $value  The raw ACF value
 * @param array $field  The ACF field definition
 * @return mixed Normalized value
 */
function memdir_normalize_export_value($value, $field)
{
    if (empty($value)) {
        return null;
    }

    switch ($field['type']) {
        case 'image':
            if (is_array($value)) {
                return array(
                    'url' => $value['url'] ?? null,
                    'alt' => $value['alt'] ?? '',
                    'width' => $value['width'] ?? null,
                    'height' => $value['height'] ?? null,
                );
            }
            return null;

        case 'taxonomy':
            $terms = is_array($value) ? $value : array($value);
            $result = array();
            foreach ($terms as $term) {
                if (is_object($term)) {
                    $result[] = array('id' => $term->term_id, 'name' => $term->name, 'slug' => $term->slug);
                } elseif (is_numeric($term)) {
                    $t = get_term($term);
                    if ($t && !is_wp_error($t)) {
                        $result[] = array('id' => $t->term_id, 'name' => $t->name, 'slug' => $t->slug);
                    }
                }
            }
            return $result;

        case 'google_map':
            if (is_array($value)) {
                return array(
                    'address' => $value['address'] ?? '',
                    'lat' => $value['lat'] ?? null,
                    'lng' => $value['lng'] ?? null,
                    'city' => $value['city'] ?? '',
                    'state' => $value['state'] ?? '',
                    'country' => $value['country'] ?? '',
                );
            }
            return null;

        case 'true_false':
            return (bool) $value;

        case 'number':
            return is_numeric($value) ? floatval($value) : null;

        default:
            return $value;
    }
}

/**
 * Add export page to WordPress admin Tools menu.
 */
function memdir_add_export_menu()
{
    add_management_page(
        'Member Directory Export',
        'Member Export',
        'manage_options',
        'memdir-export',
        'memdir_render_export_page'
    );
}
add_action('admin_menu', 'memdir_add_export_menu');

/**
 * Handle export download on admin_init — before any output is sent.
 *
 * This runs early in the admin lifecycle (before headers/HTML), which is
 * the correct WordPress pattern for file downloads. Previously this logic
 * lived inside the render callback, relying on PHP output buffering.
 *
 * @since 3.1.1 — moved from memdir_render_export_page() (H4 fix)
 */
function memdir_handle_export_download()
{
    if (
        !isset($_GET['memdir_download_export']) ||
        !isset($_GET['page']) ||
        $_GET['page'] !== 'memdir-export'
    ) {
        return;
    }

    // Capability check (belt-and-suspenders with the menu capability)
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized', 403);
    }

    if (!wp_verify_nonce($_GET['_wpnonce'] ?? '', 'memdir_export_nonce')) {
        wp_die('Invalid or expired nonce. Please go back and try again.', 403);
    }

    $data = memdir_export_all_members();
    $export = array(
        'exported_at' => current_time('c'),
        'plugin' => 'memdir-member-directory',
        'version' => MEMDIR_VERSION,
        'site_url' => home_url(),
        'member_count' => count($data),
        'members' => $data,
    );

    // Use wp_date() to respect the site's configured timezone (M8 fix)
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="memdir-members-export-' . wp_date('Y-m-d') . '.json"');
    echo wp_json_encode($export, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
add_action('admin_init', 'memdir_handle_export_download');

/**
 * Render the admin export page.
 */
function memdir_render_export_page()
{
    // Count members
    $count = wp_count_posts('member-directory');
    $published = $count->publish ?? 0;

    ?>
    <div class="wrap">
        <h1>Member Directory — Export</h1>
        <p>Download all member directory data as a JSON file. This includes all profile fields,
            social links, taxonomy terms, and portfolio images.</p>

        <div class="card" style="max-width: 600px; padding: 20px;">
            <h2 style="margin-top: 0;">Export Summary</h2>
            <p><strong>
                    <?php echo intval($published); ?>
                </strong> published member profiles will be exported.</p>
            <p>The export reads all ACF field groups dynamically — any field added through ACF
                is automatically included.</p>
            <p>
                <a href="<?php echo esc_url(wp_nonce_url(
                    admin_url('tools.php?page=memdir-export&memdir_download_export=1'),
                    'memdir_export_nonce'
                )); ?>" class="button button-primary button-large">
                    ⬇ Download JSON Export
                </a>
            </p>
        </div>

        <div class="card" style="max-width: 600px; padding: 20px; margin-top: 15px;">
            <h2 style="margin-top: 0;">REST API</h2>
            <p>You can also access the export programmatically:</p>
            <code style="display: block; padding: 10px; background: #f0f0f0; border-radius: 4px;">
                                            GET <?php echo esc_html(rest_url('memdir/v1/export')); ?>
                                        </code>
            <p><small>Requires administrator authentication.</small></p>
        </div>
    </div>
    <?php
}
