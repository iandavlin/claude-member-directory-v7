<?php
/**
 * Field Map — Central Source of Truth (v2)
 *
 * Defines memdir_field() shorthand aliases and section PMP field mappings.
 * Every field reference in the plugin resolves through this file.
 *
 * All field names now use the `member_directory_` prefix (v2).
 * Legacy `memdir_` aliases are preserved for backward compatibility.
 *
 * Naming convention: member_directory_{section}_{field}
 *   - System group uses member_directory_{field} (no section prefix — these are global)
 *   - Privacy fields use member_directory_{section}_privacy_mode / member_directory_{section}_privacy_level
 */

if (!defined('ABSPATH'))
    exit;

/**
 * Resolve a shorthand field key to its full ACF field name.
 *
 * Usage: memdir_field('avatar')  →  'member_directory_profile_avatar'
 *        memdir_field('business_name')  →  'member_directory_business_name'
 *
 * @param string $key Shorthand key.
 * @return string Full ACF field name. Falls back to 'member_directory_' . $key if not mapped.
 */
function memdir_field($key)
{
    static $map = null;

    if ($map === null) {
        $map = array(
            // ── Settings & Identity (Group 01: System) ─────────
            'global_privacy' => 'member_directory_global_privacy',
            'display_name' => 'member_directory_display_name',
            'tagline' => 'member_directory_tagline',
            'availability' => 'member_directory_availability',
            'default_header' => 'member_directory_default_header',

            // Legacy aliases (old code still references these)
            'full_name' => 'member_directory_display_name',
            'member_tagline' => 'member_directory_tagline',
            'member_pmp_default' => 'member_directory_global_privacy',
            'member_availability' => 'member_directory_availability',

            // Section enable toggles
            'enable_craft' => 'member_directory_enable_craft',
            'enable_network' => 'member_directory_enable_network',
            'enable_business' => 'member_directory_enable_business',
            'enable_workshop' => 'member_directory_enable_workshop',
            'enable_experience' => 'member_directory_enable_experience',
            'enable_vibe' => 'member_directory_enable_vibe',

            // ── Profile (Group 02) ─────────────────────────────
            'avatar' => 'member_directory_profile_avatar',
            'cover' => 'member_directory_profile_cover',
            'bio' => 'member_directory_profile_bio',
            'video' => 'member_directory_profile_video',
            'profile_website' => 'member_directory_profile_website',
            'profile_instagram' => 'member_directory_profile_instagram',
            'profile_facebook' => 'member_directory_profile_facebook',
            'profile_youtube' => 'member_directory_profile_youtube',
            'profile_linktree' => 'member_directory_profile_linktree',
            'social_privacy' => 'member_directory_profile_social_privacy',

            // Legacy aliases
            'cover_image' => 'member_directory_profile_cover',

            // ── Craft & Skills (Group 03: Discovery) ───────────
            'craft_instruments' => 'member_directory_craft_instruments',
            'craft_featured_instruments' => 'member_directory_craft_featured_instruments',
            'craft_domains' => 'member_directory_craft_domains',
            'craft_contexts' => 'member_directory_craft_contexts',
            'craft_level' => 'member_directory_craft_level',
            'craft_years' => 'member_directory_craft_years',

            // Legacy aliases
            'instruments' => 'member_directory_craft_instruments',
            'discovery_instruments' => 'member_directory_craft_instruments',
            'experience_level' => 'member_directory_craft_level',

            // ── Network (Group 04: Connect) ────────────────────
            'network_mentorship_status' => 'member_directory_network_mentorship_status',
            'network_mentorship_notes' => 'member_directory_network_mentorship_notes',
            'network_apprenticeship_status' => 'member_directory_network_apprenticeship_status',
            'network_apprenticeship_notes' => 'member_directory_network_apprenticeship_notes',
            'network_employment_status' => 'member_directory_network_employment_status',
            'network_employment_notes' => 'member_directory_network_employment_notes',
            'network_willing_to_relocate' => 'member_directory_network_willing_to_relocate',
            'network_collaboration_notes' => 'member_directory_network_collaboration_notes',

            // ── Business (Group 05) ────────────────────────────
            'business_name' => 'member_directory_business_name',
            'business_logo' => 'member_directory_business_logo',
            'business_hero' => 'member_directory_business_hero',
            'business_description' => 'member_directory_business_description',
            'business_phone' => 'member_directory_business_phone',
            'business_email' => 'member_directory_business_email',
            'business_contact_notes' => 'member_directory_business_contact_notes',
            'business_services' => 'member_directory_business_services',
            'business_featured_services' => 'member_directory_business_featured_services',
            'business_instruments' => 'member_directory_business_instruments',
            'business_warranty' => 'member_directory_business_warranty',
            'business_location' => 'member_directory_business_location',
            'business_location_precision' => 'member_directory_business_location_precision',
            'business_parking' => 'member_directory_business_parking',
            'business_accessibility' => 'member_directory_business_accessibility',
            'business_hours' => 'member_directory_business_hours',
            'business_booking_url' => 'member_directory_business_booking_url',
            'business_languages' => 'member_directory_business_languages',

            // Legacy aliases
            'discovery_services' => 'member_directory_business_services',
            'location' => 'member_directory_business_location',
            'location_specificity' => 'member_directory_business_location_precision',
            'location_precision' => 'member_directory_business_location_precision',

            // ── Workshop (Group 06: Workspace) ─────────────────
            'workshop_description' => 'member_directory_workshop_description',
            'workshop_photos' => 'member_directory_workshop_photos',
            'workshop_equipment' => 'member_directory_workshop_equipment',
            'workshop_accessibility' => 'member_directory_workshop_accessibility',

            // ── Experience (Group 07) ──────────────────────────
            'experience_history' => 'member_directory_experience_history',
            'experience_education' => 'member_directory_experience_education',
            'experience_achievements' => 'member_directory_experience_achievements',
            'experience_portfolio_url' => 'member_directory_experience_portfolio_url',
            'experience_portfolio_gallery' => 'member_directory_experience_portfolio_gallery',
            'experience_resume' => 'member_directory_experience_resume',

            // ── Vibe (Group 08) ────────────────────────────────
            'vibe_overview' => 'member_directory_vibe_overview',
            'vibe_personality' => 'member_directory_vibe_personality',
            'vibe_working_style' => 'member_directory_vibe_working_style',
            'vibe_photos' => 'member_directory_vibe_photos',
            'vibe_playlist' => 'member_directory_vibe_playlist',
            'vibe_sayings' => 'member_directory_vibe_sayings',
            'vibe_workshop_buddies' => 'member_directory_vibe_workshop_buddies',

            // ── Portfolio (standalone post meta) ───────────────
            'portfolio_images' => 'member_directory_portfolio_images',
        );
    }

    return isset($map[$key]) ? $map[$key] : 'member_directory_' . $key;
}

/**
 * Get the PMP field names for a section.
 *
 * @param string $section Section key (profile, craft, network, business, workshop, experience, vibe).
 * @return array ['mode' => '...', 'value' => '...']
 */
function memdir_get_section_pmp_map($section)
{
    static $map = null;

    if ($map === null) {
        $map = array(
            'profile' => array(
                'mode' => 'member_directory_profile_privacy_mode',
                'value' => 'member_directory_profile_privacy_level',
            ),
            'craft' => array(
                'mode' => 'member_directory_craft_privacy_mode',
                'value' => 'member_directory_craft_privacy_level',
            ),
            'network' => array(
                'mode' => 'member_directory_network_privacy_mode',
                'value' => 'member_directory_network_privacy_level',
            ),
            'business' => array(
                'mode' => 'member_directory_business_privacy_mode',
                'value' => 'member_directory_business_privacy_level',
            ),
            'workshop' => array(
                'mode' => 'member_directory_workshop_privacy_mode',
                'value' => 'member_directory_workshop_privacy_level',
            ),
            'experience' => array(
                'mode' => 'member_directory_experience_privacy_mode',
                'value' => 'member_directory_experience_privacy_level',
            ),
            'vibe' => array(
                'mode' => 'member_directory_vibe_privacy_mode',
                'value' => 'member_directory_vibe_privacy_level',
            ),
        );
    }

    if (isset($map[$section])) {
        return $map[$section];
    }

    // Fallback for unknown sections (uses new naming convention)
    return array(
        'mode' => "member_directory_{$section}_privacy_mode",
        'value' => "member_directory_{$section}_privacy_level",
    );
}
