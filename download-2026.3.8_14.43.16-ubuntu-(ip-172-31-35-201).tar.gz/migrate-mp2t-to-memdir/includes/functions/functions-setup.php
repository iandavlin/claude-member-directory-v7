<?php
/**
 * Setup Functions
 * Handles post type registration, taxonomy registration, and plugin initialization
 */

if (!defined('ABSPATH'))
    exit;

/**
 * Register the member-directory post type
 */
function memdir_register_post_type()
{
    $labels = array(
        'name' => 'Member Profiles',
        'singular_name' => 'Member Profile',
        'menu_name' => 'Member Directory',
        'add_new_item' => 'Add New Member Profile',
        'edit_item' => 'Edit Member Profile',
        'new_item' => 'New Member Profile',
        'view_item' => 'View Member Profile',
        'search_items' => 'Search Member Profiles',
        'not_found' => 'No member profiles found',
        'not_found_in_trash' => 'No member profiles found in trash',
        'all_items' => 'All Member Profiles',
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'member-directory', 'with_front' => false),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-id',
        'supports' => array('title', 'author'),
        'show_in_rest' => true,
    );

    register_post_type('member-directory', $args);
}
add_action('init', 'memdir_register_post_type');

/**
 * Self-healing rewrite flush — ensures /member-dir/ archive URL works.
 *
 * When the plugin is uploaded as a ZIP replacement (not freshly activated
 * through the WP plugin installer), the activation hook never fires and
 * the rewrite rules for the member-directory post type are never generated.
 * This checks once per version whether the rules exist and flushes if needed.
 */
function memdir_maybe_flush_rewrites()
{
    $flush_key = 'memdir_rewrite_version';
    $flush_val = MEMDIR_VERSION . '-member-directory'; // includes slug so slug changes trigger re-flush
    if (get_option($flush_key) !== $flush_val) {
        flush_rewrite_rules(false);
        update_option($flush_key, $flush_val);
    }
}
add_action('init', 'memdir_maybe_flush_rewrites', 99);

/**
 * Register Taxonomies
 */
function memdir_register_taxonomies()
{
    $taxonomies = [
        'memdir_instruments' => ['Instruments', 'Instrument'],
        'memdir_musical_contexts' => ['Musical Contexts', 'Musical Context'],
        'memdir_knowledge_domains' => ['Knowledge Domains', 'Knowledge Domain'],
        'memdir_services' => ['Services', 'Service'],
        'memdir_equipment' => ['Equipment', 'Equipment']
    ];

    foreach ($taxonomies as $slug => $labels) {
        if (taxonomy_exists($slug))
            continue;

        register_taxonomy($slug, 'member-directory', [
            'hierarchical' => true,
            'labels' => [
                'name' => $labels[0],
                'singular_name' => $labels[1]
            ],
            'show_ui' => true,
            'show_admin_column' => true,
            'query_var' => true,
            'rewrite' => ['slug' => str_replace('memdir_', '', $slug)],
            'show_in_rest' => true
        ]);
    }
}
add_action('init', 'memdir_register_taxonomies');

/**
 * Load custom template for member directory posts and archive
 */
function memdir_template_include($template)
{
    // Archive page
    if (is_post_type_archive('member-directory')) {
        $theme_template = locate_template('archive-member-directory.php');
        if ($theme_template) {
            return $theme_template;
        }

        $archive_template = MEMDIR_PLUGIN_DIR . 'templates/archive-member-directory.php';
        if (file_exists($archive_template)) {
            return $archive_template;
        }
    }

    // Single profile page
    if (is_singular('member-directory')) {
        $theme_template = locate_template('memdir-profile-page.php');
        if ($theme_template) {
            return $theme_template;
        }

        $custom_template = MEMDIR_PLUGIN_DIR . 'templates/single-member-directory.php';
        if (file_exists($custom_template)) {
            return $custom_template;
        }
    }

    return $template;
}
add_filter('template_include', 'memdir_template_include', 9999);

/**
 * Elementor Compatibility — prevent Elementor Pro's Theme Builder from
 * overriding member-directory templates.
 *
 * Elementor Pro hooks into template_include at priority ~12. Even with our
 * priority 9999 above, Elementor may also use its own rendering pipeline
 * (Canvas, Full Width, etc.) if a Theme Builder condition matches. These
 * hooks ensure Elementor steps aside for our post type.
 */
function memdir_elementor_compat()
{
    if (!defined('ELEMENTOR_VERSION')) {
        return;
    }

    // Tell Elementor not to override template locations for member-directory
    add_filter('elementor/theme/need_override_location', function ($need_override) {
        if (is_singular('member-directory') || is_post_type_archive('member-directory')) {
            return false;
        }
        return $need_override;
    });

    // L4 Fix: Prevent Elementor's page template system from applying its
    // canvas/full-width layouts. Only remove template-related attributes;
    // preserve other Elementor data attributes for compatibility.
    add_filter('elementor/document/wrapper_attributes', function ($attributes) {
        if (is_singular('member-directory') || is_post_type_archive('member-directory')) {
            unset($attributes['data-elementor-type']);
            unset($attributes['data-elementor-id']);
        }
        return $attributes;
    });
}
add_action('wp', 'memdir_elementor_compat');

/**
 * Enqueue styles and scripts for profile pages
 */
function memdir_enqueue_assets()
{
    $is_directory = is_singular('member-directory') || is_post_type_archive('member-directory');

    if (!$is_directory) {
        return;
    }

    // Enqueue Google Fonts (Work Sans)
    wp_enqueue_style(
        'memdir-google-fonts',
        'https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600&display=swap',
        array(),
        null
    );

    // Enqueue CSS
    wp_enqueue_style(
        'memdir-profile-styles',
        MEMDIR_PLUGIN_URL . 'assets/css/profile-styles.css',
        array('memdir-google-fonts'),
        MEMDIR_VERSION
    );

    // Enqueue Core JavaScript (navigation, headers, social links, forms)
    wp_enqueue_script(
        'memdir-profile-core',
        MEMDIR_PLUGIN_URL . 'assets/js/profile-core.js',
        array('jquery'),
        MEMDIR_VERSION,
        true
    );

    // Enqueue Endorsements/Vouch JS (skill vouches + trusted network)
    wp_enqueue_script(
        'memdir-endorsements',
        MEMDIR_PLUGIN_URL . 'assets/js/endorsements.js',
        array('jquery', 'memdir-profile-core'),
        MEMDIR_VERSION,
        true
    );

    // Enqueue PMP Controls whenever the owner can edit (sidebar is visible in preview modes too)
    if (memdir_can_edit()) {
        wp_enqueue_script(
            'memdir-pmp-controls',
            MEMDIR_PLUGIN_URL . 'assets/js/pmp-controls.js',
            array('jquery', 'memdir-profile-core'),
            MEMDIR_VERSION,
            true
        );
    }

    // Save controller + media library only needed in actual edit mode (form interactions)
    if (memdir_get_viewer_mode() === 'edit') {
        wp_enqueue_script(
            'memdir-save-controller',
            MEMDIR_PLUGIN_URL . 'assets/js/save-controller.js',
            array('jquery', 'memdir-profile-core'),
            MEMDIR_VERSION,
            true
        );

        // Enqueue WP Media Library for portfolio uploads
        wp_enqueue_media();
    }

    // Pass data to JavaScript
    $current_post_id = get_the_ID();
    $current_user_id = get_current_user_id();
    $viewer_mode = memdir_get_viewer_mode();

    // Build field privacy states for edit mode (used by JS badge injection)
    $field_privacy_states = array();
    if ($viewer_mode === 'edit' && function_exists('memdir_get_section_content_fields') && function_exists('memdir_get_field_privacy_state')) {
        $sections = array_keys(memdir_get_section_group_map());
        foreach ($sections as $section) {
            $fields = memdir_get_section_content_fields($section);
            foreach ($fields as $field) {
                $state = memdir_get_field_privacy_state($field['name'], $current_post_id, $section);
                $field_privacy_states[$field['name']] = array(
                    'section' => $section,
                    'value' => $state['value'],
                    'hasOverride' => $state['has_override'],
                    'inheritedFrom' => $state['inherited_from'],
                );
            }
        }
    }

    // Build PMP field name map for JS (avoid hardcoding prefixes in JS)
    $pmp_field_map = array();
    foreach (array('profile', 'craft', 'network', 'business', 'workshop', 'experience', 'vibe') as $s) {
        $pmp = memdir_get_section_pmp_fields($s);
        $pmp_field_map[$s] = array(
            'mode' => $pmp['mode'],
            'value' => $pmp['value'],
        );
    }

    wp_localize_script('memdir-profile-core', 'memdirData', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('memdir_nonce'),
        'postId' => $current_post_id,
        'viewerMode' => $viewer_mode,
        'userId' => $current_user_id,
        'isOwner' => ($current_user_id === intval(get_post_field('post_author', $current_post_id))),
        'isAdmin' => current_user_can('administrator'),
        'fieldPrivacyStates' => $field_privacy_states,
        'vouchNonce' => wp_create_nonce('memdir_vouch_nonce'),
        'globalPrivacyField' => memdir_field('member_pmp_default'),
        'pmpFields' => $pmp_field_map,
    ));

    // Archive-specific: search/filter JS
    if (is_post_type_archive('member-directory')) {
        wp_enqueue_script(
            'memdir-directory-search',
            MEMDIR_PLUGIN_URL . 'assets/js/directory-search.js',
            array('jquery', 'memdir-profile-core'),
            MEMDIR_VERSION,
            true
        );

        wp_localize_script('memdir-directory-search', 'memdirArchiveData', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('memdir_archive_nonce'),
        ));

        // Map view JS (lazy-loaded — Leaflet CDN only fetched when map toggle clicked)
        wp_enqueue_script(
            'memdir-directory-map',
            MEMDIR_PLUGIN_URL . 'assets/js/directory-map.js',
            array('jquery', 'memdir-directory-search'),
            MEMDIR_VERSION,
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'memdir_enqueue_assets');

/**
 * Add body classes for member directory pages.
 * Adds: memdir-profile-page, viewer-mode-{mode}, is-owner, is-admin.
 */
function memdir_body_class($classes)
{
    // Archive page classes
    if (is_post_type_archive('member-directory')) {
        $classes[] = 'memdir-archive-page';
        return $classes;
    }

    if (!is_singular('member-directory')) {
        return $classes;
    }

    $post_id = get_the_ID();
    $viewer_mode = memdir_get_viewer_mode($post_id);

    $classes[] = 'memdir-profile-page';
    $classes[] = 'viewer-mode-' . $viewer_mode;

    if (is_user_logged_in()) {
        $current_user_id = get_current_user_id();
        $post_author_id = intval(get_post_field('post_author', $post_id));

        if ($current_user_id === $post_author_id) {
            $classes[] = 'is-owner';
        }
        if (current_user_can('administrator')) {
            $classes[] = 'is-admin';
        }
    }

    return $classes;
}
add_filter('body_class', 'memdir_body_class');

/**
 * Restrict the WordPress Media Library so non-admin users only see
 * their own uploads. Admins retain full access to all media.
 *
 * This filters the AJAX-powered grid view (used by the media modal)
 * and the list view in wp-admin.
 */
function memdir_restrict_media_library($query)
{
    // Only restrict for non-admins
    if (current_user_can('administrator') || current_user_can('editor')) {
        return $query;
    }

    $query['author'] = get_current_user_id();
    return $query;
}
add_filter('ajax_query_attachments_args', 'memdir_restrict_media_library');

/**
 * Also restrict the list-view Media Library in wp-admin for non-admins.
 */
function memdir_restrict_media_list_view($query)
{
    if (!is_admin() || !$query->is_main_query()) {
        return;
    }

    // Only apply on the media library screen
    global $pagenow;
    if ($pagenow !== 'upload.php') {
        return;
    }

    if (current_user_can('administrator') || current_user_can('editor')) {
        return;
    }

    $query->set('author', get_current_user_id());
}
add_action('pre_get_posts', 'memdir_restrict_media_list_view');

/**
 * Finding #8: ACF JSON load point — tell ACF to look for field group JSON
 * files inside this plugin's acf-json/ directory.
 */
function memdir_acf_json_load_point($paths)
{
    $paths[] = MEMDIR_PLUGIN_DIR . 'acf-json';
    return $paths;
}
add_filter('acf/settings/load_json', 'memdir_acf_json_load_point');

/**
 * Finding #9: Admin dashboard menu — gives users a "My Profile" link
 * in the WP dashboard sidebar.
 */
function memdir_add_admin_menu()
{
    add_menu_page(
        'My Profile',                        // Page title
        'My Profile',                        // Menu title
        'read',                              // Capability — all logged-in users
        'memdir-my-profile',                   // Menu slug
        'memdir_admin_profile_redirect',       // Callback
        'dashicons-id',                      // Icon
        25                                   // Position
    );
}
add_action('admin_menu', 'memdir_add_admin_menu');

/**
 * Redirect from the admin menu item to the user's front-end profile.
 */
function memdir_admin_profile_redirect()
{
    // M7 Fix: memdir_get_profile_url() always returns a valid URL —
    // either the profile permalink or the setup flow URL with nonce.
    // The previous fallback branch was dead code (unreachable).
    wp_safe_redirect(memdir_get_profile_url());
    exit;
}

/**
 * Finding #22: Rewrite endpoint choice — DOCs describe add_rewrite_endpoint
 * for clean preview URLs (/view-as/member/). Current implementation uses
 * ?mode= query parameter which works but doesn't match DOCs. Leaving as-is
 * since ?mode= is functional and simpler; switching to endpoint would require
 * flush_rewrite_rules() and theme compatibility testing.
 */

/**
 * Finding #10: acf/prepare_field filter stub — DOCs describe injecting
 * per-field privacy toggle HTML inline with ACF field labels. This is
 * currently handled by the JS approach in pmp-controls.js which looks
 * for data-name*="memdir_pmp_override" in ACF-rendered fields. A PHP filter
 * could provide server-rendered toggles for better progressive enhancement.
 *
 * @todo Implement memdir_inject_field_privacy_control() when ACF JSON
 *       field groups are finalized, to inject toggle HTML into field wrappers.
 */
// add_filter('acf/prepare_field', 'memdir_inject_field_privacy_control');

/**
 * Archive query customization — controls pagination, sorting, and privacy filtering.
 * Excludes profiles whose global PMP is "private" from non-logged-in visitors.
 */
function memdir_archive_query($query)
{
    if (is_admin() || !$query->is_main_query() || !is_post_type_archive('member-directory')) {
        return;
    }

    $query->set('posts_per_page', 12);

    // Sorting
    $sort = isset($_GET['sort']) ? sanitize_key($_GET['sort']) : 'az';
    switch ($sort) {
        case 'za':
            $query->set('orderby', 'title');
            $query->set('order', 'DESC');
            break;
        case 'newest':
            $query->set('orderby', 'date');
            $query->set('order', 'DESC');
            break;
        case 'oldest':
            $query->set('orderby', 'date');
            $query->set('order', 'ASC');
            break;
        case 'az':
        default:
            $query->set('orderby', 'title');
            $query->set('order', 'ASC');
            break;
    }

    // Privacy filtering: hide fully-private profiles from public visitors
    $privacy_query = memdir_get_privacy_meta_query();
    if ($privacy_query) {
        $query->set('meta_query', $privacy_query);
    }

    // Taxonomy filtering from URL params
    $tax_filters = array('memdir_instruments', 'memdir_services', 'memdir_musical_contexts');
    $tax_query = array();

    foreach ($tax_filters as $taxonomy) {
        if (!empty($_GET[$taxonomy]) && is_array($_GET[$taxonomy])) {
            // Cap at 50 terms per taxonomy to prevent unbounded IN() clauses (H5 fix)
            $term_ids = array_map('intval', array_slice($_GET[$taxonomy], 0, 50));
            $tax_query[] = array(
                'taxonomy' => $taxonomy,
                'field' => 'term_id',
                'terms' => $term_ids,
                'operator' => 'IN',
            );
        }
    }

    if (!empty($tax_query)) {
        $tax_query['relation'] = 'AND';
        $query->set('tax_query', $tax_query);
    }
}
add_action('pre_get_posts', 'memdir_archive_query');

/**
 * Finding #23: Profile cache clearing stub — DOCs mention clearing cached
 * profile data when a post is saved. No caching layer exists yet, so this
 * is a no-op stub that will be activated when object caching is added.
 *
 * @param int $post_id The post ID to clear cache for
 */
function memdir_clear_profile_cache($post_id)
{
    // Clear map data transients — derive keys from centralized version constant.
    // Also clear legacy un-versioned keys for backwards compatibility.
    $map_versions = array('', 'v2_', MEMDIR_MAP_CACHE_VERSION . '_');
    foreach ($map_versions as $ver) {
        delete_transient('memdir_map_data_' . $ver . 'public');
        delete_transient('memdir_map_data_' . $ver . 'member');
    }

    // Future: delete per-profile transients/object cache here
    // delete_transient("memdir_profile_{$post_id}");
    // wp_cache_delete("profile_{$post_id}", 'memdir');
}

/**
 * Finding #24: Fire memdir_profile_updated action hook when a member-directory
 * post is saved through ACF, allowing other plugins/themes to react.
 *
 * @param int $post_id The post ID being saved
 */
function memdir_fire_profile_updated($post_id)
{
    if (get_post_type($post_id) !== 'member-directory') {
        return;
    }

    // Clear any cached data for this profile
    memdir_clear_profile_cache($post_id);

    /**
     * Fires after a member-directory profile is updated via ACF.
     *
     * @param int $post_id The post ID that was updated.
     */
    do_action('memdir_profile_updated', $post_id);
}
add_action('acf/save_post', 'memdir_fire_profile_updated', 30);

/**
 * Force the post slug (URL) to stay in sync with the post title.
 * 
 * Two-pronged approach:
 * 1. `wp_insert_post_data` filter — catches non-ACF saves (e.g. wp_insert_post 
 *    from setup-profile.php, admin edits). Modifies post_name before DB write.
 * 2. `acf/save_post` hook — catches ACF front-end form saves. ACF updates the 
 *    post title internally and may not always trigger wp_insert_post_data 
 *    reliably for the title field. This hook runs AFTER ACF saves, reads the 
 *    current title, and forces the slug to match.
 */

/**
 * Prong 1: wp_insert_post_data filter (non-ACF saves)
 * Modifies post_name in-flight before the DB write.
 *
 * @param array $data    Slashed, sanitized post data about to be saved.
 * @param array $postarr Raw (slashed) post data array.
 * @return array
 */
function memdir_sync_slug_with_title($data, $postarr)
{
    if ($data['post_type'] !== 'member-directory') {
        return $data;
    }

    if (!in_array($data['post_status'], array('publish', 'draft', 'pending'))) {
        return $data;
    }

    // $data is slashed — unslash before sanitizing to avoid 'ted\'s' → 'ted-s'
    $title_slug = sanitize_title(wp_unslash($data['post_title']));
    $current_slug = $data['post_name'];

    if ($title_slug && $current_slug !== $title_slug) {
        $data['post_name'] = $title_slug;
    }

    return $data;
}
add_filter('wp_insert_post_data', 'memdir_sync_slug_with_title', 99, 2);

/**
 * Prong 2: acf/save_post hook (ACF front-end form saves)
 * After ACF saves, read the `member_directory_page_name` field and sync it 
 * to both `post_title` (for WP display) and `post_name` (for the URL slug).
 * Uses remove_action/add_action to prevent infinite loops.
 *
 * @param int $post_id The post ID that was just saved by ACF.
 */
function memdir_sync_slug_after_acf_save($post_id)
{
    if (get_post_type($post_id) !== 'member-directory') {
        return;
    }

    $post = get_post($post_id);
    if (!$post || !in_array($post->post_status, array('publish', 'draft', 'pending'))) {
        return;
    }

    // Read the ACF "Page Name" field
    $page_name = get_field('member_directory_page_name', $post_id);

    // Backward compat: if the ACF field is empty but the post has a title,
    // seed the field from the existing post title (one-time migration).
    if (empty($page_name) && !empty($post->post_title)) {
        update_field('member_directory_page_name', $post->post_title, $post_id);
        return; // No slug change needed — title was already set
    }

    if (empty($page_name)) {
        return;
    }

    $new_slug = sanitize_title($page_name);
    $needs_title_update = ($post->post_title !== $page_name);
    $needs_slug_update = ($new_slug && $post->post_name !== $new_slug);

    if ($needs_title_update || $needs_slug_update) {
        // Unhook to prevent infinite loop
        remove_action('acf/save_post', 'memdir_sync_slug_after_acf_save', 20);

        $update = array('ID' => $post_id);
        if ($needs_title_update) {
            $update['post_title'] = $page_name;
        }
        if ($needs_slug_update) {
            $update['post_name'] = $new_slug;
        }
        wp_update_post($update);

        // Re-hook
        add_action('acf/save_post', 'memdir_sync_slug_after_acf_save', 20);
    }
}
add_action('acf/save_post', 'memdir_sync_slug_after_acf_save', 20);

/**
 * Add front-end navigation links to the WordPress admin bar.
 * Gives logged-in users quick access to the directory and their own profile
 * without needing to visit the admin dashboard.
 *
 * @param WP_Admin_Bar $wp_admin_bar The admin bar instance
 */
function memdir_admin_bar_links($wp_admin_bar)
{
    if (!is_user_logged_in()) {
        return;
    }

    // Parent node: Member Directory
    $wp_admin_bar->add_node(array(
        'id' => 'memdir-directory',
        'title' => '<span class="ab-icon dashicons dashicons-groups" style="font-family:dashicons;font-size:16px;line-height:1;margin-right:4px;vertical-align:middle;"></span>Directory',
        'href' => get_post_type_archive_link('member-directory'),
        'meta' => array(
            'title' => 'Member Directory',
        ),
    ));

    // Child: Browse Directory
    $wp_admin_bar->add_node(array(
        'id' => 'memdir-browse',
        'parent' => 'memdir-directory',
        'title' => 'Browse Directory',
        'href' => get_post_type_archive_link('member-directory'),
    ));

    // Child: My Profile
    $profile_url = memdir_get_profile_url();
    $user_post = memdir_get_user_post();
    $profile_label = $user_post ? 'My Profile' : 'Create My Profile';

    $wp_admin_bar->add_node(array(
        'id' => 'memdir-my-profile',
        'parent' => 'memdir-directory',
        'title' => $profile_label,
        'href' => $profile_url,
    ));

    // Child: Edit Profile (for owners who already have a profile — goes to edit mode)
    if ($user_post) {
        $wp_admin_bar->add_node(array(
            'id' => 'memdir-edit-profile',
            'parent' => 'memdir-directory',
            'title' => 'Edit My Profile',
            'href' => add_query_arg('mode', 'edit', get_permalink($user_post->ID)),
        ));
    }
}
add_action('admin_bar_menu', 'memdir_admin_bar_links', 80);

/**
 * Shortcode: [memdir_my_profile_link]
 * Renders a clickable link to the current user's profile.
 * For logged-out visitors, shows nothing (or a login prompt via the "guest" attribute).
 *
 * Usage:
 *   [memdir_my_profile_link]                          → "My Profile" link
 *   [memdir_my_profile_link text="View My Page"]      → Custom link text
 *   [memdir_my_profile_link class="btn btn-primary"]  → Custom CSS class
 *   [memdir_my_profile_link guest="Log in to view your profile"]  → Text shown to guests
 */
function memdir_shortcode_my_profile_link($atts)
{
    $atts = shortcode_atts(array(
        'text' => 'My Profile',
        'class' => 'memdir-profile-link',
        'guest' => '',
    ), $atts, 'memdir_my_profile_link');

    if (!is_user_logged_in()) {
        if (!empty($atts['guest'])) {
            $login_url = wp_login_url(home_url($_SERVER['REQUEST_URI']));
            return '<a href="' . esc_url($login_url) . '" class="' . esc_attr($atts['class']) . '">' . esc_html($atts['guest']) . '</a>';
        }
        return '';
    }

    $url = memdir_get_profile_url();
    return '<a href="' . esc_url($url) . '" class="' . esc_attr($atts['class']) . '">' . esc_html($atts['text']) . '</a>';
}
add_shortcode('memdir_my_profile_link', 'memdir_shortcode_my_profile_link');

/**
 * Shortcode: [memdir_directory_link]
 * Renders a clickable link to the member directory archive page.
 *
 * Usage:
 *   [memdir_directory_link]                                → "Member Directory" link
 *   [memdir_directory_link text="Browse Our Members"]      → Custom link text
 *   [memdir_directory_link class="btn btn-secondary"]      → Custom CSS class
 */
function memdir_shortcode_directory_link($atts)
{
    $atts = shortcode_atts(array(
        'text' => 'Member Directory',
        'class' => 'memdir-directory-link',
    ), $atts, 'memdir_directory_link');

    $url = get_post_type_archive_link('member-directory');
    return '<a href="' . esc_url($url) . '" class="' . esc_attr($atts['class']) . '">' . esc_html($atts['text']) . '</a>';
}
add_shortcode('memdir_directory_link', 'memdir_shortcode_directory_link');

/**
 * Shortcode: [memdir_my_profile_url]
 * Returns the raw URL (no HTML) to the current user's profile.
 * Useful inside href attributes in page builders or custom HTML blocks.
 *
 * Usage:
 *   <a href="[memdir_my_profile_url]">Go to profile</a>
 */
function memdir_shortcode_my_profile_url()
{
    if (!is_user_logged_in()) {
        return '';
    }
    return esc_url(memdir_get_profile_url());
}
add_shortcode('memdir_my_profile_url', 'memdir_shortcode_my_profile_url');
