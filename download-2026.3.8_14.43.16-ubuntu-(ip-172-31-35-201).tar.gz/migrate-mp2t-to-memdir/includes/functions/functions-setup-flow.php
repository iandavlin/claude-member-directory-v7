<?php
/**
 * Setup Flow Handler
 * Handles ?memdir_setup=1 parameter to create member directory posts for new users
 */

if (!defined('ABSPATH'))
    exit;

/**
 * Handle the setup flow for new member profiles
 * Intercepts ?memdir_setup=1 to show the creation form or redirect to existing profile
 */
function memdir_handle_setup_flow()
{
    if (!isset($_GET['memdir_setup']) || $_GET['memdir_setup'] !== '1') {
        return;
    }

    // Must be logged in
    if (!is_user_logged_in()) {
        wp_safe_redirect(wp_login_url(memdir_get_profile_url()));
        exit;
    }

    $user_id = get_current_user_id();

    // Check if user already has a post
    $existing_post = memdir_get_user_post($user_id);

    if ($existing_post) {
        // Already has a post — redirect to edit mode
        wp_safe_redirect(get_permalink($existing_post->ID) . '?mode=edit');
        exit;
    }

    // No profile found? Show the setup template.
    // This template handles post creation via a plain HTML form + wp_insert_post.
    $setup_template = MEMDIR_PLUGIN_DIR . 'templates/setup-profile.php';

    if (file_exists($setup_template)) {
        include $setup_template;
        exit;
    } else {
        wp_die('Setup template missing. Please contact an administrator.', 'Setup Error');
    }
}
add_action('template_redirect', 'memdir_handle_setup_flow');
