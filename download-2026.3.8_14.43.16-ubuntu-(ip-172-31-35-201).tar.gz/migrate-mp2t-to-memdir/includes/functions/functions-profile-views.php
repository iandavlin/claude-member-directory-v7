<?php
/**
 * Profile View Counter
 * Tracks unique profile views per session using post meta.
 * Excludes profile owner's own visits.
 */

if (!defined('ABSPATH'))
    exit;

/**
 * Increment view count when a profile is viewed.
 * Called on template_redirect for single member-directory posts.
 * Uses a session-based cookie to prevent double-counting within 24 hours.
 */
function memdir_track_profile_view()
{
    if (!is_singular('member-directory')) {
        return;
    }

    $post_id = get_the_ID();

    // Don't count if the viewer is the profile owner
    if (is_user_logged_in()) {
        $current_user_id = get_current_user_id();
        $post_author_id = intval(get_post_field('post_author', $post_id));
        if ($current_user_id === $post_author_id) {
            return;
        }
    }

    // M6 Fix: Session-based dedup using a single cookie for all viewed profiles.
    // Previously each view set a unique cookie (memdir_viewed_{id}), which could
    // create hundreds of cookies for active browsers. Now stores all viewed IDs
    // in one JSON-encoded cookie, capped at 200 entries.
    $cookie_name = 'memdir_viewed_profiles';
    $viewed = array();

    if (isset($_COOKIE[$cookie_name])) {
        $decoded = json_decode(stripslashes($_COOKIE[$cookie_name]), true);
        if (is_array($decoded)) {
            $viewed = array_map('intval', $decoded);
        }
    }

    if (in_array($post_id, $viewed, true)) {
        return;
    }

    // Add current post to viewed list (cap at 200 to prevent cookie overflow)
    $viewed[] = $post_id;
    if (count($viewed) > 200) {
        $viewed = array_slice($viewed, -200);
    }

    // Set single cookie for 24 hours (output before headers — hooked on template_redirect)
    setcookie($cookie_name, wp_json_encode($viewed), time() + DAY_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);

    // Atomic increment — avoids race condition with concurrent visitors.
    // The read-then-write pattern (get_post_meta → update_post_meta) can
    // lose increments under load. A single UPDATE ... +1 is safe.
    global $wpdb;
    $wpdb->query($wpdb->prepare(
        "UPDATE {$wpdb->postmeta} SET meta_value = meta_value + 1 WHERE post_id = %d AND meta_key = %s",
        $post_id,
        memdir_field('profile_views')
    ));

    // If the meta row doesn't exist yet, the UPDATE affected 0 rows — seed it.
    if ($wpdb->rows_affected === 0) {
        add_post_meta($post_id, memdir_field('profile_views'), 1, true);
    }

    // Invalidate WP's meta cache so subsequent reads on this request are fresh.
    wp_cache_delete($post_id, 'post_meta');
}
add_action('template_redirect', 'memdir_track_profile_view');

/**
 * Get the view count for a profile.
 *
 * @param int $post_id The post ID
 * @return int The view count
 */
function memdir_get_profile_views($post_id)
{
    return intval(get_post_meta($post_id, memdir_field('profile_views'), true));
}
